#!/usr/bin/env python3
"""
KRIVI OS - microSD card image builder
=====================================
Creates the complete FAT32 folder tree for the CYD's microSD card:

  sys/settings.json         calibration, colours, Wi-Fi keys, alarm, volume
  sys/apps/app_NN.json      per-app manifests paged in by the dynamic loader
  sys/boot/                 diagnostic boot logs (written by the OS)
  icons/app_01..43.raw      40x40 RGB565 little-endian icons
  roms/                     put your own legally-dumped .nes files here
  data/paint/               Sketchpad .bmp files
  data/chiptunes/           ProTracker .mod files (an original demo tune is generated)
  data/reader/              .txt e-books / manuals (KRIVI manual generated)
  data/video/               Motion-JPEG clips (.mjpeg, e.g. Bad Apple)
  data/music/               MP3 songs for the MP3 player (app 44)
  data/movies/              MP4s converted to .avi by convert_media.py (app 40)

Usage:   python3 make_sd.py [output_dir] [--sketch ../KriviOS]
Then copy the CONTENTS of output_dir to the root of a FAT32 microSD card.
Requires Pillow (pip install pillow) for icon rendering.
"""
import json, math, os, re, struct, sys, random

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else os.path.join(HERE, '..', 'sd_card')
SKETCH = os.path.join(HERE, '..', 'KriviOS')
if '--sketch' in sys.argv:
    SKETCH = sys.argv[sys.argv.index('--sketch') + 1]

def mk(*p):
    path = os.path.join(OUT, *p)
    os.makedirs(path, exist_ok=True)
    return path

# --------------------------------------------------------------------------- app registry
# Parsed from launcher.cpp so the SD card always matches the firmware.
def load_registry():
    src = open(os.path.join(SKETCH, 'launcher.cpp'), encoding='utf-8').read()
    body = src[src.index('const AppDef APPS[] = {'):src.index('const int APP_COUNT')]
    apps = []
    pat = re.compile(r'\{(\d+),\s*(\d),\s*"([^"]*)",\s*"([^"]*)",\s*"([^"]*)",\s*(P\d),\s*(\w+),\s*((?:"(?:[^"\\]|\\.)*"\s*)+),\s*((?:"(?:[^"\\]|\\.)*"\s*)+)\}', re.S)
    for m in pat.finditer(body):
        def joined(s):
            parts = re.findall(r'"((?:[^"\\]|\\.)*)"', s)
            return ''.join(parts).encode().decode('unicode_escape')
        apps.append(dict(id=int(m.group(1)), page=int(m.group(2)), name=m.group(3), label=m.group(4),
                         abbr=m.group(5), cat=m.group(6), needs=joined(m.group(8)), help=joined(m.group(9))))
    assert len(apps) == 71, f'expected 71 apps, parsed {len(apps)}'
    return apps

PAGE_TITLES = ["GAMING & EMULATION", "AUDIO & SENSORS",
               "UTILITIES & TIME", "PI LINK & RADIO",
               "GRAPHICS & SANDBOX", "WIRELESS LAB & SYSTEM"]
CAT_HUE = {'P1': (230, 60, 90), 'P2': (150, 80, 240), 'P3': (0, 180, 170), 'P4': (40, 160, 255), 'P5': (255, 150, 30), 'P6': (0, 210, 120)}

# --------------------------------------------------------------------------- settings
SETTINGS = {
    "wifi": {"ssid": "", "pass": ""},
    "time": {"tz": "EST5EDT,M3.2.0,M11.1.0", "ntp": "pool.ntp.org"},
    "sound": {"volume": 140, "clicks": True},
    "touch": {"invertX": False, "invertY": False,
              "_note": "map() constants are fixed in firmware: x 300..3600 -> 0..319, y 500..3700 -> 0..239"},
    "display": {"flip": False},
    "theme": {"accent": "#00C8FF", "background": "#080A12"},
    "launcher": {"page": 0},
    "alarm": {"enabled": False, "h": 7, "m": 0},
    "clap": {"threshold": 900},
    "weather": {"city": "", "lat": 40.7128, "lon": -74.006, "name": "", "units": "us",
                "_note": "set city (geocoded) OR lat/lon; units us=F/mph, metric=C/km/h"},
}

# Per-app manifests: params are handed to the app; min_heap_kb is enforced
# by the loader; require_dir is checked and reported on the launch splash.
MANIFESTS = {
    1:  {"require_dir": "/roms", "min_heap_kb": 48},
    6:  {"min_heap_kb": 70},
    10: {"params": {"octave": 4}},
    13: {"params": {"start_hz": 440}},
    14: {"params": {"double_clap": 0}},
    15: {"require_dir": "/data/chiptunes", "min_heap_kb": 24},
    16: {"params": {"bpm": 120, "beats": 4}},
    17: {"min_heap_kb": 40},
    19: {"params": {"work_min": 25, "break_min": 5, "long_break_min": 15}},
    22: {"require_dir": "/data/reader"},
    24: {"min_heap_kb": 56},
    29: {"params": {"speed": 2.0}},
    30: {"params": {"macros": [
        {"label": "Copy", "keys": "CTRL+C"}, {"label": "Paste", "keys": "CTRL+V"},
        {"label": "Undo", "keys": "CTRL+Z"}, {"label": "Save", "keys": "CTRL+S"},
        {"label": "Terminal", "keys": "CTRL+ALT+T"}, {"label": "Lock", "keys": "GUI+L"},
        {"label": "Vol -", "keys": "media:VOLDN"}, {"label": "Play", "keys": "media:PLAY"},
        {"label": "Vol +", "keys": "media:VOLUP"}]}},
    33: {"params": {"host": "1.1.1.1"}},
    34: {"params": {"channel": 1, "nick": ""}},
    35: {"require_dir": "/data/paint", "min_heap_kb": 28},
    39: {"params": {"iterations": 64}},
    40: {"require_dir": "/data/movies", "min_heap_kb": 64, "params": {"fps": 30, "max_frame_kb": 40, "volume": 230}},
    44: {"require_dir": "/data/music", "min_heap_kb": 60, "params": {"volume": 220}},
    45: {"min_heap_kb": 20},
    46: {"min_heap_kb": 40},
    47: {"min_heap_kb": 20},
    48: {"min_heap_kb": 20},
    49: {"min_heap_kb": 20, "params": {"host": "1.1.1.1", "dns_test": "example.com"}},
    50: {"min_heap_kb": 20},
    51: {"require_dir": "/icons/weather", "min_heap_kb": 48,
         "params": {"city": "", "lat": 40.7128, "lon": -74.006, "name": "", "units": "us"}},
    52: {"min_heap_kb": 100},
    53: {"min_heap_kb": 12},
    54: {"min_heap_kb": 10},
    55: {"min_heap_kb": 12},
    56: {"min_heap_kb": 10},
    57: {"min_heap_kb": 40},
    58: {"min_heap_kb": 30},
    59: {"min_heap_kb": 20},
    64: {"params": {"units": "cm"}},
    65: {},
    66: {},
    69: {"params": {"actions": [
        {"label": "Uptime", "cmd": "uptime"}, {"label": "Disk", "cmd": "df -h /"},
        {"label": "Temp", "cmd": "vcgencmd measure_temp || cat /sys/class/thermal/thermal_zone0/temp"},
        {"label": "IP", "cmd": "ip -4 -o addr show"}, {"label": "Services", "cmd": "systemctl --failed --no-legend"},
        {"label": "Free mem", "cmd": "free -h"}]}},
    74: {},
    76: {"params": {"h24": 0}},
    77: {"params": {"log": 0}},
    41: {"params": {"name": "Krivi"}},
}

# --------------------------------------------------------------------------- icons
GLYPHS = {  # app id -> (text, font size); falls back to the 3-letter abbreviation
    1: ("NES", 15), 2: ("~S", 18), 3: ("▚", 26), 4: ("|•|", 15), 5: ("▦", 26), 6: ("➶", 24), 7: ("✸", 26),
    8: ("▤", 26), 9: ("♞", 28), 10: ("♪", 28), 11: ("∿", 30), 12: ("dB", 18), 13: ("Hz", 18), 14: ("⇄", 26),
    15: ("♫", 28), 16: ("♩", 28), 17: ("◉", 26), 18: ("◷", 28), 19: ("◔", 26), 20: ("±", 28), 21: ("31", 18),
    22: ("✎", 26), 23: ("0x", 18), 24: ("⚄", 30), 25: ("+1", 18), 26: ("☀", 28), 27: ("π", 26), 28: (">_", 18),
    29: ("☝", 24), 30: ("⌘", 26), 31: ("▶", 24), 32: ("◠", 26), 33: ("ms", 18), 34: ("✉", 26), 35: ("✐", 26),
    36: ("✶", 28), 37: ("⋰", 28), 38: ("⁘", 28), 39: ("∞", 28), 40: ("▣", 26), 41: ("♥", 28), 42: ("⊕", 28),
    43: ("?", 26), 44: ("MP3", 15),
    45: ("≡", 30), 46: ("BLE", 15), 47: ("MAP", 15), 48: ("LAN", 15), 49: ("NET", 15), 50: ("≈", 30),
    51: ("WX", 15), 52: ("ISS", 15), 53: ("FPS", 15), 54: ("2048", 11),
    55: ("SPC", 15), 56: ("THR", 15), 57: ("SEQ", 15), 58: ("FX", 18),
}

def make_icons(apps):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print('  ! Pillow not installed - icons skipped (firmware draws vector fallbacks)')
        return
    sym_font = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    sym_font2 = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    def font(size, bold=True):
        for f in ([sym_font, sym_font2] if bold else [sym_font2]):
            if os.path.exists(f):
                return ImageFont.truetype(f, size)
        return ImageFont.load_default()
    d = mk('icons')
    rows = (len(apps) + 8) // 9
    sheet = Image.new('RGB', (9 * 48, rows * 48), (8, 10, 18))
    for a in apps:
        S = 160                                   # supersample then downscale -> anti-aliased
        r, g, b = CAT_HUE[a['cat']]
        im = Image.new('RGB', (S, S), (8, 10, 18))
        dr = ImageDraw.Draw(im)
        for y in range(S):                        # vertical gradient tile
            t = y / S
            c = (int(r * (1.05 - 0.45 * t)), int(g * (1.05 - 0.45 * t)), int(b * (1.05 - 0.45 * t)))
            c = tuple(max(0, min(255, v)) for v in c)
            dr.line([(0, y), (S, y)], fill=c)
        mask = Image.new('L', (S, S), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=36, fill=255)
        bg = Image.new('RGB', (S, S), (8, 10, 18))
        im = Image.composite(im, bg, mask)
        dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([12, 8, S - 13, 58], radius=26, fill=None, outline=None)
        hl = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        ImageDraw.Draw(hl).rounded_rectangle([14, 10, S - 15, 64], radius=26, fill=(255, 255, 255, 40))
        im = Image.alpha_composite(im.convert('RGBA'), hl).convert('RGB')
        dr = ImageDraw.Draw(im)
        dr.rounded_rectangle([0, 0, S - 1, S - 1], radius=36, outline=(255, 255, 255), width=3)
        txt, size = GLYPHS.get(a['id'], (a['abbr'], 16))
        f = font(size * 4)
        bb = dr.textbbox((0, 0), txt, font=f)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        pos = ((S - tw) / 2 - bb[0], (S - th) / 2 - bb[1] + 4)
        dr.text((pos[0] + 4, pos[1] + 5), txt, font=f, fill=(0, 0, 0))
        dr.text(pos, txt, font=f, fill=(255, 255, 255))
        icon = im.resize((40, 40), Image.LANCZOS)
        raw = bytearray()
        px = icon.convert('RGB').tobytes()
        for i in range(0, len(px), 3):
            pr, pg, pb = px[i], px[i + 1], px[i + 2]
            v = ((pr & 0xF8) << 8) | ((pg & 0xFC) << 3) | (pb >> 3)
            raw += struct.pack('<H', v)
        open(os.path.join(d, f"app_{a['id']:02d}.raw"), 'wb').write(raw)
        idx = a['id'] - 1
        sheet.paste(icon, ((idx % 9) * 48 + 4, (idx // 9) * 48 + 4))
    sheet.save(os.path.join(HERE, 'icon_contact_sheet.png'))

# --------------------------------------------------------------------------- demo .mod (original)
PERIODS = [856, 808, 762, 720, 678, 640, 604, 570, 538, 508, 480, 453,
           428, 404, 381, 360, 339, 320, 302, 285, 269, 254, 240, 226,
           214, 202, 190, 180, 170, 160, 151, 143, 135, 127, 120, 113]
NOTE = {n: i for i, n in enumerate(['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'])}

def per(name):                      # "C-2" / "D#3"
    n, o = (name[:2], name[2]) if name[1] == '#' else (name[0], name[2])
    return PERIODS[(int(o) - 1) * 12 + NOTE[n]]

def make_mod(path):
    rnd = random.Random(7)
    # --- samples (8-bit signed)
    def sq(duty=0.5, n=32, amp=90): return bytes(((amp if i < n * duty else -amp) & 0xFF) for i in range(n))
    tri = bytes((int(110 * (1 - 4 * abs(i / 32 - 0.5)) - 0) & 0xFF) for i in range(32))
    kick = bytes((int(120 * math.sin(2 * math.pi * sum(1 / (8 + k * 0.5) for k in range(i))) * math.exp(-i / 700)) & 0xFF) for i in range(2400))
    snare = bytes((int((rnd.random() * 2 - 1) * 110 * math.exp(-i / 500)) & 0xFF) for i in range(2000))
    hat = bytes((int((rnd.random() * 2 - 1) * 70 * math.exp(-i / 120)) & 0xFF) for i in range(600))
    samples = [  # name, data, volume, loopStart, loopLen
        ("lead square", sq(0.25), 48, 0, 32),
        ("bass triangle", tri, 64, 0, 32),
        ("kick", kick, 64, 0, 2),
        ("snare", snare, 50, 0, 2),
        ("hat", hat, 40, 0, 2),
        ("pad square", sq(0.5, 32, 60), 30, 0, 32),
    ]
    # --- patterns: 64 rows x 4 channels
    def cell(sample=0, period=0, fx=0, param=0):
        return bytes([(sample & 0xF0) | ((period >> 8) & 0x0F), period & 0xFF,
                      ((sample & 0x0F) << 4) | (fx & 0x0F), param & 0xFF])
    E = cell()
    melodyA = "C-3 . D#3 . G-3 . D#3 . F-3 . G-3 . A#3 . G-3 . G#2 . C-3 . D#3 . C-3 . D-3 . F-3 . G-3 . . . " \
              "C-3 . D#3 . G-3 . C-3 . A#2 . C-3 . D#3 . F-3 . G#2 . G-2 . F-2 . D#2 . D-2 . F-2 . G-2 . . .".split()
    melodyB = "G-3 . . . F-3 . D#3 . D-3 . . . C-3 . D-3 . D#3 . . . F-3 . G-3 . G#3 . . . G-3 . F-3 . " \
              "D#3 . . . D-3 . C-3 . D-3 . . . D#3 . F-3 . G-3 . . . . . . . . . . . . .".split()
    bassline = ["C-1", "C-1", "G#1", "G#1", "D#1", "D#1", "A#1", "A#1"]
    def pattern(melody, variant):
        rows = []
        for r in range(64):
            ch = [E, E, E, E]
            tok = melody[r] if r < len(melody) else '.'
            if tok != '.':
                ch[0] = cell(1, per(tok), 0xC, 44)
            if r % 4 == 0:
                ch[1] = cell(2, per(bassline[(r // 8) % 8]))
            elif r % 4 == 2 and variant:
                ch[1] = cell(2, per(bassline[(r // 8) % 8].replace('1', '2')))
            if r % 8 == 0 or (variant and r % 16 == 10):
                ch[2] = cell(3, per("C-2"))
            elif r % 8 == 4:
                ch[2] = cell(4, per("C-2"))
            if r % 2 == 1:
                ch[3] = cell(5, per("C-3"), 0xC, 24 if r % 4 == 1 else 40)
            elif variant and r % 16 == 0:
                ch[3] = cell(6, per(["C-2", "G#1", "D#2", "A#1"][(r // 16) % 4]), 0xC, 30)
            rows.append(b''.join(ch))
        return b''.join(rows)
    pats = [pattern(melodyA, 0), pattern(melodyA, 1), pattern(melodyB, 1), pattern(melodyB, 0)]
    order = [0, 1, 2, 1, 3, 1]
    hdr = b'KRIVI THEME'.ljust(20, b'\0')
    for i in range(31):
        if i < len(samples):
            nm, data, vol, ls, ll = samples[i]
            hdr += nm.encode().ljust(22, b'\0') + struct.pack('>HBBHH', len(data) // 2, 0, vol, ls // 2, max(1, ll // 2))
        else:
            hdr += b'\0' * 22 + struct.pack('>HBBHH', 0, 0, 0, 0, 1)
    hdr += bytes([len(order), 127]) + bytes(order + [0] * (128 - len(order))) + b'M.K.'
    body = b''.join(pats) + b''.join(s[1] for s in samples)
    # tempo: F06 speed is default; set BPM 140 on first row channel 3 (pattern 0 row 0 empty slot)
    data = bytearray(hdr + body)
    off = 1084  # pattern 0, row 0, channel 3 -> F-effect tempo 140 if free
    if data[off + 12:off + 16] == b'\0\0\0\0':
        data[off + 12:off + 16] = cell(0, 0, 0xF, 140)
    open(path, 'wb').write(data)

# --------------------------------------------------------------------------- demo media (original)
def make_demo_media():
    """Original demo MP3 + movie, only if ffmpeg is installed."""
    import shutil as _sh, subprocess as _sp, tempfile, wave
    ff = _sh.which('ffmpeg')
    if not ff:
        print('  (ffmpeg not found - demo MP3/movie skipped)')
        return
    # 16 s synth arpeggio, rendered here and encoded to MP3 with ID3 tags
    rate = 44100
    notes = [261.63, 311.13, 392.00, 466.16, 415.30, 392.00, 311.13, 349.23] * 4
    pcm = bytearray()
    for i, f0 in enumerate(notes):
        n = int(rate * 0.5)
        bass = notes[(i // 4) * 4] / 2
        for k in range(n):
            t = k / rate
            env = math.exp(-t * 5)
            v = 0.35 * env * (1 if (k * f0 / rate) % 1 < 0.3 else -1)            # pulse lead
            v += 0.25 * (2 * abs(2 * ((k * bass / rate) % 1) - 1) - 1)         # triangle bass
            v += 0.12 * math.sin(2 * math.pi * f0 * 2 * t) * env               # sparkle
            pcm += struct.pack('<h', int(max(-1, min(1, v)) * 26000))
    tmp = tempfile.mkdtemp()
    wav = os.path.join(tmp, 'demo.wav')
    with wave.open(wav, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(bytes(pcm))
    _sp.run([ff, '-loglevel', 'error', '-y', '-i', wav, '-c:a', 'libmp3lame', '-b:a', '128k',
             '-metadata', 'title=KRIVI Boot Anthem', '-metadata', 'artist=KRIVI OS', '-metadata', 'album=Demo',
             '-id3v2_version', '3', os.path.join(OUT, 'data', 'music', 'krivi_demo.mp3')], check=True)
    # 8 s colour-bar test movie with a sweeping tone, in the exact format convert_media.py makes
    _sp.run([ff, '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc2=size=320x240:rate=15',
             '-f', 'lavfi', '-i', "aevalsrc=0.4*sin(2*PI*(220+110*t)*t):s=22050", '-t', '8',
             '-c:v', 'mjpeg', '-q:v', '8', '-pix_fmt', 'yuvj420p', '-c:a', 'pcm_u8', '-ar', '22050', '-ac', '1',
             '-f', 'avi', os.path.join(OUT, 'data', 'movies', 'krivi_test_pattern.avi')], check=True)
    _sh.rmtree(tmp, ignore_errors=True)

# --------------------------------------------------------------------------- texts
def manual_text(apps):
    L = ["KRIVI OS - SYSTEM MANUAL & DIRECTORY", "=" * 36, "",
         "Board: ESP32-2432S028 'Cheap Yellow Display', 2.8in 320x240, XPT2046 touch.",
         "71 apps on a 4x3 grid (12 per page, 6 pages). All apps are now implemented.",
         "Wireless Lab tools are passive: they listen to public Wi-Fi/BLE traffic",
         "(frame counts only, never contents) or probe your OWN network. Nothing",
         "here transmits attack frames, captures payloads or impersonates a network.",
         "Exit any app with the red EXIT box in the top-right corner (X 260-315, Y 4-22).",
         "Long-press an icon on the home screen to see what it needs and how it works.",
         "Swipe left/right or use < > to change pages.", ""]
    for p in range(5):
        L += [f"PAGE {p + 1}/5: {PAGE_TITLES[p]}", "-" * 40]
        for a in apps:
            if a['page'] == p:
                L += [f"App {a['id']:02d}: {a['name']}", f"  Needs: {a['needs']}", f"  {a['help']}", ""]
    L += ["WIRING NOTES", "-" * 40,
          "Speaker: 8 ohm 1-2 W speaker on the SPEAK connector (GPIO26 DAC via on-board amp).",
          "Microphone: analog mic module (e.g. MAX4466/MAX9814) OUT -> IO35 on P3, VCC 3.3V, GND.",
          "Relay / LED for Clap Switch: IO22 on CN1 (3.3V logic; use a relay module with transistor).",
          "Raspberry Pi: USB cable from the Pi to the CYD; run tools/pi/krivi_bridge.py on the Pi.",
          "Second board for ESP-NOW: any ESP32 running KRIVI OS, same channel (default 1).", ""]
    return "\n".join(L)

WELCOME = """Welcome to KRIVI OS
===================

This is the e-book reader of app 43 (System Manual). Any .txt file you copy
into /data/reader appears in the LIBRARY tab. Tap the right half of the page
or swipe left for the next page, the left half or swipe right to go back.

Files written by the Text Editor (app 22) are saved here too, so you can
draft notes on the device and read them back later.

Tips
- Edit /sys/settings.json on a computer to add your Wi-Fi network; the clock
  then syncs over NTP right after boot.
- Each app has a manifest in /sys/apps/app_NN.json. Its "params" block tunes
  the app (metronome tempo, ping host, macro keys...). Add "bin": "/apps/x.bin"
  to make the launcher flash an external firmware image instead.
- Boot diagnostics are saved to /sys/boot/boot_last.log, and every app launch
  is recorded in /sys/boot/session.log with its heap before and after.
"""


# --------------------------------------------------------------------------- weather icons
WX_BG = (12, 16, 28)
WX_NAMES = ["clear_day", "clear_night", "partly_day", "partly_night", "cloudy",
            "fog", "drizzle", "rain", "snow", "thunder"]

def _wx_scene(dr, S, name):
    import math as _m
    cx = cy = S // 2
    sun = (255, 200, 60); sun2 = (255, 150, 30)
    moon = (225, 230, 245); cloud = (200, 208, 224); cloud2 = (150, 160, 182)
    dark = (120, 128, 150); rain = (90, 160, 255); snow = (240, 248, 255); bolt = (255, 216, 40)
    def disc(x, y, r, col):
        dr.ellipse([x - r, y - r, x + r, y + r], fill=col)
    def cloud_at(x, y, r, col, col_s):
        dr.ellipse([x - int(r * 1.6), y - r // 3, x - int(r * 0.4), y + r], fill=col_s)
        disc(x - r, y, int(r * 0.7), col); disc(x + r, y, int(r * 0.8), col)
        disc(x, y - int(r * 0.6), int(r * 0.95), col)
        dr.rounded_rectangle([x - int(r * 1.6), y, x + int(r * 1.7), y + r], radius=r, fill=col)
    night = "night" in name
    hassun = "clear" in name or "partly" in name
    off = "partly" in name
    if hassun:
        sx = cx - (S // 6 if off else 0); sy = cy - (S // 6 if off else 0); r = S // 6
        if night:
            disc(sx, sy, r, moon); disc(sx + r // 2, sy - r // 3, r, WX_BG)
            for dx, dy in [(r, -r), (int(r * 1.4), 0)]:
                dr.polygon([(sx + dx, sy + dy - 3), (sx + dx + 3, sy + dy), (sx + dx, sy + dy + 3), (sx + dx - 3, sy + dy)], fill=moon)
        else:
            for a in range(12):
                t = a * _m.pi / 6
                dr.line([sx + _m.cos(t) * r * 1.25, sy + _m.sin(t) * r * 1.25,
                         sx + _m.cos(t) * r * 1.75, sy + _m.sin(t) * r * 1.75], fill=sun2, width=max(2, S // 40))
            disc(sx, sy, r, sun); disc(sx - r // 4, sy - r // 4, r // 2, (255, 230, 150))
    if "clear" not in name:
        r = S // 7
        if name == "cloudy":
            cloud_at(cx + S // 10, cy + S // 10, r, cloud2, (110, 120, 142))
            cloud_at(cx - S // 12, cy - S // 12, r, cloud, cloud2)
        else:
            cloud_at(cx + (S // 8 if off else 0), cy + (S // 8 if off else S // 14),
                     r, cloud if "thunder" not in name else (120, 128, 150),
                     cloud2 if "thunder" not in name else (80, 86, 104))
    base = cy + S // 5
    if "rain" in name:
        for i in range(-1, 2):
            x = cx + i * S // 7 + (S // 8 if off else 0)
            dr.line([x, base, x - S // 14, base + S // 7], fill=rain, width=max(2, S // 36))
    if "drizzle" in name:
        for i in range(-1, 2):
            x = cx + i * S // 8 + (S // 8 if off else 0)
            dr.line([x, base, x - S // 22, base + S // 12], fill=(140, 190, 255), width=max(2, S // 44))
    if "snow" in name:
        rr = max(4, S // 26)
        for j, i in enumerate([-1, 0, 1, 0]):
            x = cx + i * S // 6 + (S // 8 if off else 0)
            y = base + (S // 10 if j == 3 else 0)
            dr.ellipse([x - rr, y - rr, x + rr, y + rr], fill=snow)
            dr.line([x - rr, y, x + rr, y], fill=(150, 200, 255), width=2)
            dr.line([x, y - rr, x, y + rr], fill=(150, 200, 255), width=2)
    if "thunder" in name:
        x = cx + (S // 8 if off else 0)
        dr.polygon([(x, base - S // 12), (x - S // 12, base + S // 10), (x, base + S // 14),
                    (x - S // 20, base + S // 5), (x + S // 9, base - S // 40), (x + S // 60, base - S // 40)], fill=bolt)
    if "fog" in name:
        for i in range(3):
            y = base + i * S // 12
            dr.line([cx - S // 4, y, cx + S // 4, y], fill=dark, width=max(2, S // 40))

def _wx_save(name, size, path):
    from PIL import Image, ImageDraw
    SS = size * 4
    im = Image.new('RGB', (SS, SS), WX_BG)
    _wx_scene(ImageDraw.Draw(im), SS, name)
    im = im.resize((size, size), Image.LANCZOS)
    px = im.tobytes()
    raw = bytearray()
    for i in range(0, len(px), 3):
        v = ((px[i] & 0xF8) << 8) | ((px[i + 1] & 0xFC) << 3) | (px[i + 2] >> 3)
        raw += struct.pack('<H', v)
    open(path, 'wb').write(raw)

def make_weather_icons(apps):
    try:
        from PIL import Image
    except ImportError:
        print('  ! Pillow missing - weather icons skipped (firmware draws vector fallbacks)')
        return
    d = mk('icons', 'weather')
    for nm in WX_NAMES:
        _wx_save(nm, 80, os.path.join(d, nm + '_lg.raw'))
        _wx_save(nm, 40, os.path.join(d, nm + '_sm.raw'))
    # give the Weather app a real scene on the home grid instead of the "WX" text
    try:
        _wx_save('partly_day', 40, os.path.join(OUT, 'icons', 'app_51.raw'))
    except Exception:
        pass
    print(f'  weather: {len(WX_NAMES) * 2} icons in icons/weather')

def main():
    apps = load_registry()
    print(f'Building SD tree in {os.path.abspath(OUT)}  ({len(apps)} apps)')
    for p in ['sys/boot', 'sys/apps', 'icons', 'roms', 'apps', 'data/paint', 'data/chiptunes', 'data/reader',
              'data/video', 'data/music', 'data/movies', 'icons/weather']:
        mk(*p.split('/'))
    json.dump(SETTINGS, open(os.path.join(OUT, 'sys', 'settings.json'), 'w'), indent=2)
    json.dump({"USD": 1.0, "EUR": 0.92, "GBP": 0.79, "JPY": 150.0, "CAD": 1.36, "AUD": 1.52,
               "INR": 83.2, "CNY": 7.24, "MXN": 17.1, "BRL": 5.05, "CHF": 0.88, "KRW": 1330.0,
               "_note": "edit these USD-relative rates for the Currency Converter (app 66)"},
              open(os.path.join(OUT, 'sys', 'rates.json'), 'w'), indent=2)
    for a in apps:
        m = {"id": a['id'], "name": a['name'], "page": a['page'] + 1, "requires": a['needs']}
        m.update(MANIFESTS.get(a['id'], {}))
        json.dump(m, open(os.path.join(OUT, 'sys', 'apps', f"app_{a['id']:02d}.json"), 'w'), indent=2)
    open(os.path.join(OUT, 'sys', 'boot', 'README.txt'), 'w').write("Boot and session logs are written here by KRIVI OS.\n")
    open(os.path.join(OUT, 'roms', 'README.txt'), 'w').write(
        "Copy your own legally-dumped NES ROMs here (e.g. mario.nes, tetris.nes).\n"
        "Supported: iNES mapper 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM); PRG+CHR must fit in RAM (~96 KB).\n")
    open(os.path.join(OUT, 'apps', 'README.txt'), 'w').write(
        "Optional external firmware images (.bin) for the binary launcher.\n"
        "Reference one from a manifest: \"bin\": \"/apps/myapp.bin\". Max 1.56 MB (ota_1 slot).\n"
        "Include tools/krivi_return.h in that firmware so it can hand control back to KRIVI OS.\n")
    open(os.path.join(OUT, 'data', 'video', 'README.txt'), 'w').write(
        "Motion-JPEG clips for the Video Player (app 40). Convert any video you own with:\n"
        "  ffmpeg -i input.mp4 -vf \"fps=20,scale=320:240:force_original_aspect_ratio=decrease\" -q:v 7 -an output.mjpeg\n"
        "Keep each JPEG frame under 40 KB (raise -q:v if frames are dropped).\n")
    open(os.path.join(OUT, 'data', 'music', 'README.txt'), 'w').write(
        "MP3 files for the MP3 Music Player (app 44). Any bitrate, 32/44.1/48 kHz, mono or stereo.\n"
        "Songs in this folder play in order; ID3v2 title/artist/album tags are shown.\n"
        "Other formats: python3 tools/convert_media.py song.flac --sd <card>\n")
    open(os.path.join(OUT, 'data', 'movies', 'README.txt'), 'w').write(
        "Movies for the Video & MP4 Player (app 40).\n"
        "The ESP32 cannot decode MP4/H.264 directly, so convert on a computer:\n"
        "  python3 tools/convert_media.py my_video.mp4 --sd <card>\n"
        "This writes an .avi (Motion-JPEG 320x240 @15 fps + 22 kHz audio) that plays with sound.\n")
    make_demo_media()
    open(os.path.join(OUT, 'data', 'paint', 'README.txt'), 'w').write("Sketchpad (app 35) saves 320x170 16-colour .bmp files here.\n")
    open(os.path.join(OUT, 'data', 'reader', 'KRIVI_MANUAL.txt'), 'w').write(manual_text(apps))
    open(os.path.join(OUT, 'data', 'reader', 'WELCOME.txt'), 'w').write(WELCOME)
    make_mod(os.path.join(OUT, 'data', 'chiptunes', 'krivi_theme.mod'))
    make_icons(apps)
    make_weather_icons(apps)
    print('Done. Copy the contents of the folder to the root of a FAT32 microSD card.')

if __name__ == '__main__':
    main()
