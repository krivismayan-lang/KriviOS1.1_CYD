#!/bin/bash
echo "== $(hostname) =="
vcgencmd measure_temp 2>/dev/null || true
vcgencmd get_throttled 2>/dev/null || true
free -h | awk 'NR<=2'
df -h / | awk 'NR==2 {print "disk / : "$3" used of "$2" ("$5")"}'
ip -4 -o addr show | awk '{print $2": "$4}'
