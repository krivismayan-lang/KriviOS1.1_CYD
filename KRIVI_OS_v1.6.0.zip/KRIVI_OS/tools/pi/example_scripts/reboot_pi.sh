#!/bin/bash
# Needs: USERNAME ALL=(root) NOPASSWD: /sbin/reboot
echo "Rebooting in 3 s..."
sleep 3
sudo -n /sbin/reboot || echo "add a sudoers entry for /sbin/reboot"
