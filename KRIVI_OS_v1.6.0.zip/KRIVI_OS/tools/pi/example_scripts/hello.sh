#!/bin/bash
# Smallest possible KRIVI console script
echo "Hello from $(hostname) - $(date '+%H:%M:%S')"
uptime -p
