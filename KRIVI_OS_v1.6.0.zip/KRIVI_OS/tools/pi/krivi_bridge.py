#!/usr/bin/env python3
"""
KRIVI OS <-> Raspberry Pi bridge
================================
Runs on the Raspberry Pi. Talks to the CYD over the USB serial cable and serves:

  App 27  Pi Performance Monitor   @STATS 1/0  ->  @STAT cpu=.. temp=.. ram=.. ...
  App 28  Pi Bash Console          @LIST / @RUN name / @KILL  ->  @SCRIPT / @OUT / @EXIT
  App 29  Pi Remote Trackpad       @MOVE dx dy / @CLICK L|R|M / @SCROLL n

Only executables inside the scripts folder (default ~/krivi_scripts) can be
run - the CYD sends a *name*, never a command line.

Install:
  sudo apt install python3-serial python3-psutil python3-evdev
  sudo usermod -aG dialout,input $USER          # serial + uinput access, then re-login
  python3 krivi_bridge.py                        # auto-detects /dev/ttyUSB* / ttyACM*
Run at boot: see krivi-bridge.service in this folder.
"""
import argparse, glob, os, re, shutil, socket, subprocess, sys, threading, time

try:
    import serial
except ImportError:
    sys.exit("pyserial missing:  sudo apt install python3-serial")
try:
    import psutil
except ImportError:
    psutil = None
try:
    from evdev import UInput, ecodes as E
except ImportError:
    UInput = None


def log(*a):
    print(time.strftime('%H:%M:%S'), *a, flush=True)


# ------------------------------------------------------------------ stats
class Stats:
    def __init__(self):
        self.prev = None

    def cpu(self):
        if psutil:
            return psutil.cpu_percent(interval=None)
        with open('/proc/stat') as f:
            v = list(map(int, f.readline().split()[1:]))
        idle, total = v[3] + v[4], sum(v)
        if not self.prev:
            self.prev = (idle, total)
            return 0.0
        di, dt = idle - self.prev[0], total - self.prev[1]
        self.prev = (idle, total)
        return 100.0 * (1 - di / dt) if dt else 0.0

    @staticmethod
    def temp():
        for p in glob.glob('/sys/class/thermal/thermal_zone*/temp'):
            try:
                return int(open(p).read()) / 1000.0
            except Exception:
                pass
        return 0.0

    @staticmethod
    def ram():
        info = {}
        for line in open('/proc/meminfo'):
            k, v = line.split(':')
            info[k] = int(v.split()[0])
        total, avail = info.get('MemTotal', 1), info.get('MemAvailable', 0)
        return 100.0 * (total - avail) / total, total // 1024

    def line(self):
        ram, ramtot = self.ram()
        du = shutil.disk_usage('/')
        up = float(open('/proc/uptime').read().split()[0])
        return ('STAT cpu=%.1f temp=%.1f ram=%.1f ramtot=%d disk=%.0f load=%.2f up=%d host=%s'
                % (self.cpu(), self.temp(), ram, ramtot, 100.0 * du.used / du.total,
                   os.getloadavg()[0], up, socket.gethostname()))


# ------------------------------------------------------------------ mouse
class Mouse:
    def __init__(self):
        self.ui = None
        if UInput:
            try:
                caps = {E.EV_KEY: [E.BTN_LEFT, E.BTN_RIGHT, E.BTN_MIDDLE],
                        E.EV_REL: [E.REL_X, E.REL_Y, E.REL_WHEEL]}
                self.ui = UInput(caps, name='KRIVI CYD trackpad')
                log('mouse: uinput device created')
            except Exception as e:
                log('mouse: uinput unavailable (%s) - trying xdotool' % e)
        self.xdotool = shutil.which('xdotool')

    def move(self, dx, dy):
        if self.ui:
            self.ui.write(E.EV_REL, E.REL_X, dx); self.ui.write(E.EV_REL, E.REL_Y, dy); self.ui.syn()
        elif self.xdotool:
            subprocess.run([self.xdotool, 'mousemove_relative', '--', str(dx), str(dy)])

    def click(self, b):
        btn = {'L': 1, 'M': 2, 'R': 3}.get(b, 1)
        if self.ui:
            code = {1: E.BTN_LEFT, 2: E.BTN_MIDDLE, 3: E.BTN_RIGHT}[btn]
            self.ui.write(E.EV_KEY, code, 1); self.ui.syn()
            self.ui.write(E.EV_KEY, code, 0); self.ui.syn()
        elif self.xdotool:
            subprocess.run([self.xdotool, 'click', str(btn)])

    def scroll(self, n):
        if self.ui:
            self.ui.write(E.EV_REL, E.REL_WHEEL, n); self.ui.syn()
        elif self.xdotool:
            subprocess.run([self.xdotool, 'click', '--repeat', str(abs(n)), '4' if n > 0 else '5'])


# ------------------------------------------------------------------ bridge
class Bridge:
    NAME_OK = re.compile(r'^[A-Za-z0-9._-]{1,64}$')

    def __init__(self, port, baud, scripts):
        self.scripts = os.path.abspath(os.path.expanduser(scripts))
        os.makedirs(self.scripts, exist_ok=True)
        self.ser = serial.Serial()
        self.ser.port, self.ser.baudrate, self.ser.timeout = port, baud, 0.2
        self.ser.dtr = False           # do NOT pulse EN/IO0 -> avoids resetting the CYD
        self.ser.rts = False
        self.ser.open()
        self.lock = threading.Lock()
        self.stats_on = False
        self.stats = Stats()
        self.mouse = Mouse()
        self.proc = None
        self.ps_on = False
        self.allow_shell = True        # Pi Shell / SSH Shortcuts / htop / power
        log('bridge: listening on %s @ %d, scripts in %s' % (port, baud, self.scripts))

    def send(self, s):
        with self.lock:
            self.ser.write(('@' + s + '\n').encode('utf-8', 'replace'))

    def script_list(self):
        out = []
        for n in sorted(os.listdir(self.scripts)):
            p = os.path.join(self.scripts, n)
            if os.path.isfile(p) and (os.access(p, os.X_OK) or n.endswith('.sh')) and self.NAME_OK.match(n):
                out.append(n)
        return out

    def run_script(self, name):
        if self.proc and self.proc.poll() is None:
            self.send('ERR a script is already running'); return
        if not self.NAME_OK.match(name) or name not in self.script_list():
            self.send('ERR not allowed: ' + name[:40]); return
        path = os.path.join(self.scripts, name)
        cmd = [path] if os.access(path, os.X_OK) else ['/bin/bash', path]
        log('run:', cmd)
        self.proc = subprocess.Popen(cmd, cwd=self.scripts, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, bufsize=1)

        def pump(p):
            for line in p.stdout:
                self.send('OUT ' + line.rstrip()[:120])
            self.send('EXIT %d' % p.wait())
        threading.Thread(target=pump, args=(self.proc,), daemon=True).start()

    def run_command(self, cmdline):
        # App 68 (Pi Shell) / 69 (SSH Shortcuts): run an arbitrary command on
        # THIS Pi (the user's own device, over the local USB cable).
        if not self.allow_shell:
            self.send('ERR shell disabled (start bridge without --no-shell)'); return
        if self.proc and self.proc.poll() is None:
            self.send('ERR a command is already running'); return
        log('cmd:', cmdline)
        self.proc = subprocess.Popen(['/bin/bash', '-lc', cmdline], cwd=os.path.expanduser('~'),
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)

        def pump(p):
            for line in p.stdout:
                self.send('OUT ' + line.rstrip()[:120])
            self.send('EXIT %d' % p.wait())
        threading.Thread(target=pump, args=(self.proc,), daemon=True).start()

    def power(self, what):
        if not self.allow_shell:
            self.send('ERR shell disabled'); return
        cmd = 'sudo -n /sbin/shutdown -h now' if what == 'shutdown' else 'sudo -n /sbin/reboot'
        log('power:', what)
        r = subprocess.run(['/bin/bash', '-c', cmd], stderr=subprocess.PIPE, text=True)
        if r.returncode:
            self.send('OUT needs sudoers: ' + (r.stderr.strip()[:90] or cmd))

    def ps_loop(self):
        while True:
            if self.ps_on:
                try:
                    out = subprocess.run(['ps', '-eo', 'pid,pcpu,pmem,comm', '--sort=-pcpu'],
                                         stdout=subprocess.PIPE, text=True).stdout.splitlines()[1:15]
                    self.send('PSBEGIN')
                    for ln in out:
                        f = ln.split(None, 3)
                        if len(f) >= 4:
                            self.send('PS %s %s %s %s' % (f[0], f[1], f[2], f[3][:24]))
                    self.send('PSEND')
                except Exception as e:
                    log('ps error', e)
            time.sleep(2)

    def stats_loop(self):
        while True:
            if self.stats_on:
                try:
                    self.send(self.stats.line())
                except Exception as e:
                    log('stats error', e)
            time.sleep(1)

    def handle(self, line):
        parts = line[1:].split(' ', 1)
        cmd, arg = parts[0].upper(), (parts[1] if len(parts) > 1 else '')
        if cmd == 'STATS':
            self.stats_on = arg.strip() == '1'
        elif cmd == 'LIST':
            for n in self.script_list():
                self.send('SCRIPT ' + n)
            self.send('END')
        elif cmd == 'RUN':
            self.run_script(arg.strip())
        elif cmd == 'KILL':
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
        elif cmd == 'MOVE':
            dx, dy = (int(v) for v in arg.split()[:2])
            self.mouse.move(max(-500, min(500, dx)), max(-500, min(500, dy)))
        elif cmd == 'CLICK':
            self.mouse.click(arg.strip()[:1].upper() or 'L')
        elif cmd == 'SCROLL':
            self.mouse.scroll(int(arg))
        elif cmd == 'CMD':
            self.run_command(arg)
        elif cmd == 'PS':
            self.ps_on = arg.strip() == '1'
        elif cmd == 'POWER':
            self.power(arg.strip().lower())

    def loop(self):
        threading.Thread(target=self.stats_loop, daemon=True).start()
        threading.Thread(target=self.ps_loop, daemon=True).start()
        buf = b''
        while True:
            chunk = self.ser.read(256)
            if not chunk:
                continue
            buf += chunk
            while b'\n' in buf:
                raw, buf = buf.split(b'\n', 1)
                line = raw.decode('utf-8', 'replace').strip()
                if line.startswith('@'):
                    try:
                        self.handle(line)
                    except Exception as e:
                        log('bad command %r: %s' % (line, e))
                elif line:
                    log('cyd:', line)          # KRIVI debug/log output


def find_port():
    for pat in ('/dev/serial/by-id/*CH34*', '/dev/serial/by-id/*', '/dev/ttyUSB*', '/dev/ttyACM*'):
        hits = sorted(glob.glob(pat))
        if hits:
            return hits[0]
    return None


def main():
    ap = argparse.ArgumentParser(description='KRIVI OS Raspberry Pi bridge')
    ap.add_argument('--port', default=None, help='serial port (auto-detect)')
    ap.add_argument('--no-shell', action='store_true', help='disable the Pi Shell / power commands')
    ap.add_argument('--baud', type=int, default=115200)
    ap.add_argument('--scripts', default='~/krivi_scripts', help='whitelisted script folder')
    a = ap.parse_args()
    while True:
        port = a.port or find_port()
        if not port:
            log('waiting for the CYD to be plugged in...')
            time.sleep(3)
            continue
        try:
            br = Bridge(port, a.baud, a.scripts); br.allow_shell = not a.no_shell; br.loop()
        except (serial.SerialException, OSError) as e:
            log('serial error: %s - retrying' % e)
            time.sleep(3)


if __name__ == '__main__':
    main()
