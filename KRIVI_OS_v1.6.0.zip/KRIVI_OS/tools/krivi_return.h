// ============================================================================
//  krivi_return.h - include in an EXTERNAL firmware that KRIVI OS launches in
//  binary mode ("bin" in /sys/apps/app_NN.json). Call kriviReturn() (for
//  example when the user taps the top-right corner) to reboot back into the
//  KRIVI OS launcher that lives in the ota_0 partition.
//
//  Build the external firmware with the same partitions.csv as KRIVI OS and
//  keep it under 1.56 MB (size of the ota_1 slot).
//
//  Recovery if an external app never calls kriviReturn():
//    esptool.py --chip esp32 erase_region 0xe000 0x2000   (clears otadata ->
//    the bootloader falls back to ota_0 = KRIVI OS)
// ============================================================================
#pragma once
#include <esp_ota_ops.h>
#include <esp_system.h>

inline void kriviReturn() {
  const esp_partition_t *p = esp_partition_find_first(ESP_PARTITION_TYPE_APP,
                                                      ESP_PARTITION_SUBTYPE_APP_OTA_0, nullptr);
  if (p) esp_ota_set_boot_partition(p);
  esp_restart();
}
