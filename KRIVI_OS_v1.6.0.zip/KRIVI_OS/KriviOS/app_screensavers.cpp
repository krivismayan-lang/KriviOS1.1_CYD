// ============================================================================
//  72  Matrix Digital Rain      73  Starfield Screensaver
// ============================================================================
#include "apps_common.h"

// ---------------------------------------------------------------- 72 Matrix Rain
void app_matrix(AppCtx &c) {
  const int CW = 8, CH = 12, COLS = 320 / CW, ROWS = 240 / CH;   // 40 x 20
  int16_t drop[40]; uint8_t spd[40];
  for (int i = 0; i < COLS; ++i) { drop[i] = -rnd(ROWS); spd[i] = 1 + rnd(3); }
  tft.fillScreen(TFT_BLACK);
  tft.setTextFont(1);
  auto glyph = [&]() -> char { int r = rnd(3); return r == 0 ? '0' + rnd(10) : r == 1 ? 'A' + rnd(26) : 33 + rnd(14); };
  uint32_t last = millis();
  while (c.loop()) {
    if (millis() - last < 55) { delay(3); continue; }
    last = millis();
    for (int i = 0; i < COLS; ++i) {
      int y = drop[i];
      if (y >= 0 && y < ROWS) {
        // dim the previous head to trail green
        char s[2] = {glyph(), 0};
        tft.setTextColor(RGB565(180, 255, 180), TFT_BLACK); tft.drawString(s, i * CW, y * CH, 1);   // bright head
        if (y > 0) { s[0] = glyph(); tft.setTextColor(RGB565(0, 160, 0), TFT_BLACK); tft.drawString(s, i * CW, (y - 1) * CH, 1); }
        if (y > 6) { tft.fillRect(i * CW, (y - 7) * CH, CW, CH, TFT_BLACK); }          // erase tail end
      }
      drop[i] += 1;
      if (drop[i] - 7 > ROWS) { drop[i] = -rnd(8); spd[i] = 1 + rnd(3); }
    }
  }
}

// ---------------------------------------------------------------- 73 Starfield
void app_starfield(AppCtx &c) {
  const int N = 260;
  struct S { float x, y, z; int16_t px, py; };
  S *st = (S *)malloc(sizeof(S) * N);
  if (!st) return;
  auto spawn = [&](S &s) { s.x = (rnd(2000) - 1000); s.y = (rnd(2000) - 1000); s.z = 1 + rnd(1000); s.px = -1; };
  for (int i = 0; i < N; ++i) spawn(st[i]);
  float speed = 8;
  tft.fillScreen(TFT_BLACK);
  uint32_t fpsT = millis(); int frames = 0;
  while (c.frame(16)) {
    Touch &t = *c.t;
    if (t.swipe == SW_UP) speed = min(30.f, speed + 4); if (t.swipe == SW_DOWN) speed = max(2.f, speed - 4);
    for (int i = 0; i < N; ++i) {
      S &s = st[i];
      if (s.px >= 0) tft.drawPixel(s.px, s.py, TFT_BLACK);
      s.z -= speed;
      if (s.z < 1) { spawn(s); continue; }
      int px = 160 + (int)(s.x / s.z * 160);
      int py = 120 + (int)(s.y / s.z * 160);
      if (px < 0 || px >= 320 || py < 26 || py >= 240) { spawn(s); continue; }
      uint8_t b = (uint8_t)constrain(255 - s.z / 4, 40, 255);
      tft.drawPixel(px, py, RGB565(b, b, b));
      if (s.z < 120) tft.drawPixel(px + 1, py, RGB565(b, b, b));
      s.px = px; s.py = py;
    }
    if (++frames && millis() - fpsT > 1000) { hudf("%d fps", frames); frames = 0; fpsT = millis(); }
  }
  free(st);
}
