// ============================================================================
//  Raspberry Pi apps (need tools/pi/krivi_bridge.py on the Pi)
//   68 Pi Shell Keyboard   69 SSH Action Shortcuts   70 htop Monitor   71 Pi Safe Shutdown
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  68  PI SHELL KEYBOARD  - type a command, stream the output back
// ============================================================================
void app_pishell(AppCtx &c) {
  std::vector<String> term;
  ui::Keyboard kb; kb.y0 = 150;
  String cmdline;
  bool running = false;
  const int TY = 44, TL = 8;
  auto drawTerm = [&]() {
    tft.fillRect(0, TY, 320, 100, TFT_BLACK);
    int first = max(0, (int)term.size() - TL);
    for (int i = first; i < (int)term.size(); ++i) {
      const String &s = term[i];
      tft.setTextColor(s.startsWith("$") ? C_ACCENT : s.startsWith("!") ? C_ERR : RGB565(170, 255, 190), TFT_BLACK);
      tft.drawString(s.substring(0, 53), 2, TY + 2 + (i - first) * 12, 1);
    }
  };
  auto prompt = [&]() { tft.fillRect(0, 28, 320, 15, C_PANEL); tft.setTextColor(C_TEXT, C_PANEL);
    tft.drawString(("$ " + cmdline).substring(0, 52), 4, 30, 2); };
  auto addLine = [&](const String &s) { term.push_back(s); if (term.size() > 60) term.erase(term.begin()); drawTerm(); };
  ui::clearBody(); kb.draw(); prompt();
  addLine("Type a command and press ENTER. Runs on the Pi via krivi_bridge.py.");
  while (c.loop()) {
    String l;
    while (pilink::readLine(l)) {
      if (l.startsWith("@OUT ")) addLine(l.substring(5));
      else if (l.startsWith("@EXIT ")) { running = false; addLine("! exit " + l.substring(6)); }
      else if (l.startsWith("@ERR ")) { running = false; addLine("! " + l.substring(5)); }
    }
    Touch &t = *c.t;
    if (!t.pressed) continue;
    if (t.y < kb.y0) continue;
    int k = kb.hit(t.x, t.y);
    if (!k) continue;
    if (k == ui::Keyboard::K_ENTER) {
      if (cmdline.length() && !running) { addLine("$ " + cmdline); pilink::send("CMD %s", cmdline.c_str()); running = true; cmdline = ""; prompt(); }
    } else if (k == ui::Keyboard::K_BKSP) { if (cmdline.length()) { cmdline.remove(cmdline.length() - 1); prompt(); } }
    else if (k >= 32) { if (cmdline.length() < 80) { cmdline += (char)k; prompt(); } }
  }
  if (running) pilink::send("KILL");
}

// ============================================================================
//  69  SSH ACTION SHORTCUTS  - one-tap remote commands
// ============================================================================
void app_sshactions(AppCtx &c) {
  struct Act { String label, cmd; };
  std::vector<Act> acts;
  JsonArray arr = c.params["actions"].as<JsonArray>();
  if (!arr.isNull()) for (JsonObject o : arr) acts.push_back({String(o["label"] | "cmd"), String(o["cmd"] | "true")});
  if (acts.empty()) { const char *L[6] = {"Uptime", "Disk free", "Who", "IP addr", "Update apt", "Reboot svc"};
    const char *CM[6] = {"uptime", "df -h /", "who", "ip -4 -o addr", "sudo apt update", "echo edit app_69.json"};
    for (int i = 0; i < 6; ++i) acts.push_back({L[i], CM[i]}); }
  std::vector<String> out;
  auto drawOut = [&]() { tft.fillRect(0, 150, 320, 90, TFT_BLACK);
    int first = max(0, (int)out.size() - 7);
    for (int i = first; i < (int)out.size(); ++i) { tft.setTextColor(out[i].startsWith("$") ? C_ACCENT : RGB565(170, 255, 190), TFT_BLACK);
      tft.drawString(out[i].substring(0, 53), 2, 152 + (i - first) * 12, 1); } };
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("One-tap commands (edit in app_69.json)", 6, 28, 1);
  for (int i = 0; i < (int)acts.size() && i < 9; ++i) ui::button(4 + (i % 3) * 104, 42 + (i / 3) * 34, 100, 30, acts[i].label.substring(0, 12).c_str(), RGB565(0, 90, 130), TFT_WHITE, 2);
  while (c.loop()) {
    String l; while (pilink::readLine(l)) { if (l.startsWith("@OUT ")) { out.push_back(l.substring(5)); if (out.size() > 40) out.erase(out.begin()); drawOut(); }
      else if (l.startsWith("@EXIT ")) { out.push_back("$ done"); drawOut(); } }
    Touch &t = *c.t;
    if (!t.tap) continue;
    for (int i = 0; i < (int)acts.size() && i < 9; ++i) if (ui::inRect(t.sx, t.sy, 4 + (i % 3) * 104, 42 + (i / 3) * 34, 100, 30)) {
      out.push_back("$ " + acts[i].label); drawOut(); pilink::send("CMD %s", acts[i].cmd.c_str()); audio::click(); }
  }
}

// ============================================================================
//  70  HTOP LIVE MONITOR
// ============================================================================
void app_htop(AppCtx &c) {
  struct Proc { int pid; float cpu, mem; String name; };
  std::vector<Proc> procs;
  uint32_t lastReq = 0, lastRx = 0; bool online = false;
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("PID    CPU%   MEM%   COMMAND", 6, 44, 1);
  auto draw = [&]() {
    tft.fillRect(0, 56, 320, 182, C_BG);
    for (int i = 0; i < (int)procs.size() && i < 14; ++i) { Proc &p = procs[i]; int y = 56 + i * 13;
      char s[64]; snprintf(s, 64, "%-6d %5.1f  %5.1f  %s", p.pid, p.cpu, p.mem, p.name.substring(0, 24).c_str());
      tft.setTextColor(p.cpu > 50 ? C_ERR : p.cpu > 15 ? C_WARN : C_TEXT, C_BG); tft.drawString(s, 6, y, 1); }
  };
  hud("linking...", C_WARN);
  pilink::send("PS 1");
  while (c.loop()) {
    if (millis() - lastReq > 4000) { lastReq = millis(); pilink::send("PS 1"); }
    String l;
    while (pilink::readLine(l)) {
      if (l.startsWith("@PSBEGIN")) procs.clear();
      else if (l.startsWith("@PS ")) { lastRx = millis(); if (!online) { online = true; hud("online", C_OK); }
        Proc p; char nm[40] = ""; if (sscanf(l.c_str() + 4, "%d %f %f %39[^\n]", &p.pid, &p.cpu, &p.mem, nm) >= 3) { p.name = nm; procs.push_back(p); } }
      else if (l.startsWith("@PSEND")) draw();
    }
    if (online && millis() - lastRx > 6000) { online = false; hud("link lost", C_ERR); }
  }
  pilink::send("PS 0");
}

// ============================================================================
//  71  PI SAFE SHUTDOWN
// ============================================================================
void app_pishutdown(AppCtx &c) {
  ui::clearBody();
  ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
  ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4);
  ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4);
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString("Sends a graceful command over USB (needs sudo in", 10, 196, 1);
  tft.drawString("the Pi's sudoers; see krivi_bridge notes).", 10, 208, 1);
  while (c.loop()) {
    Touch &t = *c.t;
    if (!t.tap) continue;
    if (ui::inRect(t.sx, t.sy, 40, 70, 240, 54)) {
      if (ui::confirm("SHUT DOWN", "Gracefully power off the connected Pi now?")) {
        pilink::send("POWER shutdown"); c.header(); ui::clearBody(); ui::toast("shutdown command sent", C_OK); delay(1500);
      } else { c.header(); ui::clearBody(); ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
        ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4); ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4); }
    } else if (ui::inRect(t.sx, t.sy, 40, 134, 240, 48)) {
      if (ui::confirm("REBOOT", "Reboot the connected Pi now?")) { pilink::send("POWER reboot"); c.header(); ui::clearBody(); ui::toast("reboot command sent", C_OK); delay(1500); }
      else { c.header(); ui::clearBody(); ui::centerText("Raspberry Pi Power", 160, 44, C_DIM, C_BG, 2);
        ui::button(40, 70, 240, 54, "SHUT DOWN PI", RGB565(180, 40, 40), TFT_WHITE, 4); ui::button(40, 134, 240, 48, "REBOOT PI", RGB565(180, 120, 0), TFT_WHITE, 4); }
    }
  }
}
