#include "apps_common.h"
#include <WiFi.h>
// ============================================================================
//  52  3D ISS GLOBE RADAR  - live International Space Station tracker on a
//      raycast, spinning Earth. Data: wheretheiss.at (free, no API key).
//      Per-pixel sphere geometry is precomputed once, so only the texture
//      rotation changes each frame -> smooth spin on the ESP32.
// ============================================================================
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

namespace iss {
static const uint8_t WORLD[648] = {170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,0,0,0,0,0,0,160,42,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,168,170,0,0,0,0,0,84,1,0,0,0,0,0,0,64,5,0,160,42,0,0,0,0,85,85,85,5,0,0,0,0,80,85,85,0,160,10,0,0,0,80,85,85,85,85,0,0,0,0,84,85,85,1,0,0,0,64,5,84,85,85,85,85,1,0,0,0,80,85,85,5,0,0,0,85,85,85,85,85,85,85,1,0,0,0,64,85,85,5,0,0,64,85,85,85,85,85,85,85,1,0,0,0,0,85,85,1,0,0,64,85,85,85,85,85,85,85,0,0,0,0,0,85,85,1,0,0,0,84,21,64,85,85,85,85,0,0,0,0,0,85,85,1,0,0,0,64,1,0,84,85,85,85,0,0,0,0,0,84,85,0,0,0,0,80,5,0,85,85,85,21,0,0,0,0,0,84,21,0,0,0,0,84,21,0,85,85,85,1,0,0,0,0,0,80,1,0,0,0,0,84,85,0,85,85,5,0,0,0,0,0,0,0,0,0,0,0,0,85,85,0,85,85,1,0,0,0,0,0,0,0,0,16,0,0,0,85,85,0,80,85,0,0,0,0,0,0,0,0,0,84,5,0,0,85,85,0,0,0,0,0,0,0,0,0,0,0,0,84,5,0,0,85,85,0,0,0,0,0,0,0,0,0,0,0,0,80,21,0,0,85,85,0,0,0,0,0,0,0,0,0,0,0,0,80,21,0,0,84,85,0,0,0,0,0,0,0,0,0,0,0,0,80,21,0,0,84,85,0,0,0,0,0,0,0,0,0,0,0,0,80,21,0,0,80,85,0,0,0,0,84,5,0,0,0,0,0,0,64,5,0,0,64,85,0,0,0,0,85,21,0,0,0,0,0,0,80,5,0,0,64,85,0,0,0,0,85,21,0,0,0,0,0,0,80,1,0,0,0,5,0,0,0,0,84,5,0,0,0,0,0,0,80,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,64,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170,170};
static inline int worldAt(int latDeg, int lonDeg) {
  while (lonDeg < -180) lonDeg += 360;
  while (lonDeg >= 180) lonDeg -= 360;
  int row = (int)((87.5f - latDeg) / 5.0f); row = constrain(row, 0, 35);
  int col = (lonDeg + 180) / 5; col = constrain(col, 0, 71);
  return (WORLD[row * 18 + (col >> 2)] >> ((col & 3) * 2)) & 3;
}
static bool fetch(float &lat, float &lon, float &alt, float &vel) {
  WiFiClientSecure cl; cl.setInsecure();
  HTTPClient http; http.setTimeout(6000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  if (!http.begin(cl, "https://api.wheretheiss.at/v1/satellites/25544")) return false;
  int code = http.GET();
  if (code != 200) { http.end(); return false; }
  String body = http.getString(); http.end();
  JsonDocument d;
  if (deserializeJson(d, body)) return false;
  float la = d["latitude"] | 0.0f, lo = d["longitude"] | 0.0f;
  if (la == 0.0f && lo == 0.0f) return false;            // bad-data filter
  lat = la; lon = lo; alt = d["altitude"] | alt; vel = d["velocity"] | vel;
  return true;
}
}  // namespace iss

void app_iss(AppCtx &c) {
  using namespace iss;
  const int BX = 12, BY = 48, SZ = 160, NG = 80;         // sprite box + sample grid
  const float CXl = 80, CYl = 80, R = 78;                // centre in sprite-local coords
  // ---- precompute per-sample geometry
  uint8_t *gValid = (uint8_t *)malloc(NG * NG);
  int16_t *gLon = (int16_t *)malloc(NG * NG * 2);
  int8_t  *gLat = (int8_t *)malloc(NG * NG);
  uint8_t *gSh = (uint8_t *)malloc(NG * NG);
  TFT_eSprite spr(&tft); spr.setColorDepth(16);
  bool haveSpr = gValid && gLon && gLat && gSh && spr.createSprite(SZ, SZ);
  if (!haveSpr) { free(gValid); free(gLon); free(gLat); free(gSh); if (spr.created()) spr.deleteSprite();
    c.header(); ui::msgBox("ISS GLOBE", "Not enough RAM for the globe."); return; }
  for (int gy = 0; gy < NG; ++gy) for (int gx = 0; gx < NG; ++gx) {
    int i = gy * NG + gx;
    float dx = (gx * 2 + 1 - CXl) / R, dy = (gy * 2 + 1 - CYl) / R;
    float d2 = dx * dx + dy * dy;
    if (d2 <= 1.0f) {
      float z = sqrtf(1 - d2);
      gValid[i] = 1;
      gSh[i] = (uint8_t)constrain(45 + 210 * z, 0, 255);
      gLat[i] = (int8_t)constrain((int)(asinf(-dy) * 57.2958f), -90, 90);
      gLon[i] = (int16_t)(atan2f(dx, z) * 57.2958f);
    } else if (d2 <= 1.20f) {
      gValid[i] = 2;                                      // atmosphere rim
      gSh[i] = (uint8_t)constrain((int)((1.20f - d2) / 0.20f * 180), 0, 180);
    } else gValid[i] = 0;
  }
  // static starfield (fixed screen positions)
  struct Star { uint8_t x, y; uint16_t c; };
  Star stars[46];
  for (auto &s : stars) { s.x = rnd(SZ); s.y = rnd(SZ); s.c = rnd(3) ? RGB565(80, 84, 96) : TFT_WHITE; }

  float issLat = 0, issLon = 0, alt = 420, vel = 27600; bool haveFix = false, online = false;
  float trailLat[10], trailLon[10]; int trailN = 0, trailHead = 0;
  float theta = 0, tilt = 0;
  uint32_t lastFetch = 0; bool fetching = false;
  int lastTx = -1, lastTy = -1; bool dragging = false;

  ui::clearBody(TFT_BLACK);
  c.header("live ISS tracker");
  // connect
  ui::centerText("Connecting WiFi...", 96, 128, C_WARN, TFT_BLACK, 2);
  if (sys::wifiConnect(10000, false)) online = true;
  tft.fillRect(0, 26, SZ + 16, 214, TFT_BLACK);

  auto hud = [&]() {
    int x = 180; tft.fillRect(x, 28, 140, 210, C_BG);
    tft.drawFastVLine(x - 2, 28, 210, C_PANEL2);
    tft.setTextColor(online ? C_OK : C_ERR, C_BG); tft.drawString(online ? "SYS LINK: ONLINE" : "SYS LINK: OFFLINE", x, 32, 1);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString("TARGET: ISS (25544)", x, 46, 1);
    char b[24];
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LAT", x, 66, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%+.3f", issLat); tft.drawString(b, x + 30, 66, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("LON", x, 80, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%+.3f", issLon); tft.drawString(b, x + 30, 80, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("ALT", x, 94, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%.0f km", alt); tft.drawString(b, x + 30, 94, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("VEL", x, 108, 1);
    tft.setTextColor(C_TEXT, C_BG); snprintf(b, 24, "%.0f km/h", vel); tft.drawString(b, x + 30, 108, 1);
    tft.setTextColor(haveFix ? C_OK : C_WARN, C_BG); tft.drawString(haveFix ? "TRACKING" : "acquiring...", x, 128, 1);
    tft.setTextColor(C_DIM, C_BG); tft.drawString("drag globe to spin", x, 210, 1);
    tft.drawString("wheretheiss.at", x, 224, 1);
  };
  hud();
  uint32_t frame = 0, hudT = 0;
  while (c.loop()) {
    Touch &t = *c.t;
    // touch drag within globe area -> spin / tilt
    if (t.down && t.x < 176) {
      if (lastTx >= 0) { theta += (t.x - lastTx) * 1.2f; tilt = constrain(tilt + (t.y - lastTy) * 0.8f, -80.f, 80.f); dragging = true; }
      lastTx = t.x; lastTy = t.y;
    } else { lastTx = -1; if (t.released) dragging = false; }
    if (!dragging) theta += 0.35f;                        // gentle auto-spin
    if (theta >= 360) theta -= 360; if (theta < 0) theta += 360;

    // fetch every 3 s
    if (online && millis() - lastFetch > 3000) {
      lastFetch = millis();
      float la = issLat, lo = issLon, al = alt, ve = vel;
      if (fetch(la, lo, al, ve)) {
        issLat = la; issLon = lo; alt = al; vel = ve; haveFix = true;
        trailLat[trailHead] = la; trailLon[trailHead] = lo; trailHead = (trailHead + 1) % 10; if (trailN < 10) trailN++;
      }
      hud();
    }
    frame++;

    // ---- render globe into the sprite
    spr.fillSprite(TFT_BLACK);
    for (auto &s : stars) spr.drawPixel(s.x, s.y, s.c);
    int itheta = (int)theta;
    for (int gy = 0; gy < NG; ++gy) {
      int sy = gy * 2;
      for (int gx = 0; gx < NG; ++gx) {
        int i = gy * NG + gx; uint8_t v = gValid[i];
        if (!v) continue;
        int sx = gx * 2;
        if (v == 2) { uint8_t a = gSh[i]; spr.fillRect(sx, sy, 2, 2, tft.alphaBlend(a, RGB565(90, 180, 255), TFT_BLACK)); continue; }
        int lon = gLon[i] - itheta;
        int w = worldAt(gLat[i] + (int)tilt, lon);
        uint8_t sh = gSh[i];
        uint16_t col;
        if (w == 2) col = tft.alphaBlend(sh, RGB565(240, 248, 255), TFT_BLACK);
        else if (w == 1) col = tft.alphaBlend(sh, RGB565(40, 165, 70), RGB565(10, 40, 20));
        else col = tft.alphaBlend(sh, RGB565(20, 70, 150), RGB565(0, 10, 40));
        spr.fillRect(sx, sy, 2, 2, col);
      }
    }
    // project a geo point to sprite coords; returns false if on far side
    auto project = [&](float la, float lo, int &ox, int &oy) -> bool {
      float latp = (la - tilt) * 0.0174533f, lonp = (lo + theta) * 0.0174533f;
      float cl = cosf(latp);
      float X = cl * sinf(lonp), Z = cl * cosf(lonp), Y = -sinf(latp);
      if (Z <= 0.02f) return false;
      ox = (int)(CXl + X * R); oy = (int)(CYl + Y * R);
      return true;
    };
    // trail
    for (int k = 0; k < trailN; ++k) {
      int idx = (trailHead - trailN + k + 20) % 10; int ox, oy;
      if (project(trailLat[idx], trailLon[idx], ox, oy)) {
        uint8_t a = 60 + k * 18;
        spr.fillCircle(ox, oy, 1, tft.alphaBlend(a, RGB565(255, 180, 80), TFT_BLACK));
      }
    }
    // ISS blip + crosshair (pulsing)
    if (haveFix) {
      int ox, oy;
      if (project(issLat, issLon, ox, oy)) {
        bool pulse = (frame / 4) & 1;
        spr.drawCircle(ox, oy, pulse ? 5 : 3, TFT_WHITE);
        spr.drawFastHLine(ox - 7, oy, 15, TFT_WHITE); spr.drawFastVLine(ox, oy - 7, 15, TFT_WHITE);
        spr.fillCircle(ox, oy, 2, pulse ? RGB565(255, 90, 60) : TFT_RED);
      }
    }
    spr.pushSprite(BX, BY);
  }
  spr.deleteSprite();
  free(gValid); free(gLon); free(gLat); free(gSh);
  sys::radiosOff();
}
