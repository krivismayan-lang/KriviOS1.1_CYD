// ============================================================================
//  KRIVI OS - 5-page desktop launcher + 43-app registry
// ============================================================================
#include "krivi.h"

namespace launcher {

#define P1 RGB565(230, 60, 90)
#define P2 RGB565(150, 80, 240)
#define P3 RGB565(0, 180, 170)
#define P4 RGB565(40, 160, 255)
#define P5 RGB565(255, 150, 30)
#define P6 RGB565(0, 210, 120)

#define NUM_PAGES 6
const char *PAGE_TITLES[NUM_PAGES] = {"GAMING & EMULATION", "AUDIO & SENSORS",
                              "UTILITIES & TIME", "PI LINK & RADIO",
                              "GRAPHICS & SANDBOX", "WIRELESS LAB & SYSTEM"};

const AppDef APPS[] = {
// ---------------------------------------------------------------- page 1
{1, 0, "NES Emulator", "NES Emulator", "NES", P1, app_nes,
 "microSD /roms/*.nes (mappers 0/1/2/3/4 that fit in RAM; no PSRAM so big games like SMB3 are too large)",
 "Pick a ROM. Left half is the D-pad; right panel has A, B, JUMP-RIGHT "
 "(A+Right), START, SELECT. Supports NROM/MMC1/UxROM/CNROM/MMC3 (incl. the "
 "MMC3 scanline-IRQ status-bar split). The whole ROM loads into RAM, so with "
 "no PSRAM only games up to ~180 KB fit. Audio muted for speed."},
{2, 0, "Retro Snake", "Retro Snake", "SNK", P1, app_snake, "Touchscreen",
 "Swipe in any direction to steer. Eat food to grow; walls and your tail end "
 "the run. Speed rises every 5 points."},
{3, 0, "Tetris Matrix", "Tetris", "TET", P1, app_tetris, "Touchscreen",
 "Right panel: LEFT, RIGHT, ROTATE, DOWN (soft) and DROP (hard). Clearing "
 "lines scores 100/300/500/800 x level."},
{4, 0, "Pong vs AI", "Pong vs AI", "PNG", P1, app_pong, "Touchscreen",
 "Drag up/down anywhere on the left half to move your paddle. First to 7 wins. "
 "The AI paddle has limited speed and reaction delay."},
{6, 0, "Flappy Physics", "Flappy Bird", "FLP", P1, app_flappy, "Touchscreen",
 "Tap anywhere to thrust upward against constant gravity. Pass through the "
 "gaps. Best score is kept for the session."},
{7, 0, "Minefield Sweeper", "Minesweeper", "MIN", P1, app_mines, "Touchscreen",
 "Tap to reveal, long-press (0.5 s) or use FLAG mode to mark. 16x10 grid, "
 "22 mines. First tap is always safe."},
{8, 0, "Breakout Vector", "Breakout", "BRK", P1, app_breakout, "Touchscreen",
 "Drag horizontally to move the paddle. Ball angle depends on where it hits "
 "the paddle. 3 lives."},
{9, 0, "Tabletop Board Games", "Chess / TTT", "BRD", P1, app_board, "Touchscreen",
 "Choose Tic-Tac-Toe (vs unbeatable minimax AI or 2 players) or Chess "
 "(2 players pass-and-play or vs CPU, full legal moves, castling, en passant, "
 "auto-queen promotion). Tap a piece then its target."},
{53, 0, "Raycaster FPS", "Raycaster 3D", "FPS", P1, app_raycaster, "Touchscreen",
 "A Wolfenstein-style 3D maze rendered live with a DDA column raycaster, "
 "distance shading and a minimap. On-screen turn/forward/back pads; reach the "
 "gold exit to clear the level."},
// ---------------------------------------------------------------- page 2
{10, 1, "Piano Synth", "Piano Synth", "PNO", P2, app_piano, "On-board speaker (GPIO26 DAC)",
 "Two octaves. Touch and slide across keys; tones are square waves rendered "
 "by the DMA audio engine on the DAC. Octave and waveform buttons on top."},
{11, 1, "Audio Oscilloscope", "Oscilloscope", "OSC", P2, app_scope,
 "Analog mic/line module on P3 pin IO35 (0-3.3 V, biased to ~1.6 V)",
 "Live trace of IO35 with rising-edge trigger. Tap TIME to change the "
 "timebase, HOLD to freeze. Shows Vpp and an estimated frequency."},
{12, 1, "VU Decibel Meter", "VU dB Meter", "VU", P2, app_vu,
 "Analog mic module on P3 pin IO35",
 "Peak-to-peak amplitude over 25 ms windows converted to dB relative to "
 "full-scale (dBFS) with peak-hold and a 10 s history graph."},
{14, 1, "Clap Relay Switch", "Clap Switch", "CLP", P2, app_clap,
 "Mic module on IO35; optional relay/LED on IO22 (CN1)",
 "A sound spike above the threshold toggles the latch (IO22 + green LED). "
 "Adjust the threshold live. BACKGROUND keeps listening after you exit."},
{17, 1, "Drum Pad", "Drum Pad", "DRM", P2, app_drumpad, "On-board speaker",
 "8 pads with percussion synthesized at boot (kick, snare, hats, clap, toms, "
 "rim, cowbell). ~6 ms trigger latency."},
// ---------------------------------------------------------------- page 3
{18, 2, "Stopwatch", "Stopwatch", "STW", P3, app_stopwatch, "None",
 "START/STOP, LAP and RESET. Millisecond resolution, up to 6 laps shown."},
{19, 2, "Pomodoro Timer", "Pomodoro", "POM", P3, app_pomodoro, "On-board speaker",
 "25 min work (red) / 5 min break (green), long break every 4 rounds. "
 "Chimes and LED colour change at every transition."},
{20, 2, "Calculator", "Calculator", "CAL", P3, app_calc, "None",
 "Full expression parser: + - * / ^ ( ) and sin cos tan sqrt log ln, pi, "
 "e and ANS. Trig in degrees."},
{21, 2, "Calendar", "Calendar", "DAY", P3, app_calendar, "Clock (NTP over WiFi or set in Alarm app)",
 "Month grid with today highlighted. Swipe or tap arrows to change month; "
 "leap years computed with the Gregorian rule."},
{22, 2, "Text Editor", "Text Editor", "TXT", P3, app_editor, "microSD /data/reader/",
 "Multi-line editor with on-screen keyboard. OPEN/NEW/SAVE files in "
 "/data/reader. Cursor arrows move through text."},
{23, 2, "Hex Viewer", "Hex Viewer", "HEX", P3, app_hexview, "microSD",
 "Browse any folder, open any file and page through it as offset / hex / "
 "ASCII. Swipe up/down to scroll, tap +4K/-4K to jump."},
{24, 2, "3D Dice", "3D Dice", "DIC", P3, app_dice, "None",
 "Tap or flick to roll two 3D cubes. Rotation matrices, perspective "
 "projection and back-face culling render each frame."},
{26, 2, "Alarm Clock", "Alarm Clock", "ALM", P3, app_alarm, "Clock (NTP or manual set)",
 "Set the alarm with the +/- buttons and toggle it ON. It rings anywhere in "
 "the OS; tap the red banner to stop. SET CLOCK if there is no WiFi."},
{54, 2, "2048", "2048", "2048", P3, app_2048, "Touchscreen",
 "Swipe to slide and merge the numbered tiles. Combine matching tiles to "
 "reach 2048 - then keep going for a high score. NEW resets the board."},
// ---------------------------------------------------------------- page 4
{27, 3, "Pi Performance Monitor", "Pi Monitor", "PIM", P4, app_pimon,
 "USB cable to Raspberry Pi running tools/pi/krivi_bridge.py",
 "Shows CPU %, temperature, RAM, disk, load and uptime streamed once per "
 "second by the bridge daemon, with a 60 s CPU/temp graph."},
{28, 3, "Pi Bash Console", "Pi Console", "SH", P4, app_piconsole,
 "USB to Pi + krivi_bridge.py, scripts in ~/krivi_scripts/",
 "Lists whitelisted scripts on the Pi. Tap one to run it; its output "
 "streams back live. Only scripts in that folder can run."},
{29, 3, "Pi Remote Trackpad", "Pi Trackpad", "PAD", P4, app_pitrackpad,
 "USB to Pi + krivi_bridge.py (python3-evdev, uinput)",
 "Drag to move the Pi's mouse, tap to left-click, bottom buttons for "
 "L/R click and scroll. SPEED changes sensitivity."},
{30, 3, "Bluetooth Macro Pad", "BLE Macro Pad", "BLE", P4, app_blemacro,
 "Bluetooth LE host (PC/phone/tablet)",
 "Pair with 'KRIVI Macro'. 9 pads send hotkeys or text; edit them in "
 "/sys/apps/app_30.json (e.g. \"CTRL+ALT+T\", \"text:hello\")."},
{31, 3, "BLE Keyboard", "BLE Keyboard", "KB", P4, app_blekbd,
 "Bluetooth LE host (Raspberry Pi / PC / phone / tablet)",
 "A full on-screen Bluetooth keyboard. Pair with 'KRIVI Keyboard' and type "
 "LIVE into a Raspberry Pi or any device - letters, numbers, symbols, arrows, "
 "Enter/Tab/Esc, plus sticky CTRL/ALT/GUI for shortcuts like CTRL+ALT+T."},
{32, 3, "WiFi Analyzer", "WiFi Analyzer", "WFA", P4, app_wifiscan, "None",
 "Scans 2.4 GHz networks and draws signal parabolas per channel 1-13. "
 "Tap LIST for SSID/RSSI/security table."},
{33, 3, "Ping Monitor", "Ping Monitor", "PNG", P4, app_ping,
 "WiFi credentials in /sys/settings.json",
 "ICMP-pings the gateway and a cloud host (default 1.1.1.1, editable) "
 "every second; plots latency and packet loss."},
{34, 3, "ESP-NOW Radio", "ESP-NOW Chat", "NOW", P4, app_espnow,
 "Another ESP32 running KRIVI OS (or any ESP-NOW sender)",
 "Broadcast short messages to nearby boards on channel 1, no router "
 "needed. Quick-reply buttons or type with the keyboard."},
{51, 4, "Weather", "Weather", "WX", P5, app_weather,
 "WiFi + condition icons in /icons/weather on the SD card",
 "Current conditions and a 5-day forecast from Open-Meteo (free, no API key). "
 "Set your city (or lat/lon) and units in sys/apps/app_51.json. The weather "
 "icons are loaded from /icons/weather on the SD card, so you can restyle them "
 "without reflashing. Tap to refresh."},
// ---------------------------------------------------------------- page 5
{35, 4, "Sketchpad", "Sketchpad", "ART", P5, app_paint, "microSD /data/paint/",
 "Draw with 16 colours and 4 brush sizes. SAVE writes a .bmp to "
 "/data/paint, LOAD opens one, CLR wipes the canvas."},
{36, 4, "3D Rainbow Warp", "Rainbow Warp", "WRP", P5, app_warp, "None",
 "Perspective star tunnel: 3D points projected with depth scaling and hue "
 "by depth. Touch to steer, swipe up/down to change speed."},
{37, 4, "Falling Sand", "Falling Sand", "SND", P5, app_sand, "None",
 "Cellular automaton: sand, water, wall and erase. Drag to pour. "
 "160x107 cells, updated bottom-up each frame."},
{39, 4, "Mandelbrot", "Mandelbrot", "FRC", P5, app_mandel, "None",
 "Renders every pixel in float and reports the time (benchmark). Tap to "
 "zoom x2 at that point, ZOOM- to back out, ITER to raise depth."},
{40, 4, "Video & MP4 Player", "Video / MP4", "VID", P5, app_video,
 "microSD /data/movies/*.avi (MP4s converted by tools/convert_media.py) or /data/video/*.mjpeg",
 "The ESP32 cannot decode H.264, so MP4s are converted on your computer to "
 "AVI (Motion-JPEG 320x240 + 22 kHz audio) and play with sound. Raw .mjpeg "
 "clips such as Bad Apple play silently. Tap to pause, swipe down for the "
 "list."},
{41, 4, "Virtual Pet", "Virtual Pet", "PET", P5, app_pet, "microSD /sys/pet.json",
 "Feed, play and put your pet to sleep. Hunger, happiness and energy decay "
 "over time, even while the app is closed (saved to SD)."},
{42, 4, "Touch Diagnostics", "Touch Diag", "TCH", P5, app_touchdiag, "Touchscreen",
 "Crosshair grid with live raw ADC and mapped coordinates; hit the 5 "
 "targets to measure error. Draw mode traces raw paths."},
{43, 4, "System Manual", "System Manual", "MAN", P5, app_manual, "None",
 "This directory. Also reads .txt books in /data/reader and shows "
 "system info."},
{58, 4, "Demoscene FX", "Demo FX", "FX", P5, app_demofx, "None",
 "A full-screen floating-point pixel pusher cycling plasma, a classic fire "
 "effect and metaballs - rendered at 160x100 and line-doubled to fill the "
 "screen. A benchmark that also just looks great."},
// ---------------------------------------------------------------- added: page 2 slot 9
{44, 1, "MP3 Music Player", "MP3 Player", "MP3", P2, app_mp3,
 "microSD /data/music/*.mp3 + speaker on SPEAK",
 "Plays MP3s (any bitrate, 32-48 kHz) through the on-board DAC. Shows ID3 "
 "title/artist, time and a level visualizer. Tap the progress bar to seek, "
 "swipe for next/previous, SH/RA/1x cycles shuffle, repeat-all, single."},
{55, 1, "FFT Spectrum Analyzer", "Spectrum", "SPC", P2, app_spectrum,
 "Mic module on P3 pin IO35",
 "Real-time audio spectrum: a 128-point FFT of the mic turned into 32 colour "
 "bars with peak-hold. Watch music and voice light up the frequency range."},
{56, 1, "Theremin", "Theremin", "THR", P2, app_theremin, "On-board speaker",
 "A touch instrument: slide left-right for pitch (optionally snapped to a "
 "major scale), up-down for volume. Four waveforms. Shows the note and "
 "frequency you are playing."},
{57, 1, "Beat Sequencer", "Beat Seq", "SEQ", P2, app_beatseq, "On-board speaker",
 "A 4-track, 16-step drum machine with synthesized kick, snare, hat and clap. "
 "Tap the grid to build a pattern, set the tempo, and hit PLAY. Starts with a "
 "groove loaded."},
// ---------------------------------------------------------------- page 6: Wireless Lab
// Passive / defensive radio diagnostics (original KRIVI implementations).
{45, 5, "Channel Congestion", "Ch. Congestion", "CH", P6, app_chanmon,
 "None (2.4 GHz radio)",
 "Hops across Wi-Fi channels 1-13 in monitor mode and graphs how busy each "
 "one is by counting frames only (never their contents or addresses). Use it "
 "to pick the clearest channel for your own router."},
{46, 5, "BLE Scanner", "BLE Scanner", "BLE", P6, app_blescan,
 "None (Bluetooth LE radio)",
 "Passively lists nearby Bluetooth LE devices from the public advertisements "
 "they broadcast: name, signal, address type and appearance. Handy for "
 "finding your own beacons, trackers and wearables."},
{47, 5, "Signal Mapper", "Signal Mapper", "MAP", P6, app_sigmap,
 "None (2.4 GHz radio)",
 "Pick one of your own access points, then walk around: a live RSSI meter and "
 "rolling graph reveal dead spots. SAMPLE records a labelled reading so you "
 "can compare rooms."},
{48, 5, "LAN Discovery", "LAN Devices", "LAN", P6, app_landisc,
 "Your Wi-Fi network (credentials in settings.json)",
 "Joins your own network and pings every address on the subnet to list the "
 "devices that are online, with response time and the gateway flagged. A "
 "mini network inventory for your LAN."},
{49, 5, "Net Health", "Net Health", "NET", P6, app_nethealth,
 "Your Wi-Fi network",
 "Times DNS lookups and measures latency, jitter and packet loss to your "
 "gateway and a host you choose, with a rolling sparkline. Tells you whether "
 "a bad connection is your Wi-Fi, your router or the internet."},
{50, 5, "Airtime Monitor", "Airtime Monitor", "AIR", P6, app_airmon,
 "None (2.4 GHz radio)",
 "Stays on one channel and plots total frames per second over time, split "
 "into management / data / control categories (counts only, no payloads). "
 "Shows how congested the air around you is and spots interference."},
{52, 5, "3D ISS Globe Radar", "ISS Globe", "ISS", P6, app_iss,
 "WiFi (tracks the live ISS position from wheretheiss.at, no API key)",
 "A raycast, spinning 3D Earth that tracks the International Space Station in "
 "real time. Pulsing red blip + crosshair, fading orbit trail, live lat/lon/"
 "alt/velocity HUD. Drag the globe to spin and tilt it. Refreshes every 3 s."},

// ---------------------------------------------------------------- planned apps (4x3 roadmap)
// Working placeholders - each shows its planned feature and is filled in over
// coming updates. They keep the 4x3 grid complete and launchable today.
{59, 0, "CHIP-8 Virtual Machine", "CHIP-8", "CH8", P1, app_chip8, "microSD /roms/*.ch8",
 "Interpreter for classic CHIP-8 games (Pong, Brix, Tetris...) loaded from the SD card."},
{60, 0, "Space Invaders", "Invaders", "INV", P1, app_invaders, "Touchscreen",
 "Vector arcade shooter: move and fire at descending alien rows."},
{61, 0, "Asteroids", "Asteroids", "AST", P1, app_asteroids, "Touchscreen",
 "Vector ship, thrust and rotation, shoot and split drifting asteroids."},
{62, 1, "Morse Code Keyer", "Morse Key", "MRS", P2, app_morse, "On-board speaker",
 "Tap out dits and dahs; hear them and decode touch taps into Morse text."},
{63, 1, "Voice Pitch Tracker", "Pitch", "PIT", P2, app_pitch, "Mic on IO35",
 "Analyses the mic waveform to estimate vocal pitch and show the nearest note."},
{64, 1, "Ultrasonic Range", "Ultrasonic", "USR", P2, app_ultrasonic, "HC-SR04 sensor (trig/echo GPIO)",
 "Reads distance from an external HC-SR04 and graphs it live."},
{65, 2, "World Clock", "World Clock", "WLD", P3, app_worldclock, "Clock (NTP)",
 "Shows the current time across several world time zones at once."},
{66, 2, "Currency Converter", "Currency", "CUR", P3, app_currency, "microSD rates json (or WiFi)",
 "Converts between currencies using stored or fetched exchange rates."},
{67, 2, "Unit Converter", "Units", "UNT", P3, app_units, "None",
 "Length, mass, temperature, speed and data-size conversions."},
{68, 3, "Pi Shell Keyboard", "Pi Shell", "PSH", P4, app_pishell, "USB to Pi + krivi_bridge.py",
 "Full on-screen terminal: type commands to the Pi and read the output."},
{69, 3, "SSH Action Shortcuts", "SSH", "SSH", P4, app_sshactions, "USB/Wi-Fi to Pi",
 "One-tap buttons that fire specific remote Linux commands."},
{70, 3, "htop Live Monitor", "htop", "TOP", P4, app_htop, "USB to Pi + krivi_bridge.py",
 "Draws a live process/CPU/RAM task list from the Pi over serial."},
{71, 3, "Pi Safe Shutdown", "Pi Power", "PWR", P4, app_pishutdown, "USB to Pi + krivi_bridge.py",
 "Sends a graceful shutdown/reboot command to the connected Pi."},
{72, 4, "Matrix Digital Rain", "Matrix Rain", "MTX", P5, app_matrix, "None",
 "Cascading green glyph streams - the classic terminal screensaver."},
{73, 4, "Starfield Screensaver", "Starfield", "STR", P5, app_starfield, "None",
 "Full-screen monochrome cosmic cruise through a particle starfield."},
{74, 5, "System Settings", "Settings", "SET", P6, app_settings, "None",
 "Screen brightness (PWM), Wi-Fi profiles, volume, theme and calibration from the touchscreen."},
{75, 5, "NVS Flash Editor", "NVS Editor", "NVS", P6, app_nvsedit, "None",
 "Browse and edit raw non-volatile system variables stored in flash."},
{76, 5, "Desk Clock", "Desk Clock", "CLK", P6, app_deskclock, "Clock (NTP or manual)",
 "Minimal full-screen HH:MM:SS clock for standby/desk display."},
{77, 5, "Noise Floor Log", "Noise Log", "NSE", P6, app_noiselog, "Mic on IO35",
 "Measures and logs ambient room volume over time to the SD card."},
};
const int APP_COUNT = sizeof(APPS) / sizeof(APPS[0]);

const AppDef *find(uint8_t id) {
  for (int i = 0; i < APP_COUNT; ++i) if (APPS[i].id == id) return &APPS[i];
  return nullptr;
}

// ---------------------------------------------------------------- layout
// 4x3 high-density grid: 12 cells per page
static const int CELL_W = 76, CELL_H = 56;
static const int GRID_X[4] = {3, 82, 161, 240};
static const int GRID_Y[3] = {30, 90, 150};
static const int NAV_Y = 208;
static const int CELLS = 12;

static int s_page = 0;
static uint16_t *s_icons[CELLS] = {nullptr};  // icon page cache (from SD)
static int s_iconPage = -1;

static void freeIcons() {
  for (auto &p : s_icons) { if (p) { free(p); p = nullptr; } }
  s_iconPage = -1;
}

// Dynamic paging: only the 12 icons of the visible page live in RAM
// (12 x 3200 B). They are dropped before any app launches.
static void loadIcons(int page) {
  if (s_iconPage == page) return;
  freeIcons();
  if (!sys::sdOk) return;
  int slot = 0;
  for (int i = 0; i < APP_COUNT && slot < CELLS; ++i) {
    if (APPS[i].page != page) continue;
    char path[32];
    snprintf(path, sizeof(path), "/icons/app_%02d.raw", APPS[i].id);
    File f = SD.open(path);
    if (f && f.size() == 40 * 40 * 2) {
      s_icons[slot] = (uint16_t *)malloc(40 * 40 * 2);
      if (s_icons[slot]) f.read((uint8_t *)s_icons[slot], 40 * 40 * 2);
    }
    if (f) f.close();
    slot++;
  }
  s_iconPage = page;
}

static void fallbackIcon(int x, int y, const AppDef &a) {
  uint16_t c = a.color;
  tft.fillRoundRect(x, y, 40, 40, 9, c);
  tft.fillRoundRect(x + 4, y + 3, 32, 13, 6, tft.alphaBlend(60, TFT_WHITE, c));
  tft.drawRoundRect(x, y, 40, 40, 9, tft.alphaBlend(120, TFT_WHITE, c));
  tft.setTextColor(TFT_WHITE, c);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(a.abbr, x + 20, y + 21, 2);
  tft.setTextDatum(TL_DATUM);
}

static void drawCell(int slot, const AppDef &a, bool hl) {
  int x = GRID_X[slot % 4], y = GRID_Y[slot / 4];
  uint16_t bg = hl ? C_PANEL2 : C_BG;
  tft.fillRoundRect(x, y, CELL_W, CELL_H, 6, bg);
  if (hl) tft.drawRoundRect(x, y, CELL_W, CELL_H, 6, a.color);
  int ix = x + (CELL_W - 40) / 2, iy = y + 1;
  if (s_icons[slot]) {
    tft.setSwapBytes(true);
    tft.pushImage(ix, iy, 40, 40, s_icons[slot]);
    tft.setSwapBytes(false);
  } else {
    fallbackIcon(ix, iy, a);
  }
  tft.setTextColor(C_TEXT, bg);
  tft.setTextDatum(TC_DATUM);
  tft.drawString(a.label, x + CELL_W / 2, y + 43, 1);
  tft.setTextDatum(TL_DATUM);
}

static void drawStatus() {
  tft.fillRect(0, 0, SCR_W, 26, C_PANEL);
  tft.fillRect(0, 24, SCR_W, 2, ui::hsv(s_page * 60 + 190, 200, 255));
  tft.setTextColor(C_ACCENT, C_PANEL);
  tft.drawString("KRIVI", 6, 5, 2);
  char t[24];
  snprintf(t, sizeof(t), "%d/%d %s", s_page + 1, NUM_PAGES, PAGE_TITLES[s_page]);
  tft.setTextColor(C_TEXT, C_PANEL);
  tft.drawString(t, 52, 5, 2);
  struct tm tm;
  if (sys::now(tm)) snprintf(t, sizeof(t), "%02d:%02d", tm.tm_hour, tm.tm_min);
  else strcpy(t, "--:--");
  tft.setTextColor(sys::alarm.enabled ? C_WARN : C_DIM, C_PANEL);
  tft.setTextDatum(TR_DATUM);
  tft.drawString(t, 314, 5, 2);
  tft.setTextDatum(TL_DATUM);
  if (sys::clapBackground) tft.fillCircle(270, 13, 3, sys::clapLatch ? C_OK : C_WARN);
}

static void drawNav() {
  tft.fillRect(0, NAV_Y - 2, SCR_W, SCR_H - NAV_Y + 2, C_BG);
  tft.drawFastHLine(10, NAV_Y - 2, 300, C_PANEL2);
  ui::button(4, NAV_Y + 3, 64, 28, "<", s_page > 0 ? C_PANEL2 : C_PANEL, s_page > 0 ? C_TEXT : C_DIM, 4);
  ui::button(252, NAV_Y + 3, 64, 28, ">", s_page < NUM_PAGES - 1 ? C_PANEL2 : C_PANEL, s_page < NUM_PAGES - 1 ? C_TEXT : C_DIM, 4);
  for (int i = 0; i < NUM_PAGES; ++i) {
    int cx = 112 + i * 16, cy = NAV_Y + 17;
    if (i == s_page) tft.fillCircle(cx, cy, 5, C_ACCENT);
    else tft.drawCircle(cx, cy, 4, C_DIM);
  }
}

static void drawPage() {
  loadIcons(s_page);
  tft.fillRect(0, 26, SCR_W, NAV_Y - 28, C_BG);
  drawStatus();
  int slot = 0;
  for (int i = 0; i < APP_COUNT; ++i) {
    if (APPS[i].page != s_page) continue;
    drawCell(slot++, APPS[i], false);
  }
  drawNav();
}

static const AppDef *slotApp(int page, int slot, int *idxOut = nullptr) {
  int s = 0;
  for (int i = 0; i < APP_COUNT; ++i) {
    if (APPS[i].page != page) continue;
    if (s == slot) { if (idxOut) *idxOut = i; return &APPS[i]; }
    s++;
  }
  return nullptr;
}

static int slotAt(int x, int y) {
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 4; ++c)
      if (ui::inRect(x, y, GRID_X[c], GRID_Y[r], CELL_W, CELL_H)) return r * 4 + c;
  return -1;
}

static void infoCard(const AppDef &a) {
  char t[64];
  snprintf(t, sizeof(t), "APP %02d - %s", a.id, a.name);
  String msg = String("Needs: ") + a.needs + "\n" + a.help;
  if (msg.length() > 330) msg = msg.substring(0, 327) + "...";
  ui::msgBox(t, msg.c_str());
}

void begin() { s_page = sys::cfg["launcher"]["page"] | 0; s_page = constrain(s_page, 0, NUM_PAGES - 1); }

void run() {
  drawPage();
  uint32_t lastClock = 0;
  int pressedSlot = -1;
  bool longShown = false;
  for (;;) {
    ui::clearEvents();
    Touch &t = ui::poll();
    delay(4);
    if (millis() - lastClock > 1000) { lastClock = millis(); drawStatus(); }

    if (t.pressed) {
      pressedSlot = slotAt(t.x, t.y);
      longShown = false;
      if (pressedSlot >= 0) {
        const AppDef *a = slotApp(s_page, pressedSlot);
        if (a) drawCell(pressedSlot, *a, true); else pressedSlot = -1;
      }
    }
    // long press -> app info card
    if (t.down && pressedSlot >= 0 && !longShown && t.held() > 650 &&
        abs(t.x - t.sx) < 18 && abs(t.y - t.sy) < 18) {
      longShown = true;
      const AppDef *a = slotApp(s_page, pressedSlot);
      if (a) { audio::beep(1200, 30); infoCard(*a); drawPage(); }
      pressedSlot = -1;
    }
    if (t.released) {
      int ps = pressedSlot; pressedSlot = -1;
      if (ps >= 0) {
        const AppDef *a = slotApp(s_page, ps);
        if (a) drawCell(ps, *a, false);
      }
      if (t.swipe == SW_LEFT && s_page < NUM_PAGES - 1) { s_page++; audio::click(); drawPage(); continue; }
      if (t.swipe == SW_RIGHT && s_page > 0) { s_page--; audio::click(); drawPage(); continue; }
      if (t.tap) {
        if (ui::inRect(t.sx, t.sy, 0, NAV_Y, 76, 34) && s_page > 0) { s_page--; audio::click(); drawPage(); continue; }
        if (ui::inRect(t.sx, t.sy, 244, NAV_Y, 76, 34) && s_page < NUM_PAGES - 1) { s_page++; audio::click(); drawPage(); continue; }
        if (ps >= 0 && !longShown && slotAt(t.sx, t.sy) == ps) {
          const AppDef *a = slotApp(s_page, ps);
          if (a) {
            audio::click();
            freeIcons();                     // hand the RAM to the app
            loader::launch(*a);
            ui::header(nullptr, 0);          // detach header ownership
            drawPage();
          }
        }
      }
    }
  }
}
}  // namespace launcher
