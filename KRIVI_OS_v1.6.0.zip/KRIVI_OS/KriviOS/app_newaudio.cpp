// ============================================================================
//  New audio apps (page 2)
//   55  FFT Spectrum Analyzer  - real-time mic spectrum (IO35)
//   56  Theremin               - touch-controlled continuous synth
//   57  Beat Sequencer         - 4-track x 16-step drum machine
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  55  FFT SPECTRUM ANALYZER
// ============================================================================
namespace fftm {
static const int N = 128;
static float re[N], im[N];
static uint16_t bitrev[N];
static bool revInit = false;
static void fft() {
  if (!revInit) { for (int i = 0; i < N; ++i) { int r = 0, x = i; for (int b = 0; b < 7; ++b) { r = (r << 1) | (x & 1); x >>= 1; } bitrev[i] = r; } revInit = true; }
  for (int i = 0; i < N; ++i) if (i < bitrev[i]) { float t = re[i]; re[i] = re[bitrev[i]]; re[bitrev[i]] = t; t = im[i]; im[i] = im[bitrev[i]]; im[bitrev[i]] = t; }
  for (int len = 2; len <= N; len <<= 1) {
    float ang = -2 * PI / len, wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < N; i += len) {
      float cr = 1, ci = 0;
      for (int j = 0; j < len / 2; ++j) {
        int a = i + j, b = i + j + len / 2;
        float tr = cr * re[b] - ci * im[b], ti = cr * im[b] + ci * re[b];
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
        float ncr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = ncr;
      }
    }
  }
}
}  // namespace fftm

void app_spectrum(AppCtx &c) {
  using namespace fftm;
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  const int BARS = 32, GX = 8, GY = 32, GW = 304, GH = 168, BW = GW / BARS;
  float peak[BARS]; for (auto &p : peak) p = 0;
  ui::clearBody();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("Live mic spectrum (IO35)  -  128-pt FFT", 8, 214, 1);
  while (c.loop()) {
    // sample N points at ~a fixed cadence (~16 kHz)
    for (int i = 0; i < N; ++i) { re[i] = analogRead(PIN_MIC); im[i] = 0; delayMicroseconds(55); }
    float mean = 0; for (int i = 0; i < N; ++i) mean += re[i]; mean /= N;
    for (int i = 0; i < N; ++i) re[i] = (re[i] - mean) * (0.5f - 0.5f * cosf(2 * PI * i / (N - 1)));   // Hann window
    fft();
    for (int b = 0; b < BARS; ++b) {
      int bin = 1 + b * (N / 2 - 1) / BARS;
      float mag = sqrtf(re[bin] * re[bin] + im[bin] * im[bin]);
      float db = logf(mag + 1) * 26;
      int h = (int)constrain(db, 0.f, (float)GH);
      peak[b] = h > peak[b] ? h : peak[b] * 0.90f;
      int x = GX + b * BW;
      tft.fillRect(x, GY, BW - 1, GH - h, C_BG);
      tft.fillRect(x, GY + GH - h, BW - 1, h, ui::hsv(200 + b * 5, 230, 255));
      int py = GY + GH - (int)peak[b];
      tft.fillRect(x, py, BW - 1, 2, TFT_WHITE);
    }
    if (!c.loop()) return;
  }
}

// ============================================================================
//  56  THEREMIN
// ============================================================================
void app_theremin(AppCtx &c) {
  int wave = audio::SINE; bool snap = true;
  static const char *WN[4] = {"SINE", "SQUARE", "TRI", "SAW"};
  static const int WMAP[4] = {audio::SINE, audio::SQUARE, audio::TRIANGLE, audio::SAW};
  static const float SCALE[8] = {0, 2, 4, 5, 7, 9, 11, 12};   // major scale semitones
  const char *NAMES[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
  const int PY = 44, PH = 148;
  auto toolbar = [&]() {
    ui::button(4, 200, 100, 36, WN[wave], RGB565(90, 50, 160));
    ui::button(110, 200, 100, 36, snap ? "SNAP: ON" : "SNAP: OFF", snap ? C_OK : C_PANEL2, snap ? TFT_BLACK : C_TEXT, 2);
    ui::button(216, 200, 100, 36, "silence", C_PANEL2);
  };
  ui::clearBody();
  tft.drawRect(4, PY, 312, PH, C_PANEL2);
  for (int i = 0; i <= 24; ++i) { int x = 8 + i * 304 / 24; tft.drawFastVLine(x, PY + 1, PH - 2, RGB565(24, 28, 44)); }
  toolbar();
  tft.setTextColor(C_DIM, C_BG); tft.drawString("left-right = pitch   up-down = volume", 8, 30, 1);
  bool playing = false; int lastX = -1;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && t.sy >= 200) {
      if (ui::inRect(t.sx, t.sy, 4, 200, 100, 36)) { wave = (wave + 1) % 4; toolbar(); }
      else if (ui::inRect(t.sx, t.sy, 110, 200, 100, 36)) { snap = !snap; toolbar(); }
      else if (ui::inRect(t.sx, t.sy, 216, 200, 100, 36)) { audio::stop(0); playing = false; }
      continue;
    }
    if (t.down && t.y >= PY && t.y < PY + PH) {
      float fx = (t.x - 8) / 304.0f;              // 0..1 over ~3 octaves
      float semis = fx * 36;
      if (snap) { int oct = (int)(semis / 12); int idx = (int)roundf((semis - oct * 12) / 12 * 7); idx = constrain(idx, 0, 7); semis = oct * 12 + SCALE[idx]; }
      float hz = 130.81f * powf(2.0f, semis / 12.0f);
      uint8_t vol = (uint8_t)constrain((PY + PH - t.y) * 160 / PH, 10, 160);
      if (!playing) { audio::tone(0, hz, vol, (audio::Wave)WMAP[wave]); playing = true; }
      else { audio::setFreq(0, hz); audio::tone(0, hz, vol, (audio::Wave)WMAP[wave]); }
      int px = constrain((int)t.x, 6, 314);
      if (px != lastX) {
        tft.fillRect(5, PY + 1, 310, PH - 2, C_BG);
        for (int i = 0; i <= 24; ++i) { int gx = 8 + i * 304 / 24; tft.drawFastVLine(gx, PY + 1, PH - 2, RGB565(24, 28, 44)); }
        tft.fillRect(px - 1, PY + 1, 3, PH - 2, C_ACCENT);
        tft.fillCircle(px, t.y, 6, C_WARN);
        int note = ((int)roundf(semis)) % 12; if (note < 0) note += 12;
        char s[24]; snprintf(s, 24, "%s  %.0f Hz", NAMES[note], hz);
        tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 120, 30, 2);
        lastX = px;
      }
    } else if (playing) { audio::stop(0); playing = false; lastX = -1; }
  }
  audio::stop(0);
}

// ============================================================================
//  57  BEAT SEQUENCER
// ============================================================================
static int8_t *bsDrum(int kind, uint32_t &len) {
  const float R = audio::RATE;
  static const float DUR[4] = {0.32f, 0.22f, 0.06f, 0.30f};
  len = (uint32_t)(DUR[kind] * R);
  int8_t *d = (int8_t *)malloc(len); if (!d) return nullptr;
  float ph = 0; uint32_t rng = 0xC0FFEE + kind; float prevN = 0;
  for (uint32_t i = 0; i < len; ++i) {
    float tt = i / R, v = 0; rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    float n = ((rng & 0xFFFF) / 32768.0f) - 1;
    switch (kind) {
      case 0: { float f = 45 + 110 * expf(-tt * 30); ph += f / R; v = sinf(ph * 2 * PI) * expf(-tt * 9); } break;       // kick
      case 1: { ph += 185 / R; v = 0.5f * sinf(ph * 2 * PI) * expf(-tt * 25) + 0.6f * n * expf(-tt * 14); } break;      // snare
      case 2: { v = (n - prevN) * 0.6f * expf(-tt * 70); } break;                                                       // hat
      default: { float env = tt < 0.02f ? 1 : expf(-(tt - 0.02f) * 20); v = n * env * 0.7f; } break;                    // clap
    }
    prevN = n; d[i] = (int8_t)constrain((int)(v * 120), -127, 127);
  }
  return d;
}
void app_beatseq(AppCtx &c) {
  const int TR = 4, ST = 16;
  static const char *NM[4] = {"KICK", "SNAR", "HAT", "CLAP"};
  bool grid[TR][ST]; memset(grid, 0, sizeof(grid));
  int8_t *smp[4]; uint32_t slen[4];
  ui::clearBody(); ui::centerText("building drums...", 160, 120, C_DIM, C_BG, 2);
  for (int i = 0; i < 4; ++i) smp[i] = bsDrum(i, slen[i]);
  // a default groove
  grid[0][0] = grid[0][4] = grid[0][8] = grid[0][12] = 1;
  grid[1][4] = grid[1][12] = 1;
  for (int s = 0; s < ST; s += 2) grid[2][s] = 1;
  ui::clearBody();
  int bpm = 110, step = -1, voice = 0; bool playing = true;
  const int GX = 44, GY = 40, CW = 17, CH = 30;
  auto cellDraw = [&](int r, int s) {
    int x = GX + s * CW, y = GY + r * (CH + 4);
    uint16_t on = ui::hsv(r * 40 + 190, 220, 255);
    tft.fillRoundRect(x, y, CW - 2, CH, 3, grid[r][s] ? on : (s / 4 % 2 ? RGB565(26, 30, 46) : RGB565(36, 40, 60)));
    if (s == step) tft.drawRoundRect(x, y, CW - 2, CH, 3, TFT_WHITE);
  };
  auto labels = [&]() {
    for (int r = 0; r < TR; ++r) { tft.setTextColor(C_TEXT, C_BG); tft.drawString(NM[r], 6, GY + r * (CH + 4) + 8, 1); }
  };
  auto drawGrid = [&]() { for (int r = 0; r < TR; ++r) for (int s = 0; s < ST; ++s) cellDraw(r, s); };
  auto bar = [&]() {
    ui::button(4, 200, 90, 36, playing ? "STOP" : "PLAY", playing ? C_ERR : C_OK, TFT_BLACK, 2);
    ui::button(100, 200, 50, 36, "-", C_PANEL2, C_TEXT, 4); ui::button(206, 200, 50, 36, "+", C_PANEL2, C_TEXT, 4);
    char s[16]; snprintf(s, 16, "%d BPM", bpm); tft.fillRect(152, 200, 52, 36, C_BG); ui::centerText(s, 178, 218, C_TEXT, C_BG, 2);
    ui::button(262, 200, 54, 36, "CLR", C_PANEL2, C_TEXT, 2);
  };
  labels(); drawGrid(); bar();
  uint32_t stepT = millis();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap) {
      if (t.sy < 200) {
        int s = (t.sx - GX) / CW, r = (t.sy - GY) / (CH + 4);
        if (s >= 0 && s < ST && r >= 0 && r < TR && t.sx >= GX) { grid[r][s] = !grid[r][s]; cellDraw(r, s); }
      } else if (ui::inRect(t.sx, t.sy, 4, 200, 90, 36)) { playing = !playing; bar(); }
      else if (ui::inRect(t.sx, t.sy, 100, 200, 50, 36)) { bpm = max(40, bpm - 5); bar(); }
      else if (ui::inRect(t.sx, t.sy, 206, 200, 50, 36)) { bpm = min(240, bpm + 5); bar(); }
      else if (ui::inRect(t.sx, t.sy, 262, 200, 54, 36)) { memset(grid, 0, sizeof(grid)); drawGrid(); }
    }
    uint32_t stepMs = 15000 / bpm;       // 16th notes
    if (playing && millis() - stepT >= stepMs) {
      stepT += stepMs;
      int prev = step; step = (step + 1) % ST;
      for (int r = 0; r < TR; ++r) if (prev >= 0) cellDraw(r, prev);
      for (int r = 0; r < TR; ++r) { cellDraw(r, step);
        if (grid[r][step] && smp[r]) { audio::sample(voice, smp[r], slen[r], audio::RATE, 120); voice = (voice + 1) % 6; } }
    }
  }
  audio::stopAll(); delay(15);
  for (int i = 0; i < 4; ++i) free(smp[i]);
}
