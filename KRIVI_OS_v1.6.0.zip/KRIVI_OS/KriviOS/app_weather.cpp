// ============================================================================
//  51  WEATHER  - current conditions + 5-day forecast from Open-Meteo
//                 (free, no API key). Condition icons are 16-bit .raw images
//                 loaded from /icons/weather on the microSD card, so you can
//                 restyle them without reflashing. Vector fallback if missing.
//      Config: sys/apps/app_51.json  { city | lat/lon, name, units }
// ============================================================================
#include "apps_common.h"
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

namespace wx {
#define WX_BG RGB565(12, 16, 28)

struct Day { char dow[4]; int code; float hi, lo; };
struct Data {
  bool ok = false; String err;
  float temp, feels, hum, wind; int code; bool isDay;
  String place;
  Day days[6]; int nDays = 0;
};

// WMO weather code -> icon base name (files in /icons/weather/<name>_lg.raw / _sm.raw)
static const char *icon(int c, bool day) {
  if (c == 0) return day ? "clear_day" : "clear_night";
  if (c <= 2) return day ? "partly_day" : "partly_night";
  if (c == 3) return "cloudy";
  if (c == 45 || c == 48) return "fog";
  if (c >= 51 && c <= 57) return "drizzle";
  if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return "rain";
  if ((c >= 71 && c <= 77) || (c >= 85 && c <= 86)) return "snow";
  if (c >= 95) return "thunder";
  return "cloudy";
}
static const char *text(int c) {
  switch (c) {
    case 0: return "Clear sky";
    case 1: return "Mainly clear"; case 2: return "Partly cloudy"; case 3: return "Overcast";
    case 45: case 48: return "Fog";
    case 51: case 53: case 55: return "Drizzle";
    case 56: case 57: return "Freezing drizzle";
    case 61: return "Light rain"; case 63: return "Rain"; case 65: return "Heavy rain";
    case 66: case 67: return "Freezing rain";
    case 71: return "Light snow"; case 73: return "Snow"; case 75: return "Heavy snow"; case 77: return "Snow grains";
    case 80: return "Rain showers"; case 81: return "Rain showers"; case 82: return "Violent showers";
    case 85: case 86: return "Snow showers";
    case 95: return "Thunderstorm"; case 96: case 99: return "Thunderstorm, hail";
    default: return "--";
  }
}
static const char *DOW[7] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
static void weekday(const char *date, char *out) {       // "YYYY-MM-DD"
  int y, m, d;
  if (sscanf(date, "%d-%d-%d", &y, &m, &d) != 3) { strcpy(out, "---"); return; }
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (m < 3) y -= 1;
  strcpy(out, DOW[(y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7]);
}

// ---- icon drawing: SD .raw first, else a vector fallback
static void vectorIcon(int x, int y, int s, const char *name) {
  int cx = x + s / 2, cy = y + s / 2;
  uint16_t sun = RGB565(255, 205, 60), moon = RGB565(220, 225, 240),
           cloud = RGB565(190, 198, 215), dark = RGB565(120, 130, 150),
           rain = RGB565(90, 150, 255), snow = TFT_WHITE, bolt = RGB565(255, 220, 0);
  bool night = strstr(name, "night");
  bool hasSun = strstr(name, "clear") || strstr(name, "partly");
  tft.fillRect(x, y, s, s, WX_BG);
  if (hasSun) {
    int r = s / 5, ox = strstr(name, "partly") ? cx - s / 8 : cx, oy = strstr(name, "partly") ? cy - s / 6 : cy;
    if (night) { tft.fillCircle(ox, oy, r, moon); tft.fillCircle(ox + r / 2, oy - r / 3, r, WX_BG); tft.fillCircle(cx + s / 5, cy - s / 5, 1, snow); }
    else { tft.fillCircle(ox, oy, r, sun); for (int a = 0; a < 8; ++a) { float t = a * PI / 4; tft.drawLine(ox + cosf(t) * r * 1.3f, oy + sinf(t) * r * 1.3f, ox + cosf(t) * r * 1.8f, oy + sinf(t) * r * 1.8f, sun); } }
  }
  bool hasCloud = !(strstr(name, "clear"));
  if (hasCloud) {
    int cw = s / 2, cyy = cy + s / 8;
    tft.fillCircle(cx - cw / 3, cyy, s / 7, cloud);
    tft.fillCircle(cx + cw / 4, cyy - s / 14, s / 6, cloud);
    tft.fillRoundRect(cx - cw / 2, cyy, cw, s / 7, s / 14, cloud);
  }
  if (strstr(name, "rain") || strstr(name, "drizzle"))
    for (int i = -1; i <= 1; ++i) tft.drawLine(cx + i * s / 6, cy + s / 4, cx + i * s / 6 - s / 16, cy + s / 3, rain);
  if (strstr(name, "snow"))
    for (int i = -1; i <= 1; ++i) tft.fillCircle(cx + i * s / 6, cy + s / 3, 2, snow);
  if (strstr(name, "thunder"))
    tft.fillTriangle(cx, cy + s / 6, cx - s / 10, cy + s / 3, cx + s / 20, cy + s / 4, bolt);
  if (strstr(name, "fog"))
    for (int i = 0; i < 3; ++i) tft.drawFastHLine(cx - s / 4, cy + s / 6 + i * 5, s / 2, dark);
}
static void drawIcon(int x, int y, int sz, const char *name) {
  char path[48];
  snprintf(path, sizeof(path), "/icons/weather/%s_%s.raw", name, sz >= 64 ? "lg" : "sm");
  File f = sys::sdOk ? SD.open(path) : File();
  size_t want = (size_t)sz * sz * 2;
  if (f && f.size() == want) {
    uint16_t *buf = (uint16_t *)malloc(want);
    if (buf) {
      f.read((uint8_t *)buf, want); f.close();
      tft.setSwapBytes(true); tft.pushImage(x, y, sz, sz, buf); tft.setSwapBytes(false);
      free(buf);
      return;
    }
  }
  if (f) f.close();
  vectorIcon(x, y, sz, name);
}

static bool httpJson(const String &url, JsonDocument &doc, String &err) {
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http;
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setTimeout(8000);
  if (!http.begin(client, url)) { err = "begin failed"; return false; }
  int code = http.GET();
  if (code != 200) { err = "HTTP " + String(code); http.end(); return false; }
  // Read the whole body first, THEN parse. Open-Meteo replies with chunked
  // transfer encoding over TLS, and parsing straight from the live stream can
  // stop early (the stream briefly reports 0 bytes between chunks).
  String payload = http.getString();
  http.end();
  if (payload.length() == 0) { err = "empty response"; return false; }
  sys::log("weather: %d bytes", payload.length());
  DeserializationError e = deserializeJson(doc, payload);
  if (e) {
    err = String("parse: ") + e.c_str();
    sys::log("weather parse err: %s | head: %.60s", e.c_str(), payload.c_str());
    return false;
  }
  return true;
}

static void fetch(AppCtx &c, Data &d) {
  d.ok = false;
  float lat = c.pFloat("lat", 40.7128f), lon = c.pFloat("lon", -74.006f);
  d.place = c.pStr("name", "");
  String city = c.pStr("city", "");
  String units = c.pStr("units", "us");
  bool metric = units == "metric" || units == "si";
  // geocode a city name if provided
  if (city.length()) {
    JsonDocument g; String e;
    String u = "https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + city;
    if (httpJson(u, g, e) && g["results"].is<JsonArray>() && g["results"].size() > 0) {
      lat = g["results"][0]["latitude"] | lat;
      lon = g["results"][0]["longitude"] | lon;
      if (!d.place.length()) d.place = String((const char *)(g["results"][0]["name"] | city.c_str()));
    }
  }
  if (!d.place.length()) { char b[32]; snprintf(b, 32, "%.2f, %.2f", lat, lon); d.place = b; }
  char url[360];
  snprintf(url, sizeof(url),
    "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day"
    "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=5&timezone=auto"
    "&temperature_unit=%s&wind_speed_unit=%s",
    lat, lon, metric ? "celsius" : "fahrenheit", metric ? "kmh" : "mph");
  JsonDocument doc; String e;
  if (!httpJson(url, doc, e)) { d.err = e; return; }
  JsonObject cur = doc["current"];
  d.temp = cur["temperature_2m"] | 0.0f;
  d.feels = cur["apparent_temperature"] | d.temp;
  d.hum = cur["relative_humidity_2m"] | 0.0f;
  d.wind = cur["wind_speed_10m"] | 0.0f;
  d.code = cur["weather_code"] | 0;
  d.isDay = (cur["is_day"] | 1) != 0;
  JsonObject dy = doc["daily"];
  JsonArray tm = dy["time"], wc = dy["weather_code"], mx = dy["temperature_2m_max"], mn = dy["temperature_2m_min"];
  d.nDays = 0;
  for (int i = 0; i < (int)tm.size() && i < 5; ++i) {
    Day &dd = d.days[d.nDays];
    weekday(tm[i] | "", dd.dow);
    dd.code = wc[i] | 0; dd.hi = mx[i] | 0.0f; dd.lo = mn[i] | 0.0f;
    d.nDays++;
  }
  d.ok = true;
}
}  // namespace wx

void app_weather(AppCtx &c) {
  using namespace wx;
  bool metric = c.pStr("units", "us") == "metric" || c.pStr("units", "us") == "si";
  const char *U = metric ? "C" : "F", *WU = metric ? "km/h" : "mph";
  Data d;
  auto refresh = [&]() {
    ui::clearBody();
    ui::centerText("Connecting to WiFi...", 160, 120, C_WARN, C_BG, 2);
    if (!sys::wifiConnect(10000, true)) { d.ok = false; d.err = "WiFi failed"; return; }
    ui::clearBody();
    ui::centerText("Fetching weather...", 160, 120, C_ACCENT, C_BG, 2);
    fetch(c, d);
    sys::radiosOff();
  };
  auto draw = [&]() {
    ui::clearBody(WX_BG);
    if (!d.ok) {
      ui::centerText("Weather unavailable", 160, 96, C_ERR, WX_BG, 4);
      ui::centerText(d.err.length() ? d.err.c_str() : "check WiFi in settings.json", 160, 124, C_DIM, WX_BG, 2);
      ui::button(110, 150, 100, 40, "RETRY", C_PANEL2);
      return;
    }
    // hero
    drawIcon(14, 34, 80, icon(d.code, d.isDay));
    tft.setTextColor(C_TEXT, WX_BG);
    tft.setTextDatum(TR_DATUM);
    char t[16]; snprintf(t, 16, "%d", (int)roundf(d.temp));
    tft.drawString(t, 250, 36, 7);
    tft.setTextColor(C_ACCENT, WX_BG);
    tft.drawString(String("\xB0") + U, 300, 44, 4);
    tft.setTextDatum(TL_DATUM);
    tft.setTextColor(C_TEXT, WX_BG);
    tft.drawString(d.place.substring(0, 20), 100, 34, 2);
    tft.setTextColor(C_DIM, WX_BG);
    tft.drawString(text(d.code), 100, 92, 2);
    char ln[48];
    snprintf(ln, sizeof(ln), "Feels %d\xB0   Hum %d%%   Wind %d %s", (int)roundf(d.feels), (int)roundf(d.hum), (int)roundf(d.wind), WU);
    tft.setTextColor(C_TEXT, WX_BG); tft.drawString(ln, 14, 118, 2);
    // 5-day forecast
    tft.drawFastHLine(10, 140, 300, C_PANEL2);
    int n = d.nDays, cw = 300 / max(1, n);
    for (int i = 0; i < n; ++i) {
      int x = 10 + i * cw;
      if (i) tft.drawFastVLine(x, 146, 86, RGB565(30, 36, 54));
      tft.setTextColor(i == 0 ? C_ACCENT : C_TEXT, WX_BG);
      tft.setTextDatum(TC_DATUM);
      tft.drawString(i == 0 ? "Today" : d.days[i].dow, x + cw / 2, 146, 2);
      tft.setTextDatum(TL_DATUM);
      drawIcon(x + cw / 2 - 20, 162, 40, icon(d.days[i].code, true));
      char hl[20]; snprintf(hl, sizeof(hl), "%d\xB0", (int)roundf(d.days[i].hi));
      ui::centerText(hl, x + cw / 2, 212, C_TEXT, WX_BG, 2);
      snprintf(hl, sizeof(hl), "%d\xB0", (int)roundf(d.days[i].lo));
      ui::centerText(hl, x + cw / 2, 226, C_DIM, WX_BG, 1);
    }
    // refresh affordance in the header area
    hud("tap=refresh", C_DIM);
  };
  c.header();
  refresh();
  draw();
  uint32_t loaded = millis();
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap) {
      if (!d.ok && !ui::inRect(t.sx, t.sy, 110, 150, 100, 40)) continue;
      c.header(); refresh(); draw(); loaded = millis();
    }
    // auto-refresh every 10 minutes if left open
    if (d.ok && millis() - loaded > 600000UL) { c.header(); refresh(); draw(); loaded = millis(); }
  }
}
