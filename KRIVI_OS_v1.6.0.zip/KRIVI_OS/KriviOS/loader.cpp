// ============================================================================
//  KRIVI OS - Dynamic Binary / Parameter Launcher
//
//  The ESP32 cannot dynamically link native code into IRAM, so KRIVI uses two
//  complementary mechanisms:
//
//   1. PARAMETER MODE (default, all 43 apps)
//      App code lives in flash (memory-mapped, costs no RAM until called).
//      On tap, the loader frees the launcher's icon page cache, pages the
//      app's manifest  /sys/apps/app_NN.json  from the SD card into a JSON
//      arena, checks its heap budget and required files, then runs the app.
//      All app RAM (sprites, game grids, ROM images, samples) is allocated
//      on entry and released on exit; the loader audits heap before/after.
//
//   2. BINARY MODE (optional, per app)
//      If a manifest contains  "bin": "/apps/foo.bin", the loader streams
//      that firmware image from the SD card into the ota_1 partition and
//      reboots into it. External apps return with tools/krivi_return.h.
// ============================================================================
#include "krivi.h"
#include <Update.h>
#include <esp_ota_ops.h>

namespace loader {

static JsonDocument s_manifest;          // lives while the app runs

static void splashLine(int &y, const char *k, const char *v, uint16_t c = C_TEXT) {
  tft.setTextColor(C_DIM, C_BG);
  tft.drawString(k, 24, y, 1);
  tft.setTextColor(c, C_BG);
  tft.drawString(v, 110, y, 1);
  y += 12;
}

bool flashBinary(const char *path) {
  File f = SD.open(path);
  if (!f) { ui::msgBox("LOADER", "Binary not found on SD card."); return false; }
  size_t size = f.size();
  const esp_partition_t *next = esp_ota_get_next_update_partition(nullptr);
  if (!next || size > next->size) {
    f.close();
    ui::msgBox("LOADER", "Binary is larger than the ota_1 slot (1.56 MB).");
    return false;
  }
  tft.fillScreen(C_BG);
  ui::centerText("FLASHING EXTERNAL APP", 160, 70, C_WARN, C_BG, 4);
  ui::centerText(path, 160, 100, C_TEXT, C_BG, 2);
  if (!Update.begin(size, U_FLASH)) { f.close(); ui::msgBox("LOADER", "Update.begin failed"); return false; }
  static uint8_t buf[4096];
  size_t done = 0;
  while (done < size) {
    size_t n = f.read(buf, sizeof(buf));
    if (!n) break;
    if (Update.write(buf, n) != n) break;
    done += n;
    ui::bar(30, 130, 260, 18, (float)done / size, C_WARN, C_PANEL);
  }
  f.close();
  if (done != size || !Update.end(true)) {
    ui::msgBox("LOADER", "Flash failed - launcher kept.");
    return false;
  }
  sys::log("loader: flashed %s (%u B) -> %s, rebooting", path, (unsigned)size, next->label);
  ui::centerText("Rebooting into external app...", 160, 170, C_OK, C_BG, 2);
  delay(800);
  ESP.restart();
  return true;
}

bool launch(const AppDef &a) {
  sys::radiosOff();                          // abort a pending NTP sync
  s_manifest.clear();
  char path[32];
  snprintf(path, sizeof(path), "/sys/apps/app_%02d.json", a.id);
  bool hasMan = false;
  if (sys::sdOk) {
    File f = SD.open(path);
    if (f) { hasMan = !deserializeJson(s_manifest, f); f.close(); }
  }

  // ---- binary mode
  const char *bin = s_manifest["bin"] | "";
  if (bin[0]) {
    char msg[160];
    snprintf(msg, sizeof(msg), "%s is an external binary:\n%s\nFlash it to ota_1 and reboot?", a.name, bin);
    if (ui::confirm("EXTERNAL APP", msg)) flashBinary(bin);
    return false;
  }

  // ---- parameter mode splash
  tft.fillScreen(C_BG);
  tft.fillRoundRect(16, 18, 288, 204, 10, C_BG);
  tft.drawRoundRect(16, 18, 288, 204, 10, a.color);
  char b[64];
  snprintf(b, sizeof(b), "APP %02d", a.id);
  tft.setTextColor(a.color, C_BG);
  tft.drawString(b, 28, 28, 2);
  tft.setTextColor(C_TEXT, C_BG);
  tft.drawString(a.name, 28, 46, 4);
  int y = 82;
  uint32_t freeH = ESP.getFreeHeap(), big = ESP.getMaxAllocHeap();
  snprintf(b, sizeof(b), "%s %s", path + 10, hasMan ? "[paged in]" : "[defaults]");
  splashLine(y, "manifest", b, hasMan ? C_OK : C_WARN);
  JsonObject params = s_manifest["params"].as<JsonObject>();
  snprintf(b, sizeof(b), "%d keys", params.isNull() ? 0 : (int)params.size());
  splashLine(y, "parameters", b);
  snprintf(b, sizeof(b), "%u KB free / largest %u KB", freeH / 1024, big / 1024);
  splashLine(y, "heap", b);
  int need = s_manifest["min_heap_kb"] | 0;
  snprintf(b, sizeof(b), "%d KB", need);
  splashLine(y, "budget", b, (int)(big / 1024) >= need ? C_OK : C_ERR);
  String needs = a.needs;
  if (needs.length() > 34) needs = needs.substring(0, 33) + "~";
  splashLine(y, "requires", needs.c_str(), C_DIM);

  // required directory present?
  const char *reqDir = s_manifest["require_dir"] | "";
  if (reqDir[0]) {
    bool ok = sys::sdOk && SD.exists(reqDir);
    splashLine(y, "assets", reqDir, ok ? C_OK : C_WARN);
  }
  for (int i = 0; i <= 20; ++i) { ui::bar(28, 196, 264, 12, i / 20.0f, a.color, C_PANEL); delay(12); }

  if ((int)(big / 1024) < need) {
    snprintf(b, sizeof(b), "Needs %d KB contiguous heap, only %u KB available.", need, big / 1024);
    ui::msgBox("LOAD ABORTED", b);
    return false;
  }

  // ---- run
  AppCtx ctx;
  ctx.def = &a;
  ctx.params = params;
  ctx.t = &ui::state();
  ctx.lastFrame = millis();
  tft.fillScreen(C_BG);
  ctx.header();
  ui::clearEvents();
  sys::log("loader: start app %02d '%s' heap=%u big=%u", a.id, a.name, freeH, big);
  uint32_t t0 = millis();
  a.fn(ctx);

  // ---- reclaim
  audio::stopAll();
  audio::streamEnd();
  audio::setMaster(sys::cfg["sound"]["volume"] | 140);
  sys::radiosOff();
  sys::setLatch(sys::clapLatch);
  if (!sys::clapLatch) sys::led(0, 0, 0);
  delay(30);
  uint32_t after = ESP.getFreeHeap();
  int32_t leak = (int32_t)freeH - (int32_t)after;
  sys::log("loader: exit app %02d after %lus, heap %u -> %u%s", a.id,
           (unsigned long)((millis() - t0) / 1000), freeH, after,
           leak > 2048 ? " (retained)" : "");
  while (ui::state().down) { ui::poll(); delay(5); }
  ui::clearEvents();
  return true;
}
}  // namespace loader
