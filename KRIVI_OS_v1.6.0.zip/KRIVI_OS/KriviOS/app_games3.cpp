// ============================================================================
//  New games
//   59 CHIP-8 Virtual Machine   60 Space Invaders   61 Asteroids
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  59  CHIP-8 VM
//  Full CHIP-8 interpreter. Loads .ch8 from /roms, or a built-in original demo.
//  64x32 display scaled 4x; 16-key pad mapped to on-screen buttons.
// ============================================================================
namespace chip8 {
static uint8_t mem[4096], V[16], disp[64 * 32];
static uint16_t I, pc, stack[16]; static uint8_t sp, dt, st, keys[16];
static bool draw;
static const uint8_t FONT[80] = {
  0xF0,0x90,0x90,0x90,0xF0, 0x20,0x60,0x20,0x20,0x70, 0xF0,0x10,0xF0,0x80,0xF0, 0xF0,0x10,0xF0,0x10,0xF0,
  0x90,0x90,0xF0,0x10,0x10, 0xF0,0x80,0xF0,0x10,0xF0, 0xF0,0x80,0xF0,0x90,0xF0, 0xF0,0x10,0x20,0x40,0x40,
  0xF0,0x90,0xF0,0x90,0xF0, 0xF0,0x90,0xF0,0x10,0xF0, 0xF0,0x90,0xF0,0x90,0x90, 0xE0,0x90,0xE0,0x90,0xE0,
  0xF0,0x80,0x80,0x80,0xF0, 0xE0,0x90,0x90,0x90,0xE0, 0xF0,0x80,0xF0,0x80,0xF0, 0xF0,0x80,0xF0,0x80,0x80};
// A tiny original program: bounces a 4x4 ball around the screen (public, trivial).
static const uint8_t DEMO[] = {
  0x60,0x1C, 0x61,0x0E, 0x62,0x01, 0x63,0x01, 0xA2,0x40, 0x22,0x30,          // x=28,y=14,dx=1,dy=1; draw
  0xD0,0x14, 0x80,0x24, 0x81,0x34, 0xD0,0x14,                               // erase? (we just redraw)
  0x30,0x00,                                                                 // nop-ish
  0x40,0x3C, 0x62,0xFF, 0x30,0x00, 0x40,0x00, 0x62,0x01,                     // bounce x
  0x41,0x1C, 0x63,0xFF, 0x31,0x00, 0x41,0x00, 0x63,0x01,                     // bounce y
  0x12,0x08};
static void reset() {
  memset(mem, 0, sizeof(mem)); memset(V, 0, 16); memset(disp, 0, sizeof(disp)); memset(keys, 0, 16);
  memcpy(mem, FONT, 80); I = 0; pc = 0x200; sp = 0; dt = st = 0; draw = true;
}
static void step() {
  uint16_t op = (mem[pc] << 8) | mem[pc + 1]; pc += 2;
  uint8_t x = (op >> 8) & 0xF, y = (op >> 4) & 0xF, n = op & 0xF, kk = op & 0xFF; uint16_t nnn = op & 0xFFF;
  switch (op >> 12) {
    case 0x0: if (op == 0x00E0) { memset(disp, 0, sizeof(disp)); draw = true; } else if (op == 0x00EE) pc = stack[--sp & 0xF]; break;
    case 0x1: pc = nnn; break;
    case 0x2: stack[sp++ & 0xF] = pc; pc = nnn; break;
    case 0x3: if (V[x] == kk) pc += 2; break;
    case 0x4: if (V[x] != kk) pc += 2; break;
    case 0x5: if (V[x] == V[y]) pc += 2; break;
    case 0x6: V[x] = kk; break;
    case 0x7: V[x] += kk; break;
    case 0x8: switch (n) {
        case 0: V[x] = V[y]; break; case 1: V[x] |= V[y]; break; case 2: V[x] &= V[y]; break; case 3: V[x] ^= V[y]; break;
        case 4: { int s = V[x] + V[y]; V[0xF] = s > 255; V[x] = s; } break;
        case 5: { V[0xF] = V[x] >= V[y]; V[x] -= V[y]; } break;
        case 6: V[0xF] = V[x] & 1; V[x] >>= 1; break;
        case 7: { V[0xF] = V[y] >= V[x]; V[x] = V[y] - V[x]; } break;
        case 0xE: V[0xF] = V[x] >> 7; V[x] <<= 1; break; } break;
    case 0x9: if (V[x] != V[y]) pc += 2; break;
    case 0xA: I = nnn; break;
    case 0xB: pc = nnn + V[0]; break;
    case 0xC: V[x] = (esp_random() & 0xFF) & kk; break;
    case 0xD: {
      V[0xF] = 0;
      for (int r = 0; r < n; ++r) { uint8_t px = mem[(I + r) & 0xFFF];
        for (int b = 0; b < 8; ++b) if (px & (0x80 >> b)) {
          int dx = (V[x] + b) & 63, dy = (V[y] + r) & 31; int idx = dy * 64 + dx;
          if (disp[idx]) V[0xF] = 1; disp[idx] ^= 1; } }
      draw = true; } break;
    case 0xE: if (kk == 0x9E) { if (keys[V[x] & 0xF]) pc += 2; } else if (kk == 0xA1) { if (!keys[V[x] & 0xF]) pc += 2; } break;
    case 0xF: switch (kk) {
        case 0x07: V[x] = dt; break;
        case 0x0A: { int k = -1; for (int i = 0; i < 16; ++i) if (keys[i]) k = i; if (k < 0) pc -= 2; else V[x] = k; } break;
        case 0x15: dt = V[x]; break; case 0x18: st = V[x]; break; case 0x1E: I += V[x]; break;
        case 0x29: I = V[x] * 5; break;
        case 0x33: mem[I & 0xFFF] = V[x] / 100; mem[(I + 1) & 0xFFF] = (V[x] / 10) % 10; mem[(I + 2) & 0xFFF] = V[x] % 10; break;
        case 0x55: for (int i = 0; i <= x; ++i) mem[(I + i) & 0xFFF] = V[i]; break;
        case 0x65: for (int i = 0; i <= x; ++i) V[i] = mem[(I + i) & 0xFFF]; break; } break;
  }
}
}  // namespace chip8

void app_chip8(AppCtx &c) {
  using namespace chip8;
  String path = ui::pickFile("/roms", ".ch8", "CHIP-8 - pick a ROM (or EXIT for demo)");
  reset();
  if (path.length()) { File f = SD.open(path); if (f) { int n = f.read(mem + 0x200, 4096 - 0x200); f.close(); sys::log("chip8: %s %dB", path.c_str(), n); } }
  else { memcpy(mem + 0x200, DEMO, sizeof(DEMO)); }
  c.header(path.length() ? path.substring(path.lastIndexOf('/') + 1).c_str() : "built-in demo");
  // keypad layout (CHIP-8 hex) on the bottom third
  static const uint8_t KP[16] = {1, 2, 3, 0xC, 4, 5, 6, 0xD, 7, 8, 9, 0xE, 0xA, 0, 0xB, 0xF};
  const int KY = 140, KW = 80, KH = 25;
  auto drawKeys = [&]() {
    for (int i = 0; i < 16; ++i) { int kx = (i % 4) * KW, ky = KY + (i / 4) * KH;
      char s[3]; snprintf(s, 3, "%X", KP[i]);
      ui::button(kx + 1, ky + 1, KW - 2, KH - 2, s, C_PANEL2, C_TEXT, 2); }
  };
  auto render = [&]() {
    const int SX = 0, SY = 20, SC = 5;
    for (int y = 0; y < 32; ++y) for (int x = 0; x < 64; ++x)
      tft.fillRect(SX + x * SC, SY + y * SC, SC, SC, disp[y * 64 + x] ? RGB565(120, 255, 140) : RGB565(6, 20, 8));
  };
  tft.fillRect(0, 20, 320, 160, TFT_BLACK); drawKeys();
  uint32_t lastTimer = millis();
  while (true) {
    ui::clearEvents(); Touch &t = ui::poll();
    if (ui::exitHit(t)) break;
    memset(keys, 0, 16);
    if (t.down && t.y >= KY) { int i = (t.x / KW) + ((t.y - KY) / KH) * 4; if (i >= 0 && i < 16) keys[KP[i]] = 1; }
    for (int i = 0; i < 12; ++i) step();           // ~720 insns/s at 60fps
    if (millis() - lastTimer >= 16) { lastTimer = millis(); if (dt) dt--; if (st) { st--; audio::tone(7, 440, 60, audio::SQUARE, 20); } }
    if (draw) { render(); draw = false; }
    delay(14);
  }
  audio::stop(7);
}

// ============================================================================
//  60  SPACE INVADERS
// ============================================================================
void app_invaders(AppCtx &c) {
  const int ROWS = 4, COLS = 8, TOP = 34;
  struct { bool alive[4][8]; float ox, dir, oy; } g;
  float px; int lives, score, level;
  struct Shot { float x, y; bool on; }; Shot pb, eb[3];
newgame:
  lives = 3; score = 0; level = 1;
newwave:
  for (int r = 0; r < ROWS; ++r) for (int k = 0; k < COLS; ++k) g.alive[r][k] = true;
  g.ox = 20; g.oy = TOP; g.dir = 0.5f + level * 0.15f;
  px = 150; pb.on = false; for (auto &e : eb) e.on = false;
  ui::clearBody();
  {
    int opx = -1; uint32_t lastEb = 0;
    auto invX = [&](int k) { return (int)g.ox + k * 32; };
    auto invY = [&](int r) { return (int)g.oy + r * 22; };
    char hud[24];
    auto drawHud = [&]() { snprintf(hud, 24, "%d  L%d  \x03%d", score, level, lives); ::hud(hud); };
    drawHud();
    while (c.frame(22)) {
      Touch &t = *c.t;
      if (t.down && t.y > 180) px = constrain(t.x - 16, 4, 284);
      else if (t.down) px = constrain(t.x - 16, 4, 284);
      if (t.tap && !pb.on) { pb.on = true; pb.x = px + 16; pb.y = 210; audio::tone(0, 900, 60, audio::SQUARE, 50, 50); }
      // move fleet
      bool edge = false; int live = 0;
      for (int r = 0; r < ROWS; ++r) for (int k = 0; k < COLS; ++k) if (g.alive[r][k]) { live++; if (invX(k) < 4 || invX(k) > 288) edge = true; }
      if (!live) { level++; banner("WAVE CLEAR", "tap for next", C_OK); if (!waitTap(c)) return; goto newwave; }
      if (edge) { g.dir = -g.dir; g.oy += 10; }
      g.ox += g.dir;
      // enemy fire
      if (millis() - lastEb > 900 - level * 60) { lastEb = millis();
        for (auto &e : eb) if (!e.on) { int tries = 0; int r, k;
          do { k = rnd(COLS); r = ROWS - 1; while (r >= 0 && !g.alive[r][k]) r--; } while (r < 0 && ++tries < 8);
          if (r >= 0) { e.on = true; e.x = invX(k) + 12; e.y = invY(r) + 14; } break; } }
      // render
      tft.fillRect(0, TOP - 4, 320, 150, C_BG);
      for (int r = 0; r < ROWS; ++r) for (int k = 0; k < COLS; ++k) if (g.alive[r][k]) {
        int x = invX(k), y = invY(r); uint16_t col = ui::hsv(r * 40, 220, 255);
        tft.fillRoundRect(x, y, 22, 14, 3, col); tft.fillRect(x + 4, y - 3, 3, 4, col); tft.fillRect(x + 15, y - 3, 3, 4, col);
      }
      tft.fillRect((int)px, 212, 32, 10, C_ACCENT); tft.fillRect((int)px + 14, 206, 4, 6, C_ACCENT);
      if (pb.on) { pb.y -= 9; tft.fillRect((int)pb.x, (int)pb.y, 2, 8, TFT_WHITE); if (pb.y < TOP - 4) pb.on = false;
        for (int r = 0; r < ROWS && pb.on; ++r) for (int k = 0; k < COLS; ++k) if (g.alive[r][k]) {
          int x = invX(k), y = invY(r); if (pb.x >= x && pb.x <= x + 22 && pb.y >= y - 3 && pb.y <= y + 14) {
            g.alive[r][k] = false; pb.on = false; score += (ROWS - r) * 10; drawHud(); audio::tone(1, 300, 70, audio::NOISE, 60, 60); break; } } }
      for (auto &e : eb) if (e.on) { e.y += 4; tft.fillRect((int)e.x, (int)e.y, 2, 8, C_WARN);
        if (e.y > 230) e.on = false;
        else if (e.x >= px && e.x <= px + 32 && e.y >= 212) { e.on = false; lives--; drawHud(); audio::tone(0, 150, 110, audio::SAW, 300, 300);
          if (lives <= 0) { banner("GAME OVER", "tap to restart", C_ERR); if (!waitTap(c)) return; goto newgame; } } }
      // invaders reach bottom
      for (int r = 0; r < ROWS; ++r) for (int k = 0; k < COLS; ++k) if (g.alive[r][k] && invY(r) > 196) { lives = 0; banner("INVADED!", "tap to restart", C_ERR); if (!waitTap(c)) return; goto newgame; }
    }
  }
}

// ============================================================================
//  61  ASTEROIDS
// ============================================================================
void app_asteroids(AppCtx &c) {
  struct Ro { float x, y, vx, vy, a, va; int size; bool on; };
  struct Bu { float x, y, vx, vy; int life; bool on; };
  Ro roid[12]; Bu bull[6];
  float sx, sy, sa, svx, svy; int lives, score;
  auto wrap = [](float &v, float m) { if (v < 0) v += m; if (v >= m) v -= m; };
  auto spawnRoids = [&](int n) { for (auto &r : roid) r.on = false;
    for (int i = 0; i < n && i < 12; ++i) { Ro &r = roid[i]; r.on = true; r.size = 3;
      r.x = rnd(320); r.y = rnd(240); if (fabsf(r.x - 160) < 60) r.x += 120;
      float a = rnd(628) / 100.0f; float sp = 0.4f + rnd(60) / 100.0f; r.vx = cosf(a) * sp; r.vy = sinf(a) * sp; r.a = a; r.va = (rnd(100) - 50) / 800.0f; } };
newgame:
  lives = 3; score = 0;
  sx = 160; sy = 130; sa = -PI / 2; svx = svy = 0;
  spawnRoids(4); for (auto &b : bull) b.on = false;
  ui::clearBody();
  ui::button(2, 206, 60, 32, "< ", C_PANEL2, C_TEXT, 4); ui::button(64, 206, 60, 32, " >", C_PANEL2, C_TEXT, 4);
  ui::button(128, 206, 70, 32, "THRUST", C_PANEL2, C_TEXT, 1); ui::button(200, 206, 60, 32, "FIRE", RGB565(180, 40, 60));
  uint32_t lastFire = 0;
  while (c.frame(20)) {
    Touch &t = *c.t;
    if (t.down && t.y > 204) {
      if (t.x < 62) sa -= 0.16f; else if (t.x < 124) sa += 0.16f;
      else if (t.x < 198) { svx += cosf(sa) * 0.22f; svy += sinf(sa) * 0.22f; }
      else if (millis() - lastFire > 220) { lastFire = millis();
        for (auto &b : bull) if (!b.on) { b.on = true; b.x = sx + cosf(sa) * 10; b.y = sy + sinf(sa) * 10; b.vx = cosf(sa) * 6 + svx; b.vy = sinf(sa) * 6 + svy; b.life = 60; audio::tone(0, 1200, 40, audio::SQUARE, 30, 30); break; } }
    }
    svx *= 0.99f; svy *= 0.99f; sx += svx; sy += svy; wrap(sx, 320); wrap(sy, 200); if (sy < 26) sy += 174;
    tft.fillRect(0, 26, 320, 178, C_BG);
    // ship
    float c1 = cosf(sa), s1 = sinf(sa);
    int x1 = sx + c1 * 10, y1 = sy + s1 * 10, x2 = sx + cosf(sa + 2.5f) * 8, y2 = sy + sinf(sa + 2.5f) * 8, x3 = sx + cosf(sa - 2.5f) * 8, y3 = sy + sinf(sa - 2.5f) * 8;
    tft.drawTriangle(x1, y1, x2, y2, x3, y3, C_ACCENT);
    int alive = 0;
    for (auto &r : roid) if (r.on) { alive++;
      r.x += r.vx; r.y += r.vy; r.a += r.va; wrap(r.x, 320); if (r.y < 26) r.y += 178; if (r.y >= 204) r.y -= 178;
      int rad = r.size * 7;
      for (int i = 0; i < 8; ++i) { float a1 = r.a + i * PI / 4, a2 = r.a + (i + 1) * PI / 4; float rr = rad * (0.8f + 0.2f * ((i * 37) % 10) / 10.0f);
        tft.drawLine(r.x + cosf(a1) * rr, r.y + sinf(a1) * rr, r.x + cosf(a2) * rad, r.y + sinf(a2) * rad, RGB565(180, 180, 190)); }
      // ship collision
      if (fabsf(r.x - sx) < rad + 6 && fabsf(r.y - sy) < rad + 6) { lives--; audio::tone(0, 120, 110, audio::NOISE, 400, 400);
        hud(""); if (lives <= 0) { banner("GAME OVER", "tap to restart", C_ERR); if (!waitTap(c)) return; goto newgame; }
        sx = 160; sy = 130; svx = svy = 0; } }
    for (auto &b : bull) if (b.on) { b.x += b.vx; b.y += b.vy; wrap(b.x, 320); if (b.y < 26) b.y += 178; if (b.y >= 204) b.y -= 178;
      if (--b.life <= 0) { b.on = false; continue; } tft.fillRect((int)b.x, (int)b.y, 2, 2, TFT_WHITE);
      for (auto &r : roid) if (r.on) { int rad = r.size * 7; if (fabsf(r.x - b.x) < rad && fabsf(r.y - b.y) < rad) {
        b.on = false; score += (4 - r.size) * 20 + 20; audio::tone(1, 400, 60, audio::NOISE, 60, 60);
        if (r.size > 1) { r.size--; r.va *= 1.5f; for (auto &nr : roid) if (!nr.on) { nr = r; nr.on = true; float a = rnd(628) / 100.0f; nr.vx = cosf(a); nr.vy = sinf(a); break; } }
        else r.on = false; break; } } }
    char h[24]; snprintf(h, 24, "%d  \x03%d", score, lives); hud(h);
    if (!alive) { banner("CLEARED", "tap for more", C_OK); if (!waitTap(c)) return; spawnRoids(4 + score / 500); }
  }
}
