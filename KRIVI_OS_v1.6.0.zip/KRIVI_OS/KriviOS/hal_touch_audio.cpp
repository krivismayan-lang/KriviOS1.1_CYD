// ============================================================================
//  KRIVI OS - hardware abstraction: XPT2046 touch + I2S/DAC audio engine
// ============================================================================
#include "krivi.h"
#include <driver/i2s.h>
#include <driver/dac.h>
#include <driver/rtc_io.h>

TFT_eSPI tft = TFT_eSPI();

// ============================================================================
//  XPT2046 resistive touch - software SPI on the CYD's dedicated touch pins.
//  (The SD card owns the hardware VSPI bus, the TFT owns HSPI, so bit-banging
//   the slow touch controller avoids any bus contention.)
// ============================================================================
namespace touch {
static bool s_present = false;

static inline uint8_t xfer8(uint8_t out) {
  uint8_t in = 0;
  for (int i = 7; i >= 0; --i) {
    digitalWrite(PIN_TP_MOSI, (out >> i) & 1);
    delayMicroseconds(1);
    digitalWrite(PIN_TP_CLK, HIGH);
    delayMicroseconds(1);
    in = (in << 1) | digitalRead(PIN_TP_MISO);
    digitalWrite(PIN_TP_CLK, LOW);
  }
  return in;
}
// Mirrors SPI.transfer16(cmd) in XPT2046_Touchscreen: the 16-bit word is
// 0x00 then `cmd`. The first 16 clocks shift out the PREVIOUS conversion
// while the next control byte goes out in the second byte. (Sending `cmd`
// first restarts the ADC mid-read and every sample comes back as garbage.)
static inline uint16_t xfer16(uint8_t cmd) {
  uint16_t hi = xfer8(0);
  uint16_t lo = xfer8(cmd);
  return (hi << 8) | lo;
}
static int16_t besttwoavg(int16_t x, int16_t y, int16_t z) {
  int16_t da = abs(x - z), db = abs(x - y), dc = abs(z - y);
  if (da <= db && da <= dc) return (x + z) >> 1;
  if (db <= da && db <= dc) return (x + y) >> 1;
  return (y + z) >> 1;
}

void begin() {
  // GPIO25 is DAC1 *and* the touch clock: make sure the audio driver left it
  // as a plain digital pin.
  dac_output_disable(DAC_CHANNEL_1);
  rtc_gpio_deinit(GPIO_NUM_25);
  gpio_reset_pin(GPIO_NUM_25);
  pinMode(PIN_TP_CLK, OUTPUT);
  pinMode(PIN_TP_MOSI, OUTPUT);
  pinMode(PIN_TP_CS, OUTPUT);
  pinMode(PIN_TP_MISO, INPUT);
  pinMode(PIN_TP_IRQ, INPUT);
  digitalWrite(PIN_TP_CS, HIGH);
  digitalWrite(PIN_TP_CLK, LOW);
  // probe: a powered controller returns a temperature/aux value != 0/4095
  digitalWrite(PIN_TP_CS, LOW);
  xfer8(0xA4);                                 // VBAT/aux, keeps ref on
  uint16_t v = xfer16(0x00) >> 3;
  digitalWrite(PIN_TP_CS, HIGH);
  s_present = (v != 0 && v != 4095) || digitalRead(PIN_TP_MISO) == 0;
}
bool present() { return s_present; }

// Same measurement sequence as PaulStoffregen/XPT2046_Touchscreen with
// setRotation(1), so p.x / p.y match the user's calibration constants.
bool readRaw(int16_t &rx, int16_t &ry, int16_t &rz) {
  int16_t data[6];
  digitalWrite(PIN_TP_CS, LOW);
  xfer8(0xB1);
  int16_t z1 = xfer16(0xC1) >> 3;
  int z = z1 + 4095;
  int16_t z2 = xfer16(0x91) >> 3;
  z -= z2;
  if (z >= 400) {
    xfer16(0x91);                              // first X is always noisy
    data[0] = xfer16(0xD1) >> 3;
    data[1] = xfer16(0x91) >> 3;
    data[2] = xfer16(0xD1) >> 3;
    data[3] = xfer16(0x91) >> 3;
  } else {
    data[0] = data[1] = data[2] = data[3] = 0;
  }
  data[4] = xfer16(0xD0) >> 3;                 // power down
  data[5] = xfer16(0) >> 3;
  digitalWrite(PIN_TP_CS, HIGH);
  if (z < 0) z = 0;
  rz = z;
  if (z < 400) return false;
  rx = besttwoavg(data[0], data[2], data[4]);
  ry = besttwoavg(data[1], data[3], data[5]);
  return true;
}

bool read(int16_t &sx, int16_t &sy) {
  int16_t rx, ry, rz;
  if (!readRaw(rx, ry, rz)) return false;
  struct { int16_t x, y; } p = {rx, ry};

  // 🎯 CRITICAL: Copy-Paste this exact high-precision touch map layout into the code
  int touchX = map(p.x, 300, 3600, 0, 320);   // Perfect horizontal landscape calibration
  int touchY = map(p.y, 500, 3700, 0, 240);   // Perfect vertical landscape calibration

  // Boundary constraint shield to prevent coordinate data leak crashes
  touchX = constrain(touchX, 0, 319);
  touchY = constrain(touchY, 0, 239);

  // Optional per-panel orientation fixes from /sys/settings.json
  // ("touch": {"invertX": false, "invertY": false})
  if (sys::cfg["touch"]["invertX"] | false) touchX = 319 - touchX;
  if (sys::cfg["touch"]["invertY"] | false) touchY = 239 - touchY;
  if (sys::cfg["display"]["flip"] | false) { touchX = 319 - touchX; touchY = 239 - touchY; }

  sx = touchX; sy = touchY;
  return true;
}
}  // namespace touch

// ============================================================================
//  Audio engine
//  I2S0 in built-in-DAC mode drives DAC2 (GPIO26 -> speaker amp) via DMA.
//  A mixer task on core 0 renders 8 voices (oscillators or PCM samples) plus
//  an optional hook (the MOD tracker) into 128-sample blocks (~5.8 ms).
// ============================================================================
namespace audio {

struct Voice {
  volatile uint8_t kind = 0;      // 0 off, 1 oscillator, 2 sample
  uint8_t  wave = SQUARE;
  uint32_t phase = 0, inc = 0;
  int32_t  vol = 0;               // 8.8 fixed
  int32_t  decay = 0;             // subtract per sample (8.8)
  uint32_t remain = 0;            // samples left, 0 = infinite
  int8_t   noiseVal = 0;
  const int8_t *data = nullptr;
  uint32_t len = 0, pos = 0, step = 0;  // pos/step 16.16
  bool     loop = false;
};

static Voice  V[VOICES];
static int8_t SINE_T[256];
static volatile uint8_t s_master = 140;
static volatile Hook s_hook = nullptr;
static void *volatile s_hookUser = nullptr;
static bool s_ok = false;
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t s_rng = 0x1234567;

static inline int8_t oscSample(Voice &v) {
  uint32_t p = v.phase;
  uint32_t np = p + v.inc;
  int8_t s;
  switch (v.wave) {
    case SINE:     s = SINE_T[p >> 24]; break;
    case TRIANGLE: { int t = (p >> 23) & 0x1FF; s = (t < 256) ? (t - 128) : (383 - t); } break;
    case SAW:      s = (int8_t)((p >> 24) - 128); break;
    case NOISE:
      if ((p ^ np) & 0x10000000) {
        s_rng ^= s_rng << 13; s_rng ^= s_rng >> 17; s_rng ^= s_rng << 5;
        v.noiseVal = (int8_t)(s_rng & 0xFF);
      }
      s = v.noiseVal; break;
    default:       s = (p & 0x80000000) ? 100 : -100; break;
  }
  v.phase = np;
  return s;
}

// ---- PCM stream (MP3 player, movie soundtrack): ring buffer of int16 mono
static int16_t *s_ring = nullptr;
static uint32_t s_rSize = 0;
static volatile uint32_t s_rHead = 0, s_rTail = 0;
static volatile uint32_t s_srcRate = 22050, s_acc = 0;
static volatile uint32_t s_played = 0;
static volatile bool s_paused = false;
static volatile int16_t s_last = 0;
static volatile uint8_t s_streamVol = 255;

static inline void streamRender(int32_t *mix, int n) {
  if (!s_ring || s_paused) return;
  uint32_t step = (uint32_t)(((uint64_t)s_srcRate << 16) / RATE);
  uint32_t acc = s_acc, tail = s_rTail, head = s_rHead;
  int32_t last = s_last;
  for (int i = 0; i < n; ++i) {
    acc += step;
    uint32_t whole = acc >> 16; acc &= 0xFFFF;
    if (whole) {                          // box-filter the consumed samples
      int32_t sum = 0; uint32_t cnt = 0;
      while (whole-- && tail != head) { sum += s_ring[tail]; tail = (tail + 1) % s_rSize; cnt++; }
      if (cnt) { last = sum / (int32_t)cnt; s_played += cnt; }
      else last = last * 7 / 8;            // underrun: fade instead of click
    }
    mix[i] += ((last >> 8) * s_streamVol) >> 8;
  }
  s_acc = acc; s_rTail = tail; s_last = last;
}

bool streamBegin(uint32_t rate, uint32_t ringSamples) {
  streamEnd();
  int16_t *r = (int16_t *)malloc(ringSamples * 2);
  if (!r) return false;
  s_rSize = ringSamples; s_rHead = s_rTail = 0; s_acc = 0; s_played = 0; s_last = 0;
  s_srcRate = rate ? rate : 22050; s_paused = false;
  s_ring = r;
  return true;
}
void streamSetRate(uint32_t rate) { if (rate) s_srcRate = rate; }
size_t streamSpace() {
  if (!s_ring) return 0;
  uint32_t h = s_rHead, t = s_rTail;
  return (t + s_rSize - h - 1) % s_rSize;
}
size_t streamWrite(const int16_t *s, size_t n) {
  if (!s_ring) return 0;
  size_t w = 0;
  while (w < n) {
    size_t sp = streamSpace();
    if (!sp) { if (s_paused) break; vTaskDelay(1); continue; }
    uint32_t h = s_rHead;
    size_t k = min(sp, n - w);
    for (size_t i = 0; i < k; ++i) { s_ring[h] = s[w + i]; h = (h + 1) % s_rSize; }
    s_rHead = h; w += k;
  }
  return w;
}
size_t streamQueued() { return s_ring ? s_rSize - 1 - streamSpace() : 0; }
uint32_t streamPlayed() { return s_played; }
void streamPause(bool p) { s_paused = p; }
void streamFlush() { s_rTail = s_rHead; }
void streamVolume(uint8_t v) { s_streamVol = v; }
void streamEnd() {
  int16_t *r = s_ring;
  s_ring = nullptr;
  delay(15);                               // let the mixer leave streamRender
  free(r);
  s_rSize = 0;
}

static void audioTask(void *) {
  const int N = 128;
  static int32_t mix[N];
  static uint16_t out[N * 2];
  for (;;) {
    memset(mix, 0, sizeof(mix));
    for (int vi = 0; vi < VOICES; ++vi) {
      Voice &v = V[vi];
      uint8_t k = v.kind;
      if (!k) continue;
      for (int i = 0; i < N; ++i) {
        int32_t s;
        if (k == 1) {
          s = oscSample(v);
        } else {
          uint32_t idx = v.pos >> 16;
          if (idx >= v.len) {
            if (v.loop && v.len) { v.pos = 0; idx = 0; }
            else { v.kind = 0; break; }
          }
          s = v.data[idx];
          v.pos += v.step;
        }
        mix[i] += (s * (v.vol >> 8)) >> 7;
        if (v.decay) { v.vol -= v.decay; if (v.vol <= 0) { v.vol = 0; v.kind = 0; break; } }
        if (v.remain) { if (--v.remain == 0) { v.kind = 0; break; } }
      }
    }
    Hook h = s_hook;
    if (h) h(mix, N, s_hookUser);
    streamRender(mix, N);
    uint32_t m = s_master;
    for (int i = 0; i < N; ++i) {
      int32_t s = (mix[i] * (int32_t)m) >> 8;
      if (s > 127) s = 127; else if (s < -128) s = -128;
      uint16_t u = (uint16_t)((s + 128) << 8);
      out[2 * i] = u; out[2 * i + 1] = u;
    }
    size_t wr;
    i2s_write(I2S_NUM_0, out, sizeof(out), &wr, portMAX_DELAY);
  }
}

bool begin() {
  for (int i = 0; i < 256; ++i) SINE_T[i] = (int8_t)(127.0f * sinf(i * 2.0f * PI / 256.0f));
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN);
  cfg.sample_rate = RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_MSB;
  cfg.intr_alloc_flags = 0;
  cfg.dma_buf_count = 4;
  cfg.dma_buf_len = 128;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = true;
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, nullptr) != ESP_OK) return false;
  // Only DAC2 (GPIO26). DAC1 would hijack GPIO25 = touch clock.
  i2s_set_dac_mode(I2S_DAC_CHANNEL_LEFT_EN);
  dac_output_disable(DAC_CHANNEL_1);
  xTaskCreatePinnedToCore(audioTask, "audio", 3072, nullptr, 5, nullptr, 0);
  s_ok = true;
  return true;
}
bool ok() { return s_ok; }

static inline uint32_t hzToInc(float hz) {
  return (uint32_t)((double)hz * 4294967296.0 / RATE);
}

void tone(uint8_t vi, float hz, uint8_t vol, Wave w, uint32_t ms, uint16_t decayMs) {
  if (vi >= VOICES) return;
  Voice &v = V[vi];
  portENTER_CRITICAL(&s_mux);
  v.kind = 0;
  v.wave = w; v.inc = hzToInc(hz); v.vol = (int32_t)vol << 8;
  v.remain = ms ? (uint32_t)((uint64_t)ms * RATE / 1000) : 0;
  v.decay = decayMs ? (int32_t)(((int32_t)vol << 8) / ((int32_t)decayMs * (int32_t)RATE / 1000)) : 0;
  if (decayMs && !v.decay) v.decay = 1;
  v.kind = 1;
  portEXIT_CRITICAL(&s_mux);
}
void setFreq(uint8_t vi, float hz) { if (vi < VOICES) V[vi].inc = hzToInc(hz); }

void sample(uint8_t vi, const int8_t *data, uint32_t len, uint32_t rate, uint8_t vol, bool loop) {
  if (vi >= VOICES || !data || !len) return;
  Voice &v = V[vi];
  portENTER_CRITICAL(&s_mux);
  v.kind = 0;
  v.data = data; v.len = len; v.pos = 0;
  v.step = (uint32_t)(((uint64_t)rate << 16) / RATE);
  v.vol = (int32_t)vol << 8; v.decay = 0; v.remain = 0; v.loop = loop;
  v.kind = 2;
  portEXIT_CRITICAL(&s_mux);
}
void stop(uint8_t vi) { if (vi < VOICES) V[vi].kind = 0; }
void stopAll() { for (auto &v : V) v.kind = 0; s_hook = nullptr; }
bool active(uint8_t vi) { return vi < VOICES && V[vi].kind; }
void beep(float hz, uint32_t ms, uint8_t vol) { tone(7, hz, vol, SQUARE, ms); }
void click() {
  if (sys::cfg["sound"]["clicks"] | true) tone(7, 2400, 60, SQUARE, 12, 12);
}
void setMaster(uint8_t vol) { s_master = vol; }
uint8_t master() { return s_master; }
void setHook(Hook fn, void *user) { s_hook = nullptr; s_hookUser = user; s_hook = fn; }
}  // namespace audio
