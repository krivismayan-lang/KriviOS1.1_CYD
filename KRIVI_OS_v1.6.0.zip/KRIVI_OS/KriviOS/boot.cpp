// ============================================================================
//  KRIVI OS - 4-second diagnostic boot sequence
//  Every line reports a real probe of the hardware; pacing pads each stage so
//  the whole log + escalating load bar lasts ~4 s.
// ============================================================================
#include "krivi.h"
#include <esp_system.h>
#include <esp_ota_ops.h>
#include <esp_chip_info.h>
#include <WiFi.h>

namespace {
const int CON_Y0 = 16, CON_LH = 9, CON_LINES = 20;
const int BAR_Y = 210;
const uint32_t BOOT_MS = 4000;

struct Ln { String s; uint16_t c; };
std::vector<Ln> lines;          // whole log (saved to SD at the end)
uint32_t t0;
float shownPct = 0;

void drawConsole() {
  int first = max(0, (int)lines.size() - CON_LINES);
  for (int i = 0; i < CON_LINES; ++i) {
    int y = CON_Y0 + i * CON_LH;
    tft.fillRect(0, y, SCR_W, CON_LH, TFT_BLACK);
    int idx = first + i;
    if (idx >= (int)lines.size()) continue;
    const Ln &l = lines[idx];
    // "[  1.234567] " timestamp in dim green, rest coloured
    int br = l.s.indexOf(']');
    tft.setTextColor(RGB565(0, 120, 60), TFT_BLACK);
    tft.drawString(l.s.substring(0, br + 1), 2, y, 1);
    tft.setTextColor(l.c, TFT_BLACK);
    tft.drawString(l.s.substring(br + 1), 2 + (br + 1) * 6, y, 1);
  }
}

void drawBar(float pct, const char *stage) {
  int x = 8, w = 304, h = 14;
  tft.drawRect(x, BAR_Y, w, h, RGB565(0, 160, 80));
  int segs = 38, segW = (w - 4) / segs;
  int lit = (int)(segs * pct / 100.0f + 0.5f);
  for (int i = 0; i < segs; ++i) {
    uint16_t c = i < lit ? ui::hsv(140 - i * 140 / segs, 230, 255) : RGB565(10, 22, 14);
    tft.fillRect(x + 2 + i * segW, BAR_Y + 2, segW - 1, h - 4, c);
  }
  char b[48];
  snprintf(b, sizeof(b), "%3d%%  %-32s", (int)pct, stage);
  tft.setTextColor(RGB565(120, 255, 160), TFT_BLACK);
  tft.drawString(b, 8, BAR_Y + 18, 1);
}

// Pad elapsed time up to the stage's slot while animating the bar
void paceTo(float pct, const char *stage) {
  uint32_t target = (uint32_t)(BOOT_MS * pct / 100.0f);
  float from = shownPct;
  while (millis() - t0 < target) {
    float f = (float)(millis() - t0) / target;
    float p = from + (pct - from) * min(1.0f, f);
    drawBar(p, stage);
    delay(25);
  }
  shownPct = pct;
  drawBar(pct, stage);
}

void klog(uint16_t c, const char *fmt, ...) {
  char body[96];
  va_list ap; va_start(ap, fmt); vsnprintf(body, sizeof(body), fmt, ap); va_end(ap);
  char ln[120];
  uint32_t us = micros();
  snprintf(ln, sizeof(ln), "[%3lu.%06lu] %s", (unsigned long)(us / 1000000), (unsigned long)(us % 1000000), body);
  lines.push_back({String(ln), c});
  Serial.println(ln);
  drawConsole();
}
#define OK_(...)   klog(RGB565(80, 255, 120), __VA_ARGS__)
#define INF(...)   klog(RGB565(170, 210, 190), __VA_ARGS__)
#define WRN(...)   klog(C_WARN, __VA_ARGS__)
#define BAD(...)   klog(C_ERR, __VA_ARGS__)

const char *resetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "power-on";
    case ESP_RST_SW:      return "software";
    case ESP_RST_PANIC:   return "panic";
    case ESP_RST_INT_WDT: case ESP_RST_TASK_WDT: case ESP_RST_WDT: return "watchdog";
    case ESP_RST_BROWNOUT: return "brownout";
    case ESP_RST_DEEPSLEEP: return "deep-sleep";
    default: return "other";
  }
}

int countFiles(const char *dir, const char *ext) {
  return (int)sys::listDir(dir, ext).size();
}
}  // namespace

void boot_sequence() {
  t0 = millis();
  tft.fillScreen(TFT_BLACK);
  tft.fillRect(0, 0, SCR_W, 13, RGB565(0, 60, 30));
  tft.setTextColor(RGB565(140, 255, 180), RGB565(0, 60, 30));
  tft.drawString("KRIVI OS " KRIVI_VERSION "  ::  SYSTEM DIAGNOSTICS  ::  ESP32-2432S028", 4, 3, 1);
  drawBar(0, "power-on self test");

  // ---------------------------------------------------------------- CPU
  esp_chip_info_t ci; esp_chip_info(&ci);
  INF("KRIVI kernel " KRIVI_VERSION " (xtensa-lx6) #1 SMP PREEMPT");
  OK_("cpu: %s rev%d, %d cores @ %lu MHz", ESP.getChipModel(), ESP.getChipRevision(),
      ci.cores, (unsigned long)ESP.getCpuFreqMHz());
  INF("rst: last reset reason = %s", resetReason());
  paceTo(5, "cpu / clocks");

  OK_("flash: %u MB @ %u MHz, sketch %u KB", ESP.getFlashChipSize() / 1048576,
      ESP.getFlashChipSpeed() / 1000000, ESP.getSketchSize() / 1024);
  const esp_partition_t *run = esp_ota_get_running_partition();
  const esp_partition_t *nxt = esp_ota_get_next_update_partition(nullptr);
  INF("part: running '%s' @0x%06x, ext slot '%s' %u KB", run ? run->label : "?",
      run ? run->address : 0, nxt ? nxt->label : "-", nxt ? nxt->size / 1024 : 0);
  OK_("mem: heap %u KB free / %u KB, max block %u KB", ESP.getFreeHeap() / 1024,
      ESP.getHeapSize() / 1024, ESP.getMaxAllocHeap() / 1024);
  INF("mem: psram %s", ESP.getPsramSize() ? "present" : "absent (internal SRAM only)");
  paceTo(14, "memory map");

  // ---------------------------------------------------------------- display
  OK_("spi1: HSPI SCLK=14 MOSI=13 MISO=12 @ 55 MHz");
  OK_("tft: %s 320x240 rot=1 (landscape) BL=GPIO21", KRIVI_PANEL_NAME);
  uint16_t px = tft.readPixel(2, 2);
  INF("tft: readback probe 0x%04x (%s)", px, px != 0xFFFF ? "MISO ok" : "no MISO");
  paceTo(22, "display bus");

  // ---------------------------------------------------------------- SD
  INF("spi2: VSPI SCLK=18 MOSI=23 MISO=19 CS=5 @ 20 MHz");
  SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
  sys::sdOk = SD.begin(PIN_SD_CS, SPI, 20000000);
  if (sys::sdOk) {
    const char *ty = "?";
    switch (SD.cardType()) { case CARD_MMC: ty = "MMC"; break; case CARD_SD: ty = "SDSC"; break;
                             case CARD_SDHC: ty = "SDHC"; break; default: break; }
    sys::sdSizeMB = SD.cardSize() / 1048576ULL;
    OK_("mmc0: %s card %llu MB, FAT used %s", ty, sys::sdSizeMB,
        sys::humanSize(SD.usedBytes()).c_str());
    const char *dirs[] = {"/sys", "/sys/boot", "/sys/apps", "/icons", "/roms", "/data",
                          "/data/paint", "/data/chiptunes", "/data/reader", "/data/video",
                          "/data/music", "/data/movies", "/icons/weather"};
    int made = 0;
    for (auto d : dirs) if (!SD.exists(d)) { SD.mkdir(d); made++; }
    if (made) WRN("vfs: created %d missing directories", made);
    else OK_("vfs: directory tree verified (13 nodes)");
  } else {
    BAD("mmc0: mount FAILED - running in degraded (no SD) mode");
  }
  paceTo(38, "mounting microSD");

  bool cfgOk = sys::loadSettings();
  if (cfgOk) OK_("cfg: /sys/settings.json parsed (%d sections)", (int)sys::cfg.as<JsonObject>().size());
  else WRN("cfg: settings.json missing/invalid - defaults loaded");
  if (sys::cfg["display"]["flip"] | false) { tft.setRotation(3); INF("tft: display flipped (rot=3)"); }
  if (sys::sdOk) {
    int icons = countFiles("/icons", ".raw");
    (icons >= launcher::APP_COUNT ? (void)OK_("icons: %d/%d raw 40x40 rgb565 assets", icons, launcher::APP_COUNT)
                 : (void)WRN("icons: %d/%d found, vector fallback for rest", icons, launcher::APP_COUNT));
    INF("assets: roms=%d mods=%d mp3=%d texts=%d", countFiles("/roms", ".nes"),
        countFiles("/data/chiptunes", ".mod"), countFiles("/data/music", ".mp3"),
        countFiles("/data/reader", ".txt"));
    INF("assets: movies=%d (avi)  clips=%d (mjpeg)", countFiles("/data/movies", ".avi"),
        countFiles("/data/video", ".mjpeg"));
  }
  paceTo(50, "registry / assets");

  // ---------------------------------------------------------------- audio
  if (audio::begin()) OK_("i2s0: DAC2 GPIO26 %lu Hz, DMA 4x128, 8 voices", (unsigned long)audio::RATE);
  else BAD("i2s0: driver install failed - audio disabled");
  paceTo(58, "audio engine");

  // ---------------------------------------------------------------- touch
  touch::begin();
  if (touch::present()) OK_("xpt2046: soft-SPI CLK=25 MOSI=32 MISO=39 CS=33");
  else WRN("xpt2046: no response on soft-SPI - check ribbon");
  INF("xpt2046: map x[300..3600]->[0..319] y[500..3700]->[0..239]");
  INF("xpt2046: IRQ GPIO36 level=%d (idle high)", digitalRead(PIN_TP_IRQ));
  OK_("input: exit vector X[%d..%d] Y[%d..%d] registered", EXIT_X0, EXIT_X1, EXIT_Y0, EXIT_Y1);
  paceTo(70, "touch mapping");

  // ---------------------------------------------------------------- GPIO / ADC
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_MIC, ADC_11db);
  long acc = 0; for (int i = 0; i < 64; ++i) acc += analogRead(PIN_MIC);
  INF("adc1: IO35 (P3 mic) baseline %ld / 4095", acc / 64);
  INF("adc1: IO34 LDR ambient %d / 4095", analogRead(PIN_LDR));
  sys::led(255, 0, 0); delay(70); sys::led(0, 255, 0); delay(70); sys::led(0, 0, 255); delay(70); sys::led(0, 0, 0);
  OK_("gpio: RGB LED R4 G16 B17 cycled, relay IO22 = LOW");
  paceTo(80, "gpio / adc");

  // ---------------------------------------------------------------- radio / clock
  INF("rf: WiFi/BT controllers deferred (on-demand per app)");
  INF("rf: base MAC %s", WiFi.macAddress().c_str());
  const char *ssid = sys::cfg["wifi"]["ssid"] | "";
  if (ssid[0]) { sys::startNtp(); OK_("rtc: NTP sync scheduled via '%s'", ssid); }
  else WRN("rtc: no WiFi configured - clock set manually (app 26)");
  paceTo(88, "radio / clock");

  // ---------------------------------------------------------------- loader
  int mans = sys::sdOk ? countFiles("/sys/apps", ".json") : 0;
  OK_("loader: %d apps / 5 pages, %d SD manifests", launcher::APP_COUNT, mans);
  OK_("loader: app heap budget %u KB contiguous", ESP.getMaxAllocHeap() / 1024);
  paceTo(96, "dynamic loader");

  if (sys::sdOk) {
    File f = SD.open("/sys/boot/boot_last.log", FILE_WRITE);
    if (f) { for (auto &l : lines) f.println(l.s); f.close(); }
    OK_("log: /sys/boot/boot_last.log written");
  }
  OK_("init: handing off to launcher");
  paceTo(100, "ready");
  audio::tone(0, 523.25f, 70, audio::SINE, 90, 90);
  delay(90);
  audio::tone(0, 783.99f, 70, audio::SINE, 160, 160);
  sys::log("boot complete in %lu ms", (unsigned long)(millis() - t0));
  delay(250);
  lines.clear(); lines.shrink_to_fit();
}
