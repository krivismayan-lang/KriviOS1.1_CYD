// ============================================================================
//  01  NES EMULATOR LAUNCHPAD
//  Compact NES core for the ESP32 (no PSRAM):
//   - full official 6502 instruction set, cycle counted, NMI + OAM DMA
//   - scanline PPU: loopy scrolling, 8x8/8x16 sprites, sprite-0 hit,
//     8-sprite limit, left-column clipping, palette mirroring
//   - mappers 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM)
//   - ROM image is paged from /roms/*.nes into heap at launch
//   - adaptive frame-skip; APU not emulated (silent) to keep speed
//  Supply your own legally-dumped ROMs.
// ============================================================================
#include "apps_common.h"

namespace nes {

// ---------------------------------------------------------------- state
static uint8_t *prg = nullptr, *chr = nullptr, *sram = nullptr;
static uint32_t prgSize, chrSize;
static bool chrRam;
static uint8_t mapperId, mirror;          // mirror: 0 horiz 1 vert 2 single0 3 single1
static const uint8_t *prgMap[4];
static uint8_t *chrMap[8];
static uint8_t ram[2048], vram[2048], pal[32], oam[256];

static uint8_t m1shift, m1ctrl, m1chr0, m1chr1, m1prg;
// MMC3 (mapper 4) state
static uint8_t m3bank[8], m3sel;
static uint8_t m3irqLatch, m3irqCounter;
static bool m3irqReload, m3irqEnable;
static bool irqPending;                          // maskable IRQ line (MMC3)

static uint8_t pctrl, pmask, pstat, oamaddr, rbuf, fineX;
static uint16_t pv, pt;
static bool pw;

static uint8_t A, X, Y, S, fC, fZ, fN, fV, fI, fD;
static uint16_t PC;
static int32_t cyc;
static bool nmiReq;
static uint8_t pad, padLatch, strobe;

static uint16_t lineBuf[256 * 8];
static uint16_t nesPal[64];                // byte-swapped RGB565

static const uint32_t NES_RGB[64] = {
  0x666666,0x002A88,0x1412A7,0x3B00A4,0x5C007E,0x6E0040,0x6C0600,0x561D00,0x333500,0x0B4800,0x005200,0x004F08,0x00404D,0,0,0,
  0xADADAD,0x155FD9,0x4240FF,0x7527FE,0xA01ACC,0xB71E7B,0xB53120,0x994E00,0x6B6D00,0x388700,0x0C9300,0x008F32,0x007C8D,0,0,0,
  0xFFFEFF,0x64B0FF,0x9290FF,0xC676FF,0xF36AFF,0xFE6ECC,0xFE8170,0xEA9E22,0xBCBE00,0x88D800,0x5CE430,0x45E082,0x48CDDE,0x4F4F4F,0,0,
  0xFFFEFF,0xC0DFFF,0xD3D2FF,0xE8C8FF,0xFBC2FF,0xFEC4EA,0xFECCC5,0xF7D8A5,0xE4E594,0xCFEF96,0xBDF4AB,0xB3F3CC,0xB5EBF2,0xB8B8B8,0,0};

// ---------------------------------------------------------------- mapping
static inline void setPrg16(int slot, int bank) {
  int n = prgSize / 16384; bank %= n; if (bank < 0) bank += n;
  prgMap[slot * 2] = prg + bank * 16384;
  prgMap[slot * 2 + 1] = prg + bank * 16384 + 8192;
}
static inline void setChr4(int slot, int bank) {
  int n = max(1u, chrSize / 4096); bank %= n;
  for (int i = 0; i < 4; ++i) chrMap[slot * 4 + i] = chr + bank * 4096 + i * 1024;
}
static void m1update() {
  static const uint8_t mm[4] = {2, 3, 1, 0};
  mirror = mm[m1ctrl & 3];
  int pm = (m1ctrl >> 2) & 3;
  if (pm < 2) { setPrg16(0, (m1prg & 0x0E)); setPrg16(1, (m1prg & 0x0E) + 1); }
  else if (pm == 2) { setPrg16(0, 0); setPrg16(1, m1prg & 0x0F); }
  else { setPrg16(0, m1prg & 0x0F); setPrg16(1, prgSize / 16384 - 1); }
  if (m1ctrl & 0x10) { setChr4(0, m1chr0); setChr4(1, m1chr1); }
  else { setChr4(0, m1chr0 & 0x1E); setChr4(1, (m1chr0 & 0x1E) + 1); }
}
// ---- MMC3 bank mapping: 8KB PRG banks (R6,R7 + two fixed), 1KB/2KB CHR banks
static void m3update() {
  int prgN = prgSize / 8192; if (prgN < 1) prgN = 1;
  int chrN = (int)(chrSize / 1024); if (chrN < 1) chrN = 1;
  auto P = [&](int slot, int bank) { bank %= prgN; if (bank < 0) bank += prgN; prgMap[slot] = prg + bank * 8192; };
  auto C = [&](int slot, int bank) { bank %= chrN; if (bank < 0) bank += chrN; chrMap[slot] = chr + bank * 1024; };
  if (!(m3sel & 0x40)) { P(0, m3bank[6]); P(1, m3bank[7]); P(2, prgN - 2); P(3, prgN - 1); }
  else                 { P(0, prgN - 2); P(1, m3bank[7]); P(2, m3bank[6]); P(3, prgN - 1); }
  if (!(m3sel & 0x80)) {              // CHR A12 = 0: two 2KB then four 1KB
    C(0, m3bank[0] & 0xFE); C(1, (m3bank[0] & 0xFE) | 1);
    C(2, m3bank[1] & 0xFE); C(3, (m3bank[1] & 0xFE) | 1);
    C(4, m3bank[2]); C(5, m3bank[3]); C(6, m3bank[4]); C(7, m3bank[5]);
  } else {                            // inverted
    C(0, m3bank[2]); C(1, m3bank[3]); C(2, m3bank[4]); C(3, m3bank[5]);
    C(4, m3bank[0] & 0xFE); C(5, (m3bank[0] & 0xFE) | 1);
    C(6, m3bank[1] & 0xFE); C(7, (m3bank[1] & 0xFE) | 1);
  }
}
// Clocked once per rendered scanline (approximates the MMC3 A12 counter): this
// is what lets Super Mario Bros. 3 and other MMC3 games split the screen for a
// static status bar without crashing.
static inline void m3clock() {
  if (m3irqCounter == 0 || m3irqReload) { m3irqCounter = m3irqLatch; m3irqReload = false; }
  else m3irqCounter--;
  if (m3irqCounter == 0 && m3irqEnable) irqPending = true;
}
static void mapperWrite(uint16_t a, uint8_t v) {
  switch (mapperId) {
    case 4:
      switch (a & 0xE001) {
        case 0x8000: m3sel = v; m3update(); break;
        case 0x8001: m3bank[m3sel & 7] = v; m3update(); break;
        case 0xA000: mirror = (v & 1) ? 0 : 1; break;   // 1 = horizontal, 0 = vertical
        case 0xA001: break;                             // PRG-RAM protect (ignored)
        case 0xC000: m3irqLatch = v; break;
        case 0xC001: m3irqCounter = 0; m3irqReload = true; break;
        case 0xE000: m3irqEnable = false; irqPending = false; break;
        case 0xE001: m3irqEnable = true; break;
      }
      break;
    case 1:
      if (v & 0x80) { m1shift = 0x10; m1ctrl |= 0x0C; m1update(); return; }
      {
        bool full = m1shift & 1;
        m1shift = (m1shift >> 1) | ((v & 1) << 4);
        if (full) {
          uint8_t val = m1shift;
          switch ((a >> 13) & 3) { case 0: m1ctrl = val; break; case 1: m1chr0 = val; break;
                                   case 2: m1chr1 = val; break; case 3: m1prg = val; break; }
          m1shift = 0x10; m1update();
        }
      }
      break;
    case 2: setPrg16(0, v); break;
    case 3: setChr4(0, (v & 3) * 2); setChr4(1, (v & 3) * 2 + 1); break;
    default: break;
  }
}

static inline uint16_t ntIdx(uint16_t a) {
  a &= 0x0FFF;
  switch (mirror) {
    case 0: return ((a >> 1) & 0x400) | (a & 0x3FF);
    case 1: return a & 0x7FF;
    case 2: return a & 0x3FF;
    default: return 0x400 | (a & 0x3FF);
  }
}
static inline uint8_t chrRd(uint16_t a) { return chrMap[(a >> 10) & 7][a & 0x3FF]; }
static inline uint8_t palIdx(uint16_t a) { a &= 0x1F; if ((a & 0x13) == 0x10) a &= ~0x10; return a; }

static uint8_t ppuRead(uint16_t a) {
  a &= 0x3FFF;
  if (a < 0x2000) return chrRd(a);
  if (a < 0x3F00) return vram[ntIdx(a)];
  return pal[palIdx(a)];
}
static void ppuWrite(uint16_t a, uint8_t v) {
  a &= 0x3FFF;
  if (a < 0x2000) { if (chrRam) chrMap[(a >> 10) & 7][a & 0x3FF] = v; }
  else if (a < 0x3F00) vram[ntIdx(a)] = v;
  else pal[palIdx(a)] = v & 0x3F;
}

static inline uint8_t rd(uint16_t a);
static uint8_t ioRead(uint16_t a) {
  if (a < 0x4000) {
    switch (a & 7) {
      case 2: { uint8_t r = (pstat & 0xE0) | (rbuf & 0x1F); pstat &= 0x7F; pw = false; return r; }
      case 4: return oam[oamaddr];
      case 7: {
        uint8_t r;
        if ((pv & 0x3FFF) < 0x3F00) { r = rbuf; rbuf = ppuRead(pv); }
        else { r = ppuRead(pv); rbuf = ppuRead(pv - 0x1000); }
        pv += (pctrl & 4) ? 32 : 1;
        return r;
      }
      default: return rbuf;
    }
  }
  if (a == 0x4016) {
    uint8_t r = strobe ? (pad & 1) : (padLatch & 1);
    if (!strobe) padLatch = (padLatch >> 1) | 0x80;
    return 0x40 | r;
  }
  return 0x40;
}
static void ioWrite(uint16_t a, uint8_t v) {
  if (a < 0x4000) {
    switch (a & 7) {
      case 0: {
        bool wasOff = !(pctrl & 0x80);
        pctrl = v; pt = (pt & 0xF3FF) | ((v & 3) << 10);
        if (wasOff && (v & 0x80) && (pstat & 0x80)) nmiReq = true;
      } break;
      case 1: pmask = v; break;
      case 3: oamaddr = v; break;
      case 4: oam[oamaddr++] = v; break;
      case 5:
        if (!pw) { pt = (pt & 0xFFE0) | (v >> 3); fineX = v & 7; }
        else pt = (pt & 0x8C1F) | ((v & 0xF8) << 2) | ((v & 7) << 12);
        pw = !pw; break;
      case 6:
        if (!pw) pt = (pt & 0x80FF) | ((v & 0x3F) << 8);
        else { pt = (pt & 0xFF00) | v; pv = pt; }
        pw = !pw; break;
      case 7: ppuWrite(pv, v); pv += (pctrl & 4) ? 32 : 1; break;
    }
    return;
  }
  if (a == 0x4014) {
    uint16_t base = v << 8;
    for (int i = 0; i < 256; ++i) oam[(oamaddr + i) & 0xFF] = rd(base + i);
    cyc += 513;
  } else if (a == 0x4016) {
    strobe = v & 1;
    if (strobe) padLatch = pad;
  }
}

static inline uint8_t rd(uint16_t a) {
  if (a >= 0x8000) return prgMap[(a >> 13) & 3][a & 0x1FFF];
  if (a < 0x2000) return ram[a & 0x7FF];
  if (a >= 0x6000) return sram[a & 0x1FFF];
  return ioRead(a);
}
static inline void wr(uint16_t a, uint8_t v) {
  if (a < 0x2000) ram[a & 0x7FF] = v;
  else if (a >= 0x8000) mapperWrite(a, v);
  else if (a >= 0x6000) sram[a & 0x1FFF] = v;
  else ioWrite(a, v);
}

// ---------------------------------------------------------------- 6502
#define SETNZ(v) { fZ = ((uint8_t)(v)) == 0; fN = ((uint8_t)(v)) >> 7; }
static inline uint8_t getP(bool b) { return (fN << 7) | (fV << 6) | 0x20 | (b ? 0x10 : 0) | (fD << 3) | (fI << 2) | (fZ << 1) | fC; }
static inline void setP(uint8_t p) { fN = p >> 7; fV = (p >> 6) & 1; fD = (p >> 3) & 1; fI = (p >> 2) & 1; fZ = (p >> 1) & 1; fC = p & 1; }
static inline void push(uint8_t v) { ram[0x100 | S] = v; S--; }
static inline uint8_t pop() { S++; return ram[0x100 | S]; }
static inline uint16_t rd16(uint16_t a) { return rd(a) | (rd(a + 1) << 8); }

static inline uint16_t amAbs() { uint16_t a = rd16(PC); PC += 2; return a; }
static inline uint16_t amAbI(uint8_t i, bool pen) {
  uint16_t b = rd16(PC); PC += 2; uint16_t a = b + i;
  if (pen && ((a ^ b) & 0xFF00)) cyc++;
  return a;
}
static inline uint16_t amIndX() { uint8_t z = rd(PC++) + X; return ram[z] | (ram[(uint8_t)(z + 1)] << 8); }
static inline uint16_t amIndY(bool pen) {
  uint8_t z = rd(PC++); uint16_t b = ram[z] | (ram[(uint8_t)(z + 1)] << 8); uint16_t a = b + Y;
  if (pen && ((a ^ b) & 0xFF00)) cyc++;
  return a;
}
static inline void adc(uint8_t v) {
  uint16_t s = A + v + fC;
  fV = ((~(A ^ v) & (A ^ s)) & 0x80) != 0; fC = s > 0xFF; A = (uint8_t)s; SETNZ(A);
}
static inline void cmpr(uint8_t r, uint8_t v) { fC = r >= v; SETNZ((uint8_t)(r - v)); }
static inline uint8_t asl(uint8_t v) { fC = v >> 7; v <<= 1; SETNZ(v); return v; }
static inline uint8_t lsr(uint8_t v) { fC = v & 1; v >>= 1; SETNZ(v); return v; }
static inline uint8_t rol(uint8_t v) { uint8_t c = fC; fC = v >> 7; v = (v << 1) | c; SETNZ(v); return v; }
static inline uint8_t ror(uint8_t v) { uint8_t c = fC; fC = v & 1; v = (v >> 1) | (c << 7); SETNZ(v); return v; }
static inline uint8_t inc8(uint8_t v) { v++; SETNZ(v); return v; }
static inline uint8_t dec8(uint8_t v) { v--; SETNZ(v); return v; }
static inline void branch(bool c) {
  int8_t off = (int8_t)rd(PC++);
  cyc += 2;
  if (c) { uint16_t np = PC + off; cyc += ((np ^ PC) & 0xFF00) ? 2 : 1; PC = np; }
}
static void nmi() {
  push(PC >> 8); push(PC & 0xFF); push(getP(false));
  fI = 1; PC = rd16(0xFFFA); cyc += 7;
}
static void irq() {                              // maskable IRQ (MMC3 scanline)
  push(PC >> 8); push(PC & 0xFF); push(getP(false));
  fI = 1; PC = rd16(0xFFFE); cyc += 7;
}
static void reset() {
  A = X = Y = 0; S = 0xFD; setP(0x24); PC = rd16(0xFFFC); cyc = 0; irqPending = false;
}

#define LD(r, am, cy)   { r = rd(am); SETNZ(r); cyc += cy; } break
#define ST(r, am, cy)   { wr(am, r); cyc += cy; } break
#define ALU(op, am, cy) { uint8_t v_ = rd(am); op; cyc += cy; } break
#define RMW(f, am, cy)  { uint16_t a_ = am; uint8_t v_ = rd(a_); wr(a_, f(v_)); cyc += cy; } break
#define OP_ORA A |= v_; SETNZ(A)
#define OP_AND A &= v_; SETNZ(A)
#define OP_EOR A ^= v_; SETNZ(A)
#define OP_ADC adc(v_)
#define OP_SBC adc(v_ ^ 0xFF)
#define OP_CMP cmpr(A, v_)
#define OP_CPX cmpr(X, v_)
#define OP_CPY cmpr(Y, v_)
#define OP_BIT fZ = (A & v_) == 0; fN = v_ >> 7; fV = (v_ >> 6) & 1
#define ZP  rd(PC++)
#define ZPX (uint8_t)(rd(PC++) + X)
#define ZPY (uint8_t)(rd(PC++) + Y)
#define IMM PC++

// runs until cyc >= target
static void run(int32_t target) {
  while (cyc < target) {
    if (nmiReq) { nmiReq = false; nmi(); }
    else if (irqPending && !fI) { irqPending = false; irq(); }
    uint8_t op = rd(PC++);
    switch (op) {
      // ORA AND EOR ADC CMP SBC LDA STA
      case 0x09: ALU(OP_ORA, IMM, 2); case 0x05: ALU(OP_ORA, ZP, 3); case 0x15: ALU(OP_ORA, ZPX, 4);
      case 0x0D: ALU(OP_ORA, amAbs(), 4); case 0x1D: ALU(OP_ORA, amAbI(X, 1), 4); case 0x19: ALU(OP_ORA, amAbI(Y, 1), 4);
      case 0x01: ALU(OP_ORA, amIndX(), 6); case 0x11: ALU(OP_ORA, amIndY(1), 5);
      case 0x29: ALU(OP_AND, IMM, 2); case 0x25: ALU(OP_AND, ZP, 3); case 0x35: ALU(OP_AND, ZPX, 4);
      case 0x2D: ALU(OP_AND, amAbs(), 4); case 0x3D: ALU(OP_AND, amAbI(X, 1), 4); case 0x39: ALU(OP_AND, amAbI(Y, 1), 4);
      case 0x21: ALU(OP_AND, amIndX(), 6); case 0x31: ALU(OP_AND, amIndY(1), 5);
      case 0x49: ALU(OP_EOR, IMM, 2); case 0x45: ALU(OP_EOR, ZP, 3); case 0x55: ALU(OP_EOR, ZPX, 4);
      case 0x4D: ALU(OP_EOR, amAbs(), 4); case 0x5D: ALU(OP_EOR, amAbI(X, 1), 4); case 0x59: ALU(OP_EOR, amAbI(Y, 1), 4);
      case 0x41: ALU(OP_EOR, amIndX(), 6); case 0x51: ALU(OP_EOR, amIndY(1), 5);
      case 0x69: ALU(OP_ADC, IMM, 2); case 0x65: ALU(OP_ADC, ZP, 3); case 0x75: ALU(OP_ADC, ZPX, 4);
      case 0x6D: ALU(OP_ADC, amAbs(), 4); case 0x7D: ALU(OP_ADC, amAbI(X, 1), 4); case 0x79: ALU(OP_ADC, amAbI(Y, 1), 4);
      case 0x61: ALU(OP_ADC, amIndX(), 6); case 0x71: ALU(OP_ADC, amIndY(1), 5);
      case 0xE9: case 0xEB: ALU(OP_SBC, IMM, 2); case 0xE5: ALU(OP_SBC, ZP, 3); case 0xF5: ALU(OP_SBC, ZPX, 4);
      case 0xED: ALU(OP_SBC, amAbs(), 4); case 0xFD: ALU(OP_SBC, amAbI(X, 1), 4); case 0xF9: ALU(OP_SBC, amAbI(Y, 1), 4);
      case 0xE1: ALU(OP_SBC, amIndX(), 6); case 0xF1: ALU(OP_SBC, amIndY(1), 5);
      case 0xC9: ALU(OP_CMP, IMM, 2); case 0xC5: ALU(OP_CMP, ZP, 3); case 0xD5: ALU(OP_CMP, ZPX, 4);
      case 0xCD: ALU(OP_CMP, amAbs(), 4); case 0xDD: ALU(OP_CMP, amAbI(X, 1), 4); case 0xD9: ALU(OP_CMP, amAbI(Y, 1), 4);
      case 0xC1: ALU(OP_CMP, amIndX(), 6); case 0xD1: ALU(OP_CMP, amIndY(1), 5);
      case 0xE0: ALU(OP_CPX, IMM, 2); case 0xE4: ALU(OP_CPX, ZP, 3); case 0xEC: ALU(OP_CPX, amAbs(), 4);
      case 0xC0: ALU(OP_CPY, IMM, 2); case 0xC4: ALU(OP_CPY, ZP, 3); case 0xCC: ALU(OP_CPY, amAbs(), 4);
      case 0x24: ALU(OP_BIT, ZP, 3); case 0x2C: ALU(OP_BIT, amAbs(), 4);
      case 0xA9: LD(A, IMM, 2); case 0xA5: LD(A, ZP, 3); case 0xB5: LD(A, ZPX, 4); case 0xAD: LD(A, amAbs(), 4);
      case 0xBD: LD(A, amAbI(X, 1), 4); case 0xB9: LD(A, amAbI(Y, 1), 4); case 0xA1: LD(A, amIndX(), 6); case 0xB1: LD(A, amIndY(1), 5);
      case 0xA2: LD(X, IMM, 2); case 0xA6: LD(X, ZP, 3); case 0xB6: LD(X, ZPY, 4); case 0xAE: LD(X, amAbs(), 4); case 0xBE: LD(X, amAbI(Y, 1), 4);
      case 0xA0: LD(Y, IMM, 2); case 0xA4: LD(Y, ZP, 3); case 0xB4: LD(Y, ZPX, 4); case 0xAC: LD(Y, amAbs(), 4); case 0xBC: LD(Y, amAbI(X, 1), 4);
      case 0x85: ST(A, ZP, 3); case 0x95: ST(A, ZPX, 4); case 0x8D: ST(A, amAbs(), 4); case 0x9D: ST(A, amAbI(X, 0), 5);
      case 0x99: ST(A, amAbI(Y, 0), 5); case 0x81: ST(A, amIndX(), 6); case 0x91: ST(A, amIndY(0), 6);
      case 0x86: ST(X, ZP, 3); case 0x96: ST(X, ZPY, 4); case 0x8E: ST(X, amAbs(), 4);
      case 0x84: ST(Y, ZP, 3); case 0x94: ST(Y, ZPX, 4); case 0x8C: ST(Y, amAbs(), 4);
      // shifts / inc / dec
      case 0x0A: A = asl(A); cyc += 2; break;
      case 0x06: RMW(asl, ZP, 5); case 0x16: RMW(asl, ZPX, 6); case 0x0E: RMW(asl, amAbs(), 6); case 0x1E: RMW(asl, amAbI(X, 0), 7);
      case 0x4A: A = lsr(A); cyc += 2; break;
      case 0x46: RMW(lsr, ZP, 5); case 0x56: RMW(lsr, ZPX, 6); case 0x4E: RMW(lsr, amAbs(), 6); case 0x5E: RMW(lsr, amAbI(X, 0), 7);
      case 0x2A: A = rol(A); cyc += 2; break;
      case 0x26: RMW(rol, ZP, 5); case 0x36: RMW(rol, ZPX, 6); case 0x2E: RMW(rol, amAbs(), 6); case 0x3E: RMW(rol, amAbI(X, 0), 7);
      case 0x6A: A = ror(A); cyc += 2; break;
      case 0x66: RMW(ror, ZP, 5); case 0x76: RMW(ror, ZPX, 6); case 0x6E: RMW(ror, amAbs(), 6); case 0x7E: RMW(ror, amAbI(X, 0), 7);
      case 0xE6: RMW(inc8, ZP, 5); case 0xF6: RMW(inc8, ZPX, 6); case 0xEE: RMW(inc8, amAbs(), 6); case 0xFE: RMW(inc8, amAbI(X, 0), 7);
      case 0xC6: RMW(dec8, ZP, 5); case 0xD6: RMW(dec8, ZPX, 6); case 0xCE: RMW(dec8, amAbs(), 6); case 0xDE: RMW(dec8, amAbI(X, 0), 7);
      case 0xE8: X++; SETNZ(X); cyc += 2; break;  case 0xC8: Y++; SETNZ(Y); cyc += 2; break;
      case 0xCA: X--; SETNZ(X); cyc += 2; break;  case 0x88: Y--; SETNZ(Y); cyc += 2; break;
      // transfers
      case 0xAA: X = A; SETNZ(X); cyc += 2; break; case 0xA8: Y = A; SETNZ(Y); cyc += 2; break;
      case 0x8A: A = X; SETNZ(A); cyc += 2; break; case 0x98: A = Y; SETNZ(A); cyc += 2; break;
      case 0xBA: X = S; SETNZ(X); cyc += 2; break; case 0x9A: S = X; cyc += 2; break;
      // stack
      case 0x48: push(A); cyc += 3; break;
      case 0x08: push(getP(true)); cyc += 3; break;
      case 0x68: A = pop(); SETNZ(A); cyc += 4; break;
      case 0x28: setP(pop()); cyc += 4; break;
      // flags
      case 0x18: fC = 0; cyc += 2; break; case 0x38: fC = 1; cyc += 2; break;
      case 0x58: fI = 0; cyc += 2; break; case 0x78: fI = 1; cyc += 2; break;
      case 0xB8: fV = 0; cyc += 2; break; case 0xD8: fD = 0; cyc += 2; break; case 0xF8: fD = 1; cyc += 2; break;
      // branches
      case 0x10: branch(!fN); break; case 0x30: branch(fN); break;
      case 0x50: branch(!fV); break; case 0x70: branch(fV); break;
      case 0x90: branch(!fC); break; case 0xB0: branch(fC); break;
      case 0xD0: branch(!fZ); break; case 0xF0: branch(fZ); break;
      // jumps
      case 0x4C: PC = rd16(PC); cyc += 3; break;
      case 0x6C: { uint16_t p = rd16(PC); PC = rd(p) | (rd((p & 0xFF00) | ((p + 1) & 0xFF)) << 8); cyc += 5; } break;
      case 0x20: { uint16_t a = rd16(PC); PC++; push(PC >> 8); push(PC & 0xFF); PC = a; cyc += 6; } break;
      case 0x60: { uint16_t l = pop(); uint16_t h = pop(); PC = ((h << 8) | l) + 1; cyc += 6; } break;
      case 0x40: { setP(pop()); uint16_t l = pop(); uint16_t h = pop(); PC = (h << 8) | l; cyc += 6; } break;
      case 0x00: { PC++; push(PC >> 8); push(PC & 0xFF); push(getP(true)); fI = 1; PC = rd16(0xFFFE); cyc += 7; } break;
      // NOPs (official + common unofficial)
      case 0xEA: case 0x1A: case 0x3A: case 0x5A: case 0x7A: case 0xDA: case 0xFA: cyc += 2; break;
      case 0x80: case 0x82: case 0x89: case 0xC2: case 0xE2: case 0x04: case 0x44: case 0x64: PC++; cyc += 3; break;
      case 0x14: case 0x34: case 0x54: case 0x74: case 0xD4: case 0xF4: PC++; cyc += 4; break;
      case 0x0C: case 0x1C: case 0x3C: case 0x5C: case 0x7C: case 0xDC: case 0xFC: PC += 2; cyc += 4; break;
      default: cyc += 2; break;   // unsupported unofficial opcode: skip
    }
  }
}

// ---------------------------------------------------------------- PPU
static inline void incY() {
  if ((pv & 0x7000) != 0x7000) pv += 0x1000;
  else {
    pv &= ~0x7000;
    int y = (pv & 0x03E0) >> 5;
    if (y == 29) { y = 0; pv ^= 0x0800; } else if (y == 31) y = 0; else y++;
    pv = (pv & ~0x03E0) | (y << 5);
  }
}

// Render scanline `sl`. out==nullptr -> only evaluate (sprite-0 hit).
static void renderLine(int sl, uint16_t *out) {
  static uint8_t bg[256 + 16];
  static uint8_t sp[256];
  bool bgOn = pmask & 0x08, spOn = pmask & 0x10;
  int h = (pctrl & 0x20) ? 16 : 8;

  // sprite evaluation first (we need to know if sprite 0 is here)
  uint8_t sel[8]; int ns = 0; bool s0 = false;
  if (spOn) {
    for (int i = 0; i < 64; ++i) {
      int row = sl - (oam[i * 4] + 1);
      if (row >= 0 && row < h) {
        if (ns == 8) { pstat |= 0x20; break; }
        sel[ns++] = i; if (i == 0) s0 = true;
      }
    }
  }
  if (!out && !(s0 && bgOn)) return;

  if (bgOn) {
    uint16_t vv = pv;
    int fy = (vv >> 12) & 7;
    uint16_t base = (pctrl & 0x10) ? 0x1000 : 0;
    int px = -fineX;
    for (int tile = 0; tile < 33; ++tile) {
      uint8_t ti = vram[ntIdx(0x2000 | (vv & 0x0FFF))];
      uint8_t at = vram[ntIdx(0x23C0 | (vv & 0x0C00) | ((vv >> 4) & 0x38) | ((vv >> 2) & 7))];
      int shift = ((vv >> 4) & 4) | (vv & 2);
      uint8_t ph = ((at >> shift) & 3) << 2;
      uint16_t pa = base + ti * 16 + fy;
      uint8_t lo = chrRd(pa), hi = chrRd(pa + 8);
      for (int b = 0; b < 8; ++b, ++px) {
        if (px < 0 || px > 255) continue;
        uint8_t p = ((lo >> (7 - b)) & 1) | (((hi >> (7 - b)) & 1) << 1);
        bg[px] = p ? (ph | p) : 0;
      }
      if ((vv & 0x1F) == 31) { vv &= ~0x1F; vv ^= 0x400; } else vv++;
    }
    if (!(pmask & 0x02)) memset(bg, 0, 8);
  } else memset(bg, 0, 256);

  memset(sp, 0, 256);
  for (int k = ns - 1; k >= 0; --k) {
    int i = sel[k];
    uint8_t tile = oam[i * 4 + 1], attr = oam[i * 4 + 2], x = oam[i * 4 + 3];
    int row = sl - (oam[i * 4] + 1);
    if (attr & 0x80) row = h - 1 - row;
    uint16_t addr;
    if (h == 8) addr = ((pctrl & 0x08) ? 0x1000 : 0) + tile * 16 + row;
    else addr = ((tile & 1) ? 0x1000 : 0) + (tile & 0xFE) * 16 + (row >= 8 ? 16 : 0) + (row & 7);
    uint8_t lo = chrRd(addr), hi = chrRd(addr + 8);
    for (int b = 0; b < 8; ++b) {
      int xx = x + b;
      if (xx > 255) break;
      int bit = (attr & 0x40) ? b : 7 - b;
      uint8_t p = ((lo >> bit) & 1) | (((hi >> bit) & 1) << 1);
      if (!p) continue;
      if (xx < 8 && !(pmask & 0x04)) continue;
      sp[xx] = 0x80 | ((attr & 0x20) ? 0x40 : 0) | 0x10 | ((attr & 3) << 2) | p;
      if (i == 0 && bgOn && (bg[xx] & 3) && xx != 255) pstat |= 0x40;
    }
  }
  if (!out) return;
  for (int x = 0; x < 256; ++x) {
    uint8_t s = sp[x], b = bg[x];
    uint8_t ci;
    if ((s & 0x80) && (!(s & 0x40) || !(b & 3))) ci = pal[s & 0x1F];
    else ci = (b & 3) ? pal[b] : pal[0];
    out[x] = nesPal[ci & 0x3F];
  }
}

static int s_skip = 0;
static void frame(bool draw) {
  bool rendering = pmask & 0x18;
  for (int sl = 0; sl < 262; ++sl) {
    if (sl == 241) {
      pstat |= 0x80;
      if (pctrl & 0x80) nmiReq = true;
    }
    if (sl == 261) {
      pstat &= ~0xE0;
      rendering = pmask & 0x18;
      if (rendering) pv = (pv & 0x041F) | (pt & 0x7BE0);
    }
    run(cyc + ((sl % 3 == 2) ? 113 : 114));
    if (sl < 240) {
      rendering = pmask & 0x18;
      bool vis = draw && sl >= 8 && sl < 232;
      uint16_t *o = vis ? &lineBuf[((sl - 8) & 7) * 256] : nullptr;
      if (rendering) {
        renderLine(sl, o);
        if (mapperId == 4) m3clock();          // MMC3 scanline IRQ counter
        incY();
        pv = (pv & ~0x041F) | (pt & 0x041F);
      } else if (o) {
        uint16_t c = nesPal[pal[0] & 0x3F];
        for (int x = 0; x < 256; ++x) o[x] = c;
      }
      if (vis && ((sl - 8) & 7) == 7) tft.pushImage(0, 16 + (sl - 8) - 7, 256, 8, lineBuf);
    }
  }
  cyc -= 29780;
}

// ---------------------------------------------------------------- loader
static bool load(const String &path, String &err) {
  File f = SD.open(path);
  if (!f) { err = "cannot open file"; return false; }
  uint8_t h[16];
  if (f.read(h, 16) != 16 || memcmp(h, "NES\x1A", 4)) { f.close(); err = "not an iNES file"; return false; }
  mapperId = (h[6] >> 4) | (h[7] & 0xF0);
  if (mapperId != 0 && mapperId != 1 && mapperId != 2 && mapperId != 3 && mapperId != 4) {
    f.close(); err = "mapper " + String(mapperId) + " unsupported (0-4)"; return false;
  }
  if (h[6] & 4) f.seek(16 + 512);                // trainer
  prgSize = h[4] * 16384; chrSize = h[5] * 8192;
  chrRam = chrSize == 0; if (chrRam) chrSize = 8192;
  uint32_t need = prgSize + chrSize + 8192;
  if (prgSize > ESP.getMaxAllocHeap() || need > ESP.getFreeHeap() - 24000) {
    f.close();
    err = "ROM needs " + String(need / 1024) + " KB of RAM; this CYD has no PSRAM, only ~"
          + String((ESP.getFreeHeap() - 24000) / 1024) + " KB free. (e.g. SMB3 is too big.)";
    return false;
  }
  prg = (uint8_t *)malloc(prgSize);
  chr = (uint8_t *)malloc(chrSize);
  sram = (uint8_t *)calloc(8192, 1);
  if (!prg || !chr || !sram) { f.close(); err = "out of memory (" + String(need / 1024) + " KB)"; return false; }
  f.read(prg, prgSize);
  if (!chrRam) f.read(chr, chrSize); else memset(chr, 0, chrSize);
  f.close();
  mirror = (h[6] & 1) ? 1 : 0;
  setPrg16(0, 0); setPrg16(1, prgSize / 16384 - 1);
  setChr4(0, 0); setChr4(1, 1);
  if (mapperId == 1) { m1shift = 0x10; m1ctrl = 0x0C; m1chr0 = m1chr1 = m1prg = 0; m1update(); }
  if (mapperId == 4) {
    memset(m3bank, 0, sizeof(m3bank)); m3sel = 0;
    m3irqLatch = m3irqCounter = 0; m3irqReload = false; m3irqEnable = false; irqPending = false;
    mirror = (h[6] & 1) ? 1 : 0;
    m3update();                                  // sets R6/R7 + two fixed PRG banks, CHR banks
  }
  return true;
}
static void unload() {
  free(prg); free(chr); free(sram); prg = chr = sram = nullptr;
}
}  // namespace nes

// ---------------------------------------------------------------- UI
enum { NB_A = 0x01, NB_B = 0x02, NB_SEL = 0x04, NB_START = 0x08, NB_UP = 0x10, NB_DN = 0x20, NB_LT = 0x40, NB_RT = 0x80 };
struct NesBtn { int y, h; const char *l; uint8_t mask; uint16_t col; };
static const NesBtn NES_BTNS[] = {
  {28, 30, "START", NB_START, RGB565(60, 60, 80)},
  {60, 26, "SELECT", NB_SEL, RGB565(60, 60, 80)},
  {88, 36, "B", NB_B, RGB565(170, 30, 50)},
  {126, 36, "A", NB_A, RGB565(200, 40, 60)},
  {164, 36, ">+A", NB_A | NB_RT, RGB565(130, 40, 120)},
  {202, 37, ">+B", NB_B | NB_RT, RGB565(90, 40, 130)},
};

static void nesPanel() {
  tft.fillRect(256, 0, 64, 240, RGB565(20, 20, 30));
  for (auto &b : NES_BTNS) ui::button(258, b.y, 60, b.h, b.l, b.col, TFT_WHITE, 2);
  ui::exitBox();
}

void app_nes(AppCtx &c) {
  String path = ui::pickFile("/roms", ".nes", "NES - choose ROM");
  if (!path.length()) return;
  String err;
  tft.fillScreen(TFT_BLACK);
  ui::centerText("Paging ROM into RAM...", 160, 110, C_TEXT, TFT_BLACK, 2);
  if (!nes::load(path, err)) {
    nes::unload();
    tft.fillScreen(C_BG); c.header();
    ui::msgBox("ROM NOT LOADED", err.c_str());
    return;
  }
  sys::log("nes: %s mapper %d prg %uK chr %uK%s", path.c_str(), nes::mapperId,
           nes::prgSize / 1024, nes::chrSize / 1024, nes::chrRam ? " (RAM)" : "");
  for (int i = 0; i < 64; ++i) {
    uint32_t c24 = nes::NES_RGB[i];
    uint16_t c16 = RGB565((c24 >> 16) & 0xFF, (c24 >> 8) & 0xFF, c24 & 0xFF);
    nes::nesPal[i] = (c16 >> 8) | (c16 << 8);
  }
  memset(nes::ram, 0, sizeof(nes::ram)); memset(nes::vram, 0, sizeof(nes::vram));
  memset(nes::pal, 0, sizeof(nes::pal)); memset(nes::oam, 0xFF, sizeof(nes::oam));
  nes::pctrl = nes::pmask = nes::pstat = nes::oamaddr = 0; nes::pv = nes::pt = 0; nes::pw = false;
  nes::pad = 0; nes::nmiReq = false; nes::irqPending = false;
  nes::reset();

  tft.fillScreen(TFT_BLACK);
  nesPanel();
  String nm = path.substring(path.lastIndexOf('/') + 1);
  tft.setTextColor(C_DIM, TFT_BLACK);
  tft.drawString(nm.substring(0, 22), 2, 4, 1);
  tft.setSwapBytes(false);

  uint32_t frameUs = 16639, next = micros(), fpsT = millis();
  int frames = 0, drawn = 0, skipped = 0;
  while (true) {
    // input (single resistive touch point)
    ui::clearEvents();
    Touch &t = ui::poll();
    if (ui::exitHit(t)) break;
    uint8_t p = 0;
    if (t.down) {
      if (t.x >= 256) {
        for (auto &b : NES_BTNS) if (t.y >= b.y && t.y < b.y + b.h) p = b.mask;
      } else if (t.y > 16) {
        int dx = t.x - 128, dy = t.y - 128;
        if (abs(dx) > 18 || abs(dy) > 18) {
          if (dx > abs(dy) / 2) p |= NB_RT;
          if (-dx > abs(dy) / 2) p |= NB_LT;
          if (dy > abs(dx) / 2) p |= NB_DN;
          if (-dy > abs(dx) / 2) p |= NB_UP;
        }
      }
    }
    nes::pad = p;

    bool draw = micros() <= next + frameUs || skipped >= 3;
    nes::frame(draw);
    if (draw) { drawn++; skipped = 0; } else skipped++;
    frames++;
    next += frameUs;
    int32_t ahead = (int32_t)(next - micros());
    if (ahead > 0) delayMicroseconds(min(ahead, 16000));
    else if (ahead < -100000) next = micros();     // way behind: resync
    if (millis() - fpsT >= 1000) {
      char b[32]; snprintf(b, sizeof(b), "%2d fps (%d emu)  ", drawn, frames);
      tft.setTextColor(C_DIM, TFT_BLACK); tft.drawString(b, 180 - 30, 4, 1);
      fpsT = millis(); frames = drawn = 0;
    }
  }
  nes::unload();
  tft.setSwapBytes(false);
}
