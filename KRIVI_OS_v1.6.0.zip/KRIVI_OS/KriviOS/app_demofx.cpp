// ============================================================================
//  58  DEMOSCENE FX  - plasma / fire / metaballs. Renders at 160x100 and
//      line-doubles to a full 320x200 via bulk pushImage: a floating-point
//      pixel pusher that stresses the ESP32 core and the SPI bus.
// ============================================================================
#include "apps_common.h"

void app_demofx(AppCtx &c) {
  const int W = 160, H = 100, OY = 34;
  uint16_t *line = (uint16_t *)malloc(W * 2);
  uint16_t *out = (uint16_t *)malloc(320 * 2);
  uint8_t *fire = (uint8_t *)calloc(W * (H + 2), 1);
  if (!line || !out || !fire) { free(line); free(out); free(fire); ui::msgBox("DEMO FX", "Not enough RAM"); return; }
  uint16_t palPlasma[256], palFire[256];
  for (int i = 0; i < 256; ++i) {
    uint16_t p = ui::hsv(i * 360 / 256, 255, 255); palPlasma[i] = (p >> 8) | (p << 8);
    int r = constrain(i * 3, 0, 255), g = constrain(i * 3 - 255, 0, 255), b = constrain(i * 3 - 510, 0, 255);
    uint16_t f = RGB565(r, g, b); palFire[i] = (f >> 8) | (f << 8);
  }
  int fx = 0; const char *NAMES[3] = {"PLASMA", "FIRE", "METABALLS"};
  auto bar = [&]() {
    ui::button(4, 202, 150, 36, "NEXT EFFECT", RGB565(90, 50, 160));
    tft.fillRect(160, 202, 160, 36, C_BG);
    tft.setTextColor(C_ACCENT, C_BG); tft.drawString(NAMES[fx], 178, 212, 4);
  };
  ui::clearBody(TFT_BLACK); bar();
  tft.setSwapBytes(true);
  float bx[5], by[5], bvx[5], bvy[5];
  for (int i = 0; i < 5; ++i) { bx[i] = rnd(W); by[i] = rnd(H); bvx[i] = (rnd(100) - 50) / 22.0f; bvy[i] = (rnd(100) - 50) / 22.0f; }
  uint32_t fr = 0, fpsT = millis(); int frames = 0;
  auto emit = [&](int y) {                         // double `line` into `out` and push 2 rows
    for (int x = 0; x < W; ++x) { out[2 * x] = line[x]; out[2 * x + 1] = line[x]; }
    tft.pushImage(0, OY + 2 * y, 320, 1, out);
    tft.pushImage(0, OY + 2 * y + 1, 320, 1, out);
  };
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && ui::inRect(t.sx, t.sy, 4, 202, 150, 36)) { fx = (fx + 1) % 3; if (fx == 1) memset(fire, 0, W * (H + 2)); tft.setSwapBytes(true); bar(); }
    fr++;
    if (fx == 0) {
      float ft = fr * 0.06f;
      for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
          float v = sinf(x * 0.06f + ft) + sinf(y * 0.08f - ft) + sinf((x + y) * 0.05f + ft * 1.3f)
                  + sinf(sqrtf((x - 80) * (x - 80) + (y - 50) * (y - 50)) * 0.09f - ft);
          line[x] = palPlasma[(uint8_t)((v + 4) * 31)];
        }
        emit(y);
      }
    } else if (fx == 1) {
      for (int x = 0; x < W; ++x) { fire[H * W + x] = fire[(H + 1) * W + x] = 170 + rnd(86); }
      for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
          int b = (y + 1) * W + x;
          int sum = fire[b] + fire[b + (x < W - 1 ? 1 : 0)] + fire[b - (x > 0 ? 1 : 0)] + fire[(y + 2) * W + x];
          int v = (sum * 98) / 408; fire[y * W + x] = v > 255 ? 255 : v;
        }
      }
      for (int y = 0; y < H; ++y) { for (int x = 0; x < W; ++x) line[x] = palFire[fire[(H - 1 - y) * W + x]]; emit(y); }
    } else {
      for (int i = 0; i < 5; ++i) { bx[i] += bvx[i]; by[i] += bvy[i];
        if (bx[i] < 2 || bx[i] > W - 2) bvx[i] = -bvx[i]; if (by[i] < 2 || by[i] > H - 2) bvy[i] = -bvy[i]; }
      for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
          float s = 0;
          for (int i = 0; i < 5; ++i) { float dx = x - bx[i], dy = y - by[i]; s += 1100.0f / (dx * dx + dy * dy + 1); }
          line[x] = palPlasma[(uint8_t)(constrain((int)(s * 36), 0, 255) + fr) & 0xFF];
        }
        emit(y);
      }
    }
    if (++frames && millis() - fpsT > 1000) { tft.setSwapBytes(false); hudf("%d fps", frames); tft.setSwapBytes(true); frames = 0; fpsT = millis(); }
  }
  tft.setSwapBytes(false);
  free(line); free(out); free(fire);
}
