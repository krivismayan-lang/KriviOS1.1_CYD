// ============================================================================
//  New arcade apps that push the CYD
//   53  Raycaster FPS   - Wolfenstein-style 3D maze, DDA column renderer
//   54  2048            - swipe-to-merge number puzzle
// ============================================================================
#include "apps_common.h"

// ============================================================================
//  53  RAYCASTER FPS
// ============================================================================
void app_raycaster(AppCtx &c) {
  const int MW = 16, MH = 16, VH = 202;
  static const char *MAP[16] = {
    "################", "#..............#", "#.###.####.##..#", "#.#.....#...#..#",
    "#.#.###.#.#.##.#", "#...#...#.#....#", "#.#.#.###.#.##.#", "#.#...#.#.#..#.#",
    "#.###.#.#.##.#.#", "#...#.#.....#..#", "#.#.#.#####.##.#", "#.#........G#..#",
    "#.#.#####.###..#", "#.....#.......##", "#.###.#.#####..#", "################"};
  auto cell = [&](int x, int y) { return (x < 0 || y < 0 || x >= MW || y >= MH) ? '#' : MAP[y][x]; };
  float px = 2.5f, py = 2.5f, ang = 0.4f;
  const float FOV = 1.05f;
  uint32_t t0 = millis();
  auto controls = [&]() {
    ui::button(2, 206, 76, 32, "< TURN", C_PANEL2); ui::button(82, 206, 76, 32, "FWD", RGB565(0, 120, 80));
    ui::button(162, 206, 76, 32, "BACK", C_PANEL2); ui::button(242, 206, 76, 32, "TURN >", C_PANEL2);
  };
  controls();
  while (c.frame(16)) {
    Touch &t = *c.t;
    float moveS = 0.07f, rotS = 0.055f;
    if (t.down && t.y >= 206) {
      if (t.x < 80) ang -= rotS;
      else if (t.x < 160) { float nx = px + cosf(ang) * moveS, ny = py + sinf(ang) * moveS; if (cell((int)nx, (int)py) != '#') px = nx; if (cell((int)px, (int)ny) != '#') py = ny; }
      else if (t.x < 238) { float nx = px - cosf(ang) * moveS, ny = py - sinf(ang) * moveS; if (cell((int)nx, (int)py) != '#') px = nx; if (cell((int)px, (int)ny) != '#') py = ny; }
      else ang += rotS;
    }
    // render columns (2px wide)
    for (int col = 0; col < 320; col += 2) {
      float ca = ang + (col / 320.0f - 0.5f) * FOV;
      float rx = cosf(ca), ry = sinf(ca);
      // DDA
      int mx = (int)px, my = (int)py;
      float ddx = fabsf(1 / rx), ddy = fabsf(1 / ry);
      int sx = rx < 0 ? -1 : 1, sy = ry < 0 ? -1 : 1;
      float sdx = (rx < 0 ? (px - mx) : (mx + 1 - px)) * ddx;
      float sdy = (ry < 0 ? (py - my) : (my + 1 - py)) * ddy;
      int side = 0; char hit = 0;
      for (int it = 0; it < 64 && !hit; ++it) {
        if (sdx < sdy) { sdx += ddx; mx += sx; side = 0; } else { sdy += ddy; my += sy; side = 1; }
        char cc = cell(mx, my); if (cc != '.' ) hit = cc;
      }
      float dist = side == 0 ? (sdx - ddx) : (sdy - ddy);
      if (dist < 0.05f) dist = 0.05f;
      int h = (int)(VH / dist); if (h > VH) h = VH;
      int y0 = (VH - h) / 2, y1 = y0 + h;
      // ceiling / floor
      tft.drawFastVLine(col, 0, y0, RGB565(20, 24, 40)); tft.drawFastVLine(col + 1, 0, y0, RGB565(20, 24, 40));
      tft.drawFastVLine(col, y1, VH - y1, RGB565(40, 36, 30)); tft.drawFastVLine(col + 1, y1, VH - y1, RGB565(40, 36, 30));
      uint16_t base = hit == 'G' ? RGB565(255, 210, 40) : RGB565(200, 70, 60);
      if (hit == '#') base = (mx + my) & 1 ? RGB565(150, 155, 170) : RGB565(120, 125, 145);
      uint8_t sh = (uint8_t)constrain(255 - dist * 26, 50, 255); if (side) sh = sh * 7 / 10;
      uint16_t wcol = tft.alphaBlend(sh, base, TFT_BLACK);
      tft.drawFastVLine(col, y0, h, wcol); tft.drawFastVLine(col + 1, y0, h, wcol);
    }
    // minimap
    const int ox = 4, oy = 4, cs = 4;
    for (int y = 0; y < MH; ++y) for (int x = 0; x < MW; ++x)
      tft.fillRect(ox + x * cs, oy + y * cs, cs - 1, cs - 1, cell(x, y) == '#' ? RGB565(60, 66, 90) : cell(x, y) == 'G' ? C_WARN : RGB565(15, 18, 28));
    tft.fillCircle(ox + (int)(px * cs), oy + (int)(py * cs), 2, C_OK);
    ui::exitBox();
    if (cell((int)px, (int)py) == 'G') {
      char s[32]; snprintf(s, 32, "escaped in %lus", (millis() - t0) / 1000);
      banner("LEVEL CLEAR", s, C_OK);
      if (!waitTap(c)) return;
      px = 2.5f; py = 2.5f; ang = 0.4f; t0 = millis(); tft.fillRect(0, 0, 320, VH, TFT_BLACK); controls();
    }
  }
}

// ============================================================================
//  54  2048
// ============================================================================
void app_2048(AppCtx &c) {
  int g[4][4]; int score = 0, best = 0;
  const int OX = 36, OY = 44, CS = 60, GAP = 4;
  auto tileCol = [](int v) -> uint16_t {
    switch (v) { case 2: return RGB565(238, 228, 218); case 4: return RGB565(237, 224, 200);
      case 8: return RGB565(242, 177, 121); case 16: return RGB565(245, 149, 99); case 32: return RGB565(246, 124, 95);
      case 64: return RGB565(246, 94, 59); case 128: return RGB565(237, 207, 114); case 256: return RGB565(237, 204, 97);
      case 512: return RGB565(237, 200, 80); case 1024: return RGB565(237, 197, 63); case 2048: return RGB565(237, 194, 46);
      default: return v ? RGB565(60, 58, 50) : RGB565(50, 48, 44); }
  };
  auto spawn = [&]() { int e[16], n = 0; for (int i = 0; i < 16; ++i) if (!g[i / 4][i % 4]) e[n++] = i; if (!n) return; int k = e[rnd(n)]; g[k / 4][k % 4] = rnd(10) ? 2 : 4; };
  auto drawTile = [&](int r, int col) {
    int x = OX + col * (CS + GAP), y = OY + r * (CS + GAP), v = g[r][col];
    tft.fillRoundRect(x, y, CS, CS, 6, tileCol(v));
    if (v) { tft.setTextColor(v <= 4 ? RGB565(119, 110, 101) : TFT_WHITE, tileCol(v));
      tft.setTextDatum(MC_DATUM); tft.drawNumber(v, x + CS / 2, y + CS / 2, v < 128 ? 4 : v < 1024 ? 2 : 2); tft.setTextDatum(TL_DATUM); }
  };
  auto drawAll = [&]() { for (int r = 0; r < 4; ++r) for (int col = 0; col < 4; ++col) drawTile(r, col);
    char s[24]; snprintf(s, 24, "SCORE %d", score); tft.fillRect(0, 28, 220, 14, C_BG); tft.setTextColor(C_TEXT, C_BG); tft.drawString(s, 6, 28, 2);
    snprintf(s, 24, "BEST %d", best); tft.setTextColor(C_DIM, C_BG); tft.drawString(s, 170, 28, 2);
    ui::button(286, 28, 32, 16, "NEW", C_PANEL2, C_TEXT, 1); };
  auto slide = [&](int line[4]) -> bool {
    int t[4] = {0, 0, 0, 0}, n = 0; bool moved = false;
    for (int i = 0; i < 4; ++i) if (line[i]) t[n++] = line[i];
    for (int i = 0; i < 3; ++i) if (t[i] && t[i] == t[i + 1]) { t[i] *= 2; score += t[i]; t[i + 1] = 0; }
    int o[4] = {0, 0, 0, 0}, m = 0;
    for (int i = 0; i < 4; ++i) if (t[i]) o[m++] = t[i];
    for (int i = 0; i < 4; ++i) { if (line[i] != o[i]) moved = true; line[i] = o[i]; }
    return moved;
  };
  auto move = [&](int dir) -> bool {   // 0 up 1 right 2 down 3 left
    bool moved = false;
    for (int k = 0; k < 4; ++k) {
      int line[4];
      for (int i = 0; i < 4; ++i) {
        if (dir == 3) line[i] = g[k][i]; else if (dir == 1) line[i] = g[k][3 - i];
        else if (dir == 0) line[i] = g[i][k]; else line[i] = g[3 - i][k];
      }
      if (slide(line)) moved = true;
      for (int i = 0; i < 4; ++i) {
        if (dir == 3) g[k][i] = line[i]; else if (dir == 1) g[k][3 - i] = line[i];
        else if (dir == 0) g[i][k] = line[i]; else g[3 - i][k] = line[i];
      }
    }
    return moved;
  };
  auto canMove = [&]() { for (int r = 0; r < 4; ++r) for (int col = 0; col < 4; ++col) { if (!g[r][col]) return true;
    if (col < 3 && g[r][col] == g[r][col + 1]) return true; if (r < 3 && g[r][col] == g[r + 1][col]) return true; } return false; };
newgame:
  memset(g, 0, sizeof(g)); score = 0;
  ui::clearBody(); spawn(); spawn(); drawAll();
  bool won = false;
  while (c.loop()) {
    Touch &t = *c.t;
    if (t.tap && ui::inRect(t.sx, t.sy, 286, 28, 32, 16)) goto newgame;
    int dir = -1;
    if (t.swipe == SW_UP) dir = 0; else if (t.swipe == SW_RIGHT) dir = 1;
    else if (t.swipe == SW_DOWN) dir = 2; else if (t.swipe == SW_LEFT) dir = 3;
    if (dir >= 0) {
      if (move(dir)) { spawn(); best = max(best, score); drawAll(); audio::click();
        if (!won) for (int i = 0; i < 16; ++i) if (g[i / 4][i % 4] == 2048) { won = true; banner("2048!", "keep going - tap", C_WARN); waitTap(c); drawAll(); }
        if (!canMove()) { banner("GAME OVER", "swipe to restart", C_ERR); if (!waitTap(c)) return; goto newgame; }
      }
    }
  }
}
