Boot and session logs are written here by KRIVI OS.
