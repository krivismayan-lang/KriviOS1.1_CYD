Sketchpad (app 35) saves 320x170 16-colour .bmp files here.
