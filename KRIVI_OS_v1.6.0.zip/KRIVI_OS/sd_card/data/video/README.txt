Motion-JPEG clips for the Video Player (app 40). Convert any video you own with:
  ffmpeg -i input.mp4 -vf "fps=20,scale=320:240:force_original_aspect_ratio=decrease" -q:v 7 -an output.mjpeg
Keep each JPEG frame under 40 KB (raise -q:v if frames are dropped).
