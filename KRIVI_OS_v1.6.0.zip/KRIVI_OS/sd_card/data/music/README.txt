MP3 files for the MP3 Music Player (app 44). Any bitrate, 32/44.1/48 kHz, mono or stereo.
Songs in this folder play in order; ID3v2 title/artist/album tags are shown.
Other formats: python3 tools/convert_media.py song.flac --sd <card>
