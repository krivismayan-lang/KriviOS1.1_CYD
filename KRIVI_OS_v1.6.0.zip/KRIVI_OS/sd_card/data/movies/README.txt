Movies for the Video & MP4 Player (app 40).
The ESP32 cannot decode MP4/H.264 directly, so convert on a computer:
  python3 tools/convert_media.py my_video.mp4 --sd <card>
This writes an .avi (Motion-JPEG 320x240 @15 fps + 22 kHz audio) that plays with sound.
